import { QualityMetric, DefectLog, ProcessParameter, KPI } from '../types';

const LINES = ['Line-A1', 'Line-A2', 'Line-B1', 'Line-B2', 'Line-C1'];
const PRODUCTS = ['PCB-Assembly', 'Motor-Housing', 'Sensor-Module', 'Actuator-Unit', 'Control-Board'];
const DEFECT_TYPES = [
  'Surface Scratch', 'Dimensional Deviation', 'Solder Bridge', 'Crack/Fracture',
  'Contamination', 'Misalignment', 'Short Circuit', 'Open Circuit',
  'Color Mismatch', 'Warpage', 'Burrs', 'Incomplete Fill'
];
const DETECTED_BY = ['AOI System', 'Manual Inspection', 'SPC Alert', 'Customer Return', 'In-line Sensor'];

function seededRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 16807 + 0) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export function generateQualityMetrics(): QualityMetric[] {
  const rand = seededRandom(42);
  const metrics: QualityMetric[] = [];
  const now = Date.now();

  for (let day = 30; day >= 0; day--) {
    for (const line of LINES) {
      for (const product of PRODUCTS.slice(0, 2 + Math.floor(rand() * 2))) {
        const baseDefectRate = 0.02 + rand() * 0.03;
        const spike = rand() > 0.92 ? rand() * 0.15 : 0;
        const defectRate = Math.min(baseDefectRate + spike, 0.25);
        const inspectionCount = 200 + Math.floor(rand() * 300);

        metrics.push({
          timestamp: new Date(now - day * 86400000 + Math.floor(rand() * 86400000)).toISOString(),
          line,
          productType: product,
          defectRate: parseFloat(defectRate.toFixed(4)),
          yield: parseFloat((1 - defectRate).toFixed(4)),
          temperature: parseFloat((22 + rand() * 8 + (spike > 0.05 ? 5 : 0)).toFixed(1)),
          pressure: parseFloat((1.5 + rand() * 0.8 + (spike > 0.05 ? 0.3 : 0)).toFixed(2)),
          humidity: parseFloat((40 + rand() * 20).toFixed(1)),
          speed: parseFloat((50 + rand() * 30).toFixed(1)),
          inspectionCount,
          defectCount: Math.floor(inspectionCount * defectRate),
        });
      }
    }
  }

  return metrics.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
}

export function generateDefectLogs(): DefectLog[] {
  const rand = seededRandom(123);
  const logs: DefectLog[] = [];
  const now = Date.now();
  const severities: DefectLog['severity'][] = ['low', 'medium', 'high', 'critical'];
  const statuses: DefectLog['status'][] = ['open', 'investigating', 'resolved', 'closed'];

  for (let i = 0; i < 85; i++) {
    const dayOffset = Math.floor(rand() * 30);
    const severity = severities[Math.floor(rand() * (rand() > 0.7 ? 4 : 3))];
    const status = dayOffset > 15 ? (rand() > 0.3 ? 'closed' : 'resolved') : statuses[Math.floor(rand() * 4)];

    logs.push({
      id: `INC-${String(1000 + i).padStart(4, '0')}`,
      timestamp: new Date(now - dayOffset * 86400000 + Math.floor(rand() * 86400000)).toISOString(),
      line: LINES[Math.floor(rand() * LINES.length)],
      productType: PRODUCTS[Math.floor(rand() * PRODUCTS.length)],
      defectType: DEFECT_TYPES[Math.floor(rand() * DEFECT_TYPES.length)],
      severity,
      quantity: Math.floor(5 + rand() * 200),
      description: `Detected ${DEFECT_TYPES[Math.floor(rand() * DEFECT_TYPES.length)].toLowerCase()} on ${PRODUCTS[Math.floor(rand() * PRODUCTS.length)]} during ${['routine inspection', 'batch sampling', 'end-of-line check', 'incoming QC'][Math.floor(rand() * 4)]}`,
      detectedBy: DETECTED_BY[Math.floor(rand() * DETECTED_BY.length)],
      status,
    });
  }

  return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

export function getCurrentProcessParameters(line: string): ProcessParameter[] {
  const rand = seededRandom(line.charCodeAt(line.length - 1) * 100);
  return [
    {
      name: 'Temperature',
      value: parseFloat((22 + rand() * 10).toFixed(1)),
      unit: '°C',
      lowerLimit: 20,
      upperLimit: 30,
      status: 'normal',
    },
    {
      name: 'Pressure',
      value: parseFloat((1.5 + rand() * 1.0).toFixed(2)),
      unit: 'bar',
      lowerLimit: 1.2,
      upperLimit: 2.5,
      status: 'normal',
    },
    {
      name: 'Humidity',
      value: parseFloat((40 + rand() * 25).toFixed(1)),
      unit: '%RH',
      lowerLimit: 35,
      upperLimit: 65,
      status: 'normal',
    },
    {
      name: 'Line Speed',
      value: parseFloat((50 + rand() * 35).toFixed(1)),
      unit: 'units/min',
      lowerLimit: 40,
      upperLimit: 85,
      status: 'normal',
    },
    {
      name: 'Vibration',
      value: parseFloat((0.5 + rand() * 2.0).toFixed(2)),
      unit: 'mm/s',
      lowerLimit: 0,
      upperLimit: 2.0,
      status: rand() > 0.7 ? 'warning' : 'normal',
    },
    {
      name: 'Voltage',
      value: parseFloat((220 + rand() * 20).toFixed(1)),
      unit: 'V',
      lowerLimit: 210,
      upperLimit: 240,
      status: 'normal',
    },
  ].map(p => ({
    ...p,
    status: p.value < p.lowerLimit || p.value > p.upperLimit ? 'critical' :
            p.value < p.lowerLimit * 1.05 || p.value > p.upperLimit * 0.95 ? 'warning' : 'normal',
  }));
}

export function getKPIs(defectLogs: DefectLog[], metrics: QualityMetric[]): KPI[] {
  const openIncidents = defectLogs.filter(d => d.status === 'open' || d.status === 'investigating').length;
  const avgDefectRate = metrics.slice(-50).reduce((s, m) => s + m.defectRate, 0) / Math.min(50, metrics.length);
  const avgYield = metrics.slice(-50).reduce((s, m) => s + m.yield, 0) / Math.min(50, metrics.length);
  const criticalIncidents = defectLogs.filter(d => d.severity === 'critical' && (d.status === 'open' || d.status === 'investigating')).length;

  return [
    { label: 'Open Incidents', value: String(openIncidents), change: -12, icon: 'alert-circle', unit: 'active' },
    { label: 'Avg Defect Rate', value: (avgDefectRate * 100).toFixed(2), change: -8.5, icon: 'trending-down', unit: '%' },
    { label: 'Yield Rate', value: (avgYield * 100).toFixed(2), change: 2.3, icon: 'check-circle', unit: '%' },
    { label: 'Critical Alerts', value: String(criticalIncidents), change: criticalIncidents > 0 ? 25 : -100, icon: 'zap', unit: 'pending' },
  ];
}

export const DEFECT_TYPE_OPTIONS = DEFECT_TYPES;
export const LINE_OPTIONS = LINES;
export const PRODUCT_OPTIONS = PRODUCTS;
