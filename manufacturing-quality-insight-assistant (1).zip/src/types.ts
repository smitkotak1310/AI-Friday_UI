export interface QualityMetric {
  timestamp: string;
  line: string;
  productType: string;
  defectRate: number;
  yield: number;
  temperature: number;
  pressure: number;
  humidity: number;
  speed: number;
  inspectionCount: number;
  defectCount: number;
}

export interface DefectLog {
  id: string;
  timestamp: string;
  line: string;
  productType: string;
  defectType: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  quantity: number;
  description: string;
  detectedBy: string;
  status: 'open' | 'investigating' | 'resolved' | 'closed';
}

export interface ProcessParameter {
  name: string;
  value: number;
  unit: string;
  lowerLimit: number;
  upperLimit: number;
  status: 'normal' | 'warning' | 'critical';
}

export interface IncidentInput {
  defectType: string;
  productionLine: string;
  productType: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timeRange: string;
  description: string;
  affectedQuantity: number;
  processParameters: ProcessParameter[];
}

export interface RootCause {
  category: string;
  description: string;
  confidence: number;
  evidence: string[];
  recommendedAction: string;
  priority: 'high' | 'medium' | 'low';
}

export interface AnalysisResult {
  incidentId: string;
  timestamp: string;
  summary: string;
  rootCauses: RootCause[];
  relatedIncidents: string[];
  trendAnalysis: string;
  processDeviations: ProcessParameter[];
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  estimatedResolution: string;
}

export interface KPI {
  label: string;
  value: string;
  change: number;
  unit?: string;
  icon: string;
}

export type Page = 'dashboard' | 'analyze' | 'log' | 'docs' | 'chat' | 'settings';

export interface ApiConfig {
  apiKey: string;
  baseUrl: string;
  model: string;
  temperature: number;
  maxTokens: number;
  enabled: boolean;
  provider: 'openai' | 'anthropic' | 'custom' | 'ollama' | 'azure' | 'groq';
}

export interface LLMModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  baseAccuracy: number;
  baseConfidence: number;
  responseSpeed: 'fast' | 'medium' | 'slow';
  specialties: string[];
  icon: string;
  color: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  modelId?: string;
  accuracy?: number;
  confidence?: number;
  responseTime?: number;
  tokensUsed?: number;
  sources?: string[];
  thinkingSteps?: string[];
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: string;
  modelId: string;
}
