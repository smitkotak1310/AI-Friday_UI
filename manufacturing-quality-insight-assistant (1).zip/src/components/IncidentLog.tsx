import { useState, useMemo } from 'react';
import { Search, Filter, Eye, X } from 'lucide-react';
import { DefectLog } from '../types';

interface IncidentLogProps {
  defectLogs: DefectLog[];
  onViewAnalysis: (log: DefectLog) => void;
}

export default function IncidentLog({ defectLogs, onViewAnalysis }: IncidentLogProps) {
  const [search, setSearch] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedLog, setSelectedLog] = useState<DefectLog | null>(null);

  const filtered = useMemo(() => {
    return defectLogs.filter(log => {
      const matchesSearch = !search || 
        log.id.toLowerCase().includes(search.toLowerCase()) ||
        log.defectType.toLowerCase().includes(search.toLowerCase()) ||
        log.line.toLowerCase().includes(search.toLowerCase()) ||
        log.productType.toLowerCase().includes(search.toLowerCase()) ||
        log.description.toLowerCase().includes(search.toLowerCase());
      const matchesSeverity = severityFilter === 'all' || log.severity === severityFilter;
      const matchesStatus = statusFilter === 'all' || log.status === statusFilter;
      return matchesSearch && matchesSeverity && matchesStatus;
    });
  }, [defectLogs, search, severityFilter, statusFilter]);

  const severityColors: Record<string, string> = {
    critical: 'bg-red-100 text-red-700 border-red-200',
    high: 'bg-orange-100 text-orange-700 border-orange-200',
    medium: 'bg-yellow-100 text-yellow-700 border-yellow-200',
    low: 'bg-green-100 text-green-700 border-green-200',
  };

  const statusColors: Record<string, string> = {
    open: 'bg-red-50 text-red-700',
    investigating: 'bg-yellow-50 text-yellow-700',
    resolved: 'bg-blue-50 text-blue-700',
    closed: 'bg-green-50 text-green-700',
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Incident Log</h2>
        <p className="text-slate-500 text-sm mt-1">Browse and search historical quality incidents</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by ID, defect type, line, product..."
              className="w-full pl-9 pr-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            />
          </div>
          <div className="flex gap-2">
            <div className="relative">
              <Filter size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <select
                value={severityFilter}
                onChange={e => setSeverityFilter(e.target.value)}
                className="pl-8 pr-8 py-2.5 rounded-lg border border-slate-300 text-sm appearance-none bg-white focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="all">All Severity</option>
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="px-3 py-2.5 rounded-lg border border-slate-300 text-sm appearance-none bg-white focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="all">All Status</option>
              <option value="open">Open</option>
              <option value="investigating">Investigating</option>
              <option value="resolved">Resolved</option>
              <option value="closed">Closed</option>
            </select>
          </div>
        </div>
        <div className="mt-2 text-xs text-slate-500">
          Showing {filtered.length} of {defectLogs.length} incidents
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">ID</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Date</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Defect Type</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Line</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Product</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Severity</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Qty</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(log => (
                <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs text-slate-500">{log.id}</td>
                  <td className="px-4 py-3 text-slate-600 whitespace-nowrap">{new Date(log.timestamp).toLocaleDateString()}</td>
                  <td className="px-4 py-3 font-medium text-slate-800">{log.defectType}</td>
                  <td className="px-4 py-3 text-slate-600">{log.line}</td>
                  <td className="px-4 py-3 text-slate-600">{log.productType}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${severityColors[log.severity]}`}>
                      {log.severity}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-600">{log.quantity}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[log.status]}`}>
                      {log.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => setSelectedLog(log)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                      title="View details"
                    >
                      <Eye size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="py-12 text-center text-slate-400">
            <Search size={32} className="mx-auto mb-2 opacity-50" />
            <p>No incidents match your filters</p>
          </div>
        )}
      </div>

      {/* Detail Modal */}
      {selectedLog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setSelectedLog(null)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">{selectedLog.id}</h3>
              <button onClick={() => setSelectedLog(null)} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400">
                <X size={18} />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider">Defect Type</span>
                  <p className="text-sm font-medium text-slate-800 mt-1">{selectedLog.defectType}</p>
                </div>
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider">Severity</span>
                  <p className="mt-1">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${severityColors[selectedLog.severity]}`}>
                      {selectedLog.severity}
                    </span>
                  </p>
                </div>
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider">Production Line</span>
                  <p className="text-sm font-medium text-slate-800 mt-1">{selectedLog.line}</p>
                </div>
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider">Product</span>
                  <p className="text-sm font-medium text-slate-800 mt-1">{selectedLog.productType}</p>
                </div>
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider">Quantity Affected</span>
                  <p className="text-sm font-medium text-slate-800 mt-1">{selectedLog.quantity} units</p>
                </div>
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider">Detected By</span>
                  <p className="text-sm font-medium text-slate-800 mt-1">{selectedLog.detectedBy}</p>
                </div>
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider">Status</span>
                  <p className="mt-1">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[selectedLog.status]}`}>
                      {selectedLog.status}
                    </span>
                  </p>
                </div>
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider">Date</span>
                  <p className="text-sm font-medium text-slate-800 mt-1">{new Date(selectedLog.timestamp).toLocaleString()}</p>
                </div>
              </div>
              <div>
                <span className="text-xs text-slate-400 uppercase tracking-wider">Description</span>
                <p className="text-sm text-slate-700 mt-1 bg-slate-50 rounded-lg p-3">{selectedLog.description}</p>
              </div>
              <button
                onClick={() => {
                  onViewAnalysis(selectedLog);
                  setSelectedLog(null);
                }}
                className="w-full py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
              >
                <Eye size={16} />
                Run AI Analysis on This Incident
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
