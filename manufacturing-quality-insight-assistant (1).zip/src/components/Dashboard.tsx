import { useMemo } from 'react';
import {
  AlertTriangle,
  TrendingDown,
  CheckCircle,
  Zap,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from 'recharts';
import { QualityMetric, DefectLog, KPI, Page } from '../types';

const iconMap: Record<string, React.ReactNode> = {
  'alert-circle': <AlertTriangle size={22} />,
  'trending-down': <TrendingDown size={22} />,
  'check-circle': <CheckCircle size={22} />,
  'zap': <Zap size={22} />,
};

const COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6', '#ec4899'];

interface DashboardProps {
  metrics: QualityMetric[];
  defectLogs: DefectLog[];
  kpis: KPI[];
  onNavigate: (page: Page) => void;
}

export default function Dashboard({ metrics, defectLogs, kpis, onNavigate }: DashboardProps) {
  // Daily defect rate trend
  const dailyTrend = useMemo(() => {
    const grouped: Record<string, { total: number; count: number }> = {};
    metrics.forEach(m => {
      const day = m.timestamp.slice(0, 10);
      if (!grouped[day]) grouped[day] = { total: 0, count: 0 };
      grouped[day].total += m.defectRate;
      grouped[day].count += 1;
    });
    return Object.entries(grouped)
      .map(([date, { total, count }]) => ({
        date: date.slice(5),
        defectRate: parseFloat(((total / count) * 100).toFixed(2)),
        yield: parseFloat(((1 - total / count) * 100).toFixed(2)),
      }))
      .slice(-14);
  }, [metrics]);

  // Defects by type
  const defectByType = useMemo(() => {
    const counts: Record<string, number> = {};
    defectLogs.forEach(d => {
      counts[d.defectType] = (counts[d.defectType] || 0) + 1;
    });
    return Object.entries(counts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [defectLogs]);

  // Defects by line
  const defectByLine = useMemo(() => {
    const counts: Record<string, number> = {};
    defectLogs.forEach(d => {
      counts[d.line] = (counts[d.line] || 0) + d.quantity;
    });
    return Object.entries(counts).map(([line, quantity]) => ({ line, quantity }));
  }, [defectLogs]);

  // Severity distribution
  const severityDist = useMemo(() => {
    const counts: Record<string, number> = {};
    defectLogs.forEach(d => {
      counts[d.severity] = (counts[d.severity] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [defectLogs]);

  const severityColors: Record<string, string> = {
    critical: '#ef4444',
    high: '#f97316',
    medium: '#f59e0b',
    low: '#22c55e',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Quality Dashboard</h2>
          <p className="text-slate-500 text-sm mt-1">Real-time manufacturing quality metrics and incident overview</p>
        </div>
        <button
          onClick={() => onNavigate('analyze')}
          className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/20 flex items-center gap-2"
        >
          <Zap size={16} />
          Analyze New Incident
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, i) => (
          <div key={i} className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-slate-500">{kpi.label}</span>
              <div className={`p-2 rounded-lg ${
                i === 0 ? 'bg-orange-50 text-orange-600' :
                i === 1 ? 'bg-red-50 text-red-600' :
                i === 2 ? 'bg-green-50 text-green-600' :
                'bg-purple-50 text-purple-600'
              }`}>
                {iconMap[kpi.icon]}
              </div>
            </div>
            <div className="flex items-end gap-2">
              <span className="text-3xl font-bold text-slate-900">{kpi.value}</span>
              {kpi.unit && <span className="text-sm text-slate-400 mb-1">{kpi.unit}</span>}
            </div>
            <div className="flex items-center gap-1 mt-2">
              {kpi.change >= 0 ? (
                <ArrowUpRight size={14} className="text-red-500" />
              ) : (
                <ArrowDownRight size={14} className="text-green-500" />
              )}
              <span className={`text-xs font-medium ${kpi.change >= 0 ? 'text-red-500' : 'text-green-500'}`}>
                {Math.abs(kpi.change)}%
              </span>
              <span className="text-xs text-slate-400">vs last period</span>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Defect Rate Trend */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Defect Rate & Yield Trend (14 Days)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={dailyTrend}>
              <defs>
                <linearGradient id="colorDefect" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorYield" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} unit="%" />
              <Tooltip
                contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '12px' }}
              />
              <Area type="monotone" dataKey="defectRate" stroke="#ef4444" fillOpacity={1} fill="url(#colorDefect)" strokeWidth={2} name="Defect Rate" />
              <Area type="monotone" dataKey="yield" stroke="#3b82f6" fillOpacity={1} fill="url(#colorYield)" strokeWidth={2} name="Yield" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Severity Distribution */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Severity Distribution</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie
                data={severityDist}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={90}
                paddingAngle={3}
                dataKey="value"
                nameKey="name"
                label={({ name, percent }) => `${name} ${((percent ?? 0) * 100).toFixed(0)}%`}
                labelLine={false}
                fontSize={11}
              >
                {severityDist.map((entry, index) => (
                  <Cell key={index} fill={severityColors[entry.name] || COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Defects by Type */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Top Defect Types</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={defectByType} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis type="number" tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#94a3b8' }} width={120} />
              <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
              <Bar dataKey="value" radius={[0, 4, 4, 0]} fill="#3b82f6" name="Occurrences" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Defects by Line */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Defect Quantity by Production Line</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={defectByLine}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="line" tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
              <Bar dataKey="quantity" radius={[4, 4, 0, 0]} name="Total Defects">
                {defectByLine.map((_, index) => (
                  <Cell key={index} fill={COLORS[index % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Incidents */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-700">Recent Quality Incidents</h3>
          <button
            onClick={() => onNavigate('log')}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium"
          >
            View All →
          </button>
        </div>
        <div className="divide-y divide-slate-100">
          {defectLogs.slice(0, 6).map(log => (
            <div key={log.id} className="px-5 py-3.5 flex items-center gap-4 hover:bg-slate-50 transition-colors">
              <div className={`w-2 h-2 rounded-full shrink-0 ${
                log.severity === 'critical' ? 'bg-red-500' :
                log.severity === 'high' ? 'bg-orange-500' :
                log.severity === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
              }`} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-slate-400">{log.id}</span>
                  <span className="text-sm font-medium text-slate-800 truncate">{log.defectType}</span>
                </div>
                <p className="text-xs text-slate-500 truncate">{log.line} · {log.productType} · {log.quantity} units</p>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-xs font-medium shrink-0 ${
                log.status === 'open' ? 'bg-red-50 text-red-700' :
                log.status === 'investigating' ? 'bg-yellow-50 text-yellow-700' :
                log.status === 'resolved' ? 'bg-blue-50 text-blue-700' :
                'bg-green-50 text-green-700'
              }`}>
                {log.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
