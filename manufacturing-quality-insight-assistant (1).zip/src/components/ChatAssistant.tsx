import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Send,
  Bot,
  User,
  Sparkles,
  ChevronDown,
  Zap,
  Clock,
  Target,
  Shield,
  BarChart3,
  FileText,
  Trash2,
  MessageSquare,
  ChevronRight,
  CheckCircle2,
  AlertCircle,
  Info,
  Copy,
  Check,
} from 'lucide-react';
import { LLMModel, ChatMessage, DefectLog, QualityMetric } from '../types';
import { LLM_MODELS, generateChatResponse, getThinkingStepsForModel } from '../engine/llmEngine';
import { callRealLLM, isRealApiConfigured } from '../engine/apiClient';

interface ChatAssistantProps {
  defectLogs: DefectLog[];
  metrics: QualityMetric[];
}

const SUGGESTED_QUERIES = [
  'What could be causing surface scratches on Line-A1?',
  'Analyze the critical incidents from the past week',
  'What standards apply to solder bridge defects?',
  'Tell me about INC-1001',
  'How do I triage a contamination issue?',
  'What are common causes of dimensional deviation?',
];

function ModelSelector({
  models,
  selectedModel,
  onSelect,
}: {
  models: LLMModel[];
  selectedModel: LLMModel;
  onSelect: (model: LLMModel) => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 rounded-lg hover:border-slate-300 transition-all text-sm shadow-sm"
      >
        <span className="text-lg">{selectedModel.icon}</span>
        <span className="font-medium text-slate-700">{selectedModel.name}</span>
        <span className="text-xs text-slate-400">{selectedModel.provider}</span>
        <ChevronDown size={14} className={`text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-96 bg-white border border-slate-200 rounded-xl shadow-xl z-50 overflow-hidden">
          <div className="px-4 py-3 bg-slate-50 border-b border-slate-100">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Select AI Model</p>
          </div>
          <div className="max-h-80 overflow-y-auto">
            {models.map((model) => (
              <button
                key={model.id}
                onClick={() => {
                  onSelect(model);
                  setIsOpen(false);
                }}
                className={`w-full text-left px-4 py-3 flex items-start gap-3 hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0 ${
                  selectedModel.id === model.id ? 'bg-blue-50' : ''
                }`}
              >
                <span className="text-2xl mt-0.5">{model.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-slate-800">{model.name}</span>
                    <span className="text-xs text-slate-400">{model.provider}</span>
                    {selectedModel.id === model.id && (
                      <CheckCircle2 size={14} className="text-blue-600" />
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5 line-clamp-2">{model.description}</p>
                  <div className="flex items-center gap-3 mt-1.5">
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-green-100 text-green-700 font-medium">
                      {(model.baseAccuracy * 100).toFixed(0)}% accuracy
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-medium">
                      {model.responseSpeed}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {model.specialties.slice(0, 2).join(' · ')}
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function AccuracyGauge({ value, label, color }: { value: number; label: string; color: string }) {
  const circumference = 2 * Math.PI * 36;
  const offset = circumference - (value / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative w-20 h-20">
        <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
          <circle cx="40" cy="40" r="36" fill="none" stroke="#e2e8f0" strokeWidth="6" />
          <circle
            cx="40"
            cy="40"
            r="36"
            fill="none"
            stroke="url(#gradient)"
            strokeWidth="6"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className="transition-all duration-1000 ease-out"
          />
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={color === 'green' ? '#22c55e' : color === 'blue' ? '#3b82f6' : '#8b5cf6'} />
              <stop offset="100%" stopColor={color === 'green' ? '#16a34a' : color === 'blue' ? '#2563eb' : '#7c3aed'} />
            </linearGradient>
          </defs>
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-sm font-bold text-slate-800">{value.toFixed(1)}%</span>
        </div>
      </div>
      <span className="text-[10px] font-medium text-slate-500 uppercase tracking-wider">{label}</span>
    </div>
  );
}

function ThinkingIndicator({ model }: { model: LLMModel }) {
  const [step, setStep] = useState(0);
  const steps = getThinkingStepsForModel(model.id);

  useEffect(() => {
    const interval = setInterval(() => {
      setStep((prev) => (prev + 1) % steps.length);
    }, 600);
    return () => clearInterval(interval);
  }, [steps.length]);

  return (
    <div className="flex items-start gap-3 px-4 py-3">
      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shrink-0">
        <Bot size={16} className="text-white" />
      </div>
      <div className="flex-1 bg-white border border-slate-200 rounded-2xl rounded-tl-sm p-4 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-sm">{model.icon}</span>
          <span className="text-xs font-medium text-slate-600">{model.name}</span>
          <span className="text-xs text-slate-400">is thinking...</span>
          <div className="flex gap-1 ml-2">
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        </div>
        <div className="space-y-1.5">
          {steps.slice(0, step + 1).map((s, i) => (
            <div key={i} className="flex items-center gap-2 text-xs">
              {i < step ? (
                <CheckCircle2 size={12} className="text-green-500 shrink-0" />
              ) : (
                <div className="w-3 h-3 border-2 border-blue-500 border-t-transparent rounded-full animate-spin shrink-0" />
              )}
              <span className={i < step ? 'text-slate-500' : 'text-slate-700 font-medium'}>{s}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MessageBubble({
  message,
  model,
}: {
  message: ChatMessage;
  model?: LLMModel;
}) {
  const [copied, setCopied] = useState(false);
  const [showMeta, setShowMeta] = useState(false);
  const [showThinking, setShowThinking] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const renderMarkdown = (text: string) => {
    let html = text;
    // Headers
    html = html.replace(/^### (.+)$/gm, '<h3 class="text-sm font-bold text-slate-800 mt-3 mb-1">$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2 class="text-base font-bold text-slate-800 mt-3 mb-1">$1</h2>');
    // Bold
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong class="font-semibold text-slate-800">$1</strong>');
    // Italic
    html = html.replace(/\*(.+?)\*/g, '<em class="text-slate-600">$1</em>');
    // Blockquotes
    html = html.replace(/^> (.+)$/gm, '<blockquote class="border-l-2 border-blue-300 pl-3 py-1 my-2 text-sm text-slate-600 bg-blue-50/50 rounded-r">$1</blockquote>');
    // Code
    html = html.replace(/`(.+?)`/g, '<code class="px-1.5 py-0.5 bg-slate-100 rounded text-xs font-mono text-slate-700">$1</code>');
    // Horizontal rule
    html = html.replace(/^---$/gm, '<hr class="my-3 border-slate-200" />');
    // Line breaks
    html = html.replace(/\n/g, '<br />');
    return html;
  };

  if (message.role === 'user') {
    return (
      <div className="flex items-start gap-3 justify-end px-4 py-2">
        <div className="max-w-[75%] bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-2xl rounded-br-sm px-4 py-3 shadow-md">
          <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
          <p className="text-[10px] text-blue-200 mt-1.5 text-right">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </p>
        </div>
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center shrink-0">
          <User size={16} className="text-white" />
        </div>
      </div>
    );
  }

  const msgModel = model || LLM_MODELS.find(m => m.id === message.modelId) || LLM_MODELS[0];

  return (
    <div className="flex items-start gap-3 px-4 py-2">
      <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${msgModel.color} flex items-center justify-center shrink-0 shadow-md`}>
        <Bot size={16} className="text-white" />
      </div>
      <div className="flex-1 max-w-[85%]">
        <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm shadow-sm overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-2 bg-slate-50 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <span className="text-sm">{msgModel.icon}</span>
              <span className="text-xs font-semibold text-slate-700">{msgModel.name}</span>
              <span className="text-[10px] text-slate-400">{msgModel.provider}</span>
            </div>
            <div className="flex items-center gap-1">
              <button onClick={handleCopy} className="p-1 rounded hover:bg-slate-200 text-slate-400 hover:text-slate-600 transition-colors" title="Copy">
                {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
              </button>
              <button onClick={() => setShowMeta(!showMeta)} className={`p-1 rounded transition-colors ${showMeta ? 'bg-blue-100 text-blue-600' : 'hover:bg-slate-200 text-slate-400 hover:text-slate-600'}`} title="Show metadata">
                <BarChart3 size={14} />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="px-4 py-3">
            <div
              className="text-sm text-slate-700 leading-relaxed prose prose-sm max-w-none"
              dangerouslySetInnerHTML={{ __html: renderMarkdown(message.content) }}
            />
          </div>

          {/* Thinking Steps (collapsible) */}
          {message.thinkingSteps && message.thinkingSteps.length > 0 && (
            <div className="border-t border-slate-100">
              <button
                onClick={() => setShowThinking(!showThinking)}
                className="w-full flex items-center gap-2 px-4 py-2 text-xs text-slate-500 hover:bg-slate-50 transition-colors"
              >
                <Sparkles size={12} />
                <span>Thinking Process ({message.thinkingSteps.length} steps)</span>
                <ChevronRight size={12} className={`transition-transform ${showThinking ? 'rotate-90' : ''}`} />
              </button>
              {showThinking && (
                <div className="px-4 pb-3 space-y-1">
                  {message.thinkingSteps.map((step, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-slate-500">
                      <CheckCircle2 size={11} className="text-green-500 shrink-0" />
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Sources (collapsible) */}
          {message.sources && message.sources.length > 0 && (
            <div className="border-t border-slate-100 px-4 py-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <FileText size={11} />
                <span>Sources: {message.sources.join(' · ')}</span>
              </div>
            </div>
          )}

          {/* Timestamp */}
          <div className="px-4 py-1.5 text-[10px] text-slate-400 text-right">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>

        {/* Metadata Panel */}
        {showMeta && message.accuracy !== undefined && (
          <div className="mt-2 bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="px-4 py-2 bg-slate-50 border-b border-slate-100">
              <p className="text-xs font-semibold text-slate-600">Response Metadata</p>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-center gap-6 mb-4">
                <AccuracyGauge value={message.accuracy} label="Accuracy" color="green" />
                <AccuracyGauge value={message.confidence || 0} label="Confidence" color="blue" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-lg">
                  <Clock size={14} className="text-slate-400" />
                  <div>
                    <p className="text-[10px] text-slate-400">Response Time</p>
                    <p className="text-xs font-semibold text-slate-700">{message.responseTime}ms</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-lg">
                  <Target size={14} className="text-slate-400" />
                  <div>
                    <p className="text-[10px] text-slate-400">Tokens</p>
                    <p className="text-xs font-semibold text-slate-700">{message.tokensUsed}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-lg">
                  <Zap size={14} className="text-slate-400" />
                  <div>
                    <p className="text-[10px] text-slate-400">Speed</p>
                    <p className="text-xs font-semibold text-slate-700 capitalize">{msgModel.responseSpeed}</p>
                  </div>
                </div>
              </div>

              {/* Accuracy Breakdown */}
              <div className="mt-3 space-y-2">
                <p className="text-xs font-medium text-slate-600">Accuracy Breakdown</p>
                <div className="space-y-1.5">
                  {[
                    { label: 'Domain Relevance', value: Math.min(message.accuracy + 2, 99), color: 'bg-green-500' },
                    { label: 'Data Consistency', value: Math.min(message.accuracy - 1, 98), color: 'bg-blue-500' },
                    { label: 'Contextual Match', value: Math.min(message.accuracy - 3, 96), color: 'bg-purple-500' },
                    { label: 'Historical Correlation', value: Math.min(message.accuracy - 5, 94), color: 'bg-amber-500' },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-500 w-32 shrink-0">{item.label}</span>
                      <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${item.color} rounded-full transition-all duration-1000`}
                          style={{ width: `${item.value}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-medium text-slate-600 w-10 text-right">{item.value.toFixed(1)}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ChatAssistant({ defectLogs, metrics }: ChatAssistantProps) {
  const [selectedModel, setSelectedModel] = useState<LLMModel>(LLM_MODELS[0]);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `Welcome to the **QualityGuard AI Chat Assistant**! 🛡️

I'm powered by multiple AI models to help you analyze quality incidents, identify root causes, and get actionable recommendations.

**How to get started:**
- Select an AI model from the dropdown above
- Type your question or select a suggested query below
- View accuracy scores and confidence metrics for each response
- Click the chart icon on any response to see detailed metadata

I have access to your current plant data including **${defectLogs.length} defect logs** and quality metrics across **5 production lines**.`,
      timestamp: new Date().toISOString(),
      modelId: 'qualityguard-custom',
      accuracy: 99.0,
      confidence: 98.5,
      sources: ['QualityGuard AI System'],
      thinkingSteps: ['System initialized', 'Plant data loaded', 'Ready for queries'],
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = useCallback(async (query?: string) => {
    const text = query || inputValue.trim();
    if (!text || isTyping) return;

    setShowSuggestions(false);

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    try {
      let response;

      // Use real API if configured, otherwise use simulated responses
      if (isRealApiConfigured()) {
        response = await callRealLLM(
          text,
          defectLogs,
          metrics,
          messages
        );
      } else {
        response = await generateChatResponse(
          text,
          selectedModel.id,
          defectLogs,
          metrics,
          messages
        );
      }

      const assistantMessage: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: response.content,
        timestamp: new Date().toISOString(),
        modelId: selectedModel.id,
        accuracy: response.accuracy,
        confidence: response.confidence,
        responseTime: response.responseTime,
        tokensUsed: response.tokensUsed,
        sources: response.sources,
        thinkingSteps: response.thinkingSteps,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      const isApiError = isRealApiConfigured();
      const errorMessage: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: isApiError
          ? `⚠️ **API Error:** ${errorMsg}\n\nPlease check your API configuration in Settings or switch to simulated mode.`
          : '⚠️ I encountered an error processing your request. Please try again or select a different model.',
        timestamp: new Date().toISOString(),
        modelId: selectedModel.id,
        accuracy: 0,
        confidence: 0,
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  }, [inputValue, isTyping, selectedModel, defectLogs, metrics, messages]);

  const handleClearChat = () => {
    setMessages([
      {
        id: 'welcome-new',
        role: 'assistant',
        content: `Chat cleared! 🧹 Ready for a fresh analysis. What quality incident would you like to investigate?`,
        timestamp: new Date().toISOString(),
        modelId: selectedModel.id,
        accuracy: 99.0,
        confidence: 98.5,
        sources: ['QualityGuard AI System'],
      },
    ]);
    setShowSuggestions(true);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] bg-gradient-to-br from-slate-50 to-blue-50/30 rounded-2xl border border-slate-200 overflow-hidden shadow-lg">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3 bg-white border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <MessageSquare size={20} className="text-white" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-800">AI Chat Assistant</h2>
            <p className="text-[10px] text-slate-400">Multi-model quality incident analysis</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <ModelSelector
            models={LLM_MODELS}
            selectedModel={selectedModel}
            onSelect={setSelectedModel}
          />
          {isRealApiConfigured() && (
            <div className="flex items-center gap-1 px-2 py-1 bg-green-50 border border-green-200 rounded-full">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              <span className="text-[10px] font-medium text-green-700">Live API</span>
            </div>
          )}
          <button
            onClick={handleClearChat}
            className="p-2 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-all"
            title="Clear chat"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      {/* Model Info Bar */}
      <div className="flex items-center gap-4 px-5 py-2 bg-gradient-to-r from-slate-50 to-blue-50/50 border-b border-slate-100">
        <div className="flex items-center gap-1.5">
          <Shield size={12} className="text-blue-500" />
          <span className="text-[10px] text-slate-500">Model:</span>
          <span className="text-[10px] font-semibold text-slate-700">{selectedModel.name}</span>
        </div>
        <div className="w-px h-3 bg-slate-200" />
        <div className="flex items-center gap-1.5">
          <Target size={12} className="text-green-500" />
          <span className="text-[10px] text-slate-500">Base Accuracy:</span>
          <span className="text-[10px] font-semibold text-green-600">{(selectedModel.baseAccuracy * 100).toFixed(0)}%</span>
        </div>
        <div className="w-px h-3 bg-slate-200" />
        <div className="flex items-center gap-1.5">
          <Zap size={12} className="text-amber-500" />
          <span className="text-[10px] text-slate-500">Speed:</span>
          <span className="text-[10px] font-semibold text-amber-600 capitalize">{selectedModel.responseSpeed}</span>
        </div>
        <div className="w-px h-3 bg-slate-200" />
        <div className="flex items-center gap-1.5">
          <Sparkles size={12} className="text-purple-500" />
          <span className="text-[10px] text-slate-500">Specialties:</span>
          <span className="text-[10px] text-slate-600">{selectedModel.specialties.slice(0, 2).join(', ')}</span>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto py-4 space-y-1">
        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} model={selectedModel} />
        ))}

        {isTyping && <ThinkingIndicator model={selectedModel} />}

        {/* Suggested Queries */}
        {showSuggestions && !isTyping && (
          <div className="px-4 py-3">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={14} className="text-blue-500" />
              <span className="text-xs font-medium text-slate-600">Suggested Queries</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {SUGGESTED_QUERIES.map((query, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(query)}
                  className="text-left px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-600 hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700 transition-all group"
                >
                  <div className="flex items-center gap-2">
                    <Info size={12} className="text-slate-300 group-hover:text-blue-400 shrink-0" />
                    <span className="line-clamp-2">{query}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-slate-200 bg-white px-4 py-3">
        <div className="flex items-end gap-3">
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask about quality incidents, root causes, defect analysis..."
              className="w-full px-4 py-3 pr-12 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-700 placeholder-slate-400 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition-all"
              rows={2}
              disabled={isTyping}
            />
            <div className="absolute right-2 bottom-2 text-[10px] text-slate-300">
              {inputValue.length > 0 && `${inputValue.length} chars`}
            </div>
          </div>
          <button
            onClick={() => handleSend()}
            disabled={!inputValue.trim() || isTyping}
            className="p-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl hover:from-blue-700 hover:to-blue-800 disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30 active:scale-95"
          >
            {isTyping ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Send size={20} />
            )}
          </button>
        </div>
        <div className="flex items-center justify-between mt-2 px-1">
          <div className="flex items-center gap-1.5">
            <AlertCircle size={11} className="text-slate-300" />
            <span className="text-[10px] text-slate-400">
              Responses are AI-generated. Verify critical decisions with domain experts.
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-slate-400">Press</span>
            <kbd className="px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded text-[10px] text-slate-500 font-mono">Enter</kbd>
            <span className="text-[10px] text-slate-400">to send</span>
          </div>
        </div>
      </div>
    </div>
  );
}
