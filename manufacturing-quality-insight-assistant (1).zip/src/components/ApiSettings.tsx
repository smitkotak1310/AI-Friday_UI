import { useState, useEffect } from 'react';
import {
  Settings,
  Key,
  Globe,
  Cpu,
  Thermometer,
  FileText,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Eye,
  EyeOff,
  Save,
  RotateCcw,
  Zap,
  Shield,
  Info,
  Copy,
  Check,
  ArrowRight,
} from 'lucide-react';
import { API_CONFIG } from '../config/apiConfig';
import { isRealApiConfigured } from '../engine/apiClient';

const PROVIDERS = [
  {
    id: 'openai',
    name: 'OpenAI',
    icon: '🟢',
    defaultUrl: 'https://api.openai.com/v1',
    defaultModel: 'gpt-4o',
    description: 'Industry-leading models with strong reasoning capabilities',
    models: ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo', 'o1-preview', 'o1-mini'],
  },
  {
    id: 'anthropic',
    name: 'Anthropic',
    icon: '🟣',
    defaultUrl: 'https://api.anthropic.com',
    defaultModel: 'claude-3-5-sonnet-20241022',
    description: 'Claude models with exceptional analytical reasoning',
    models: ['claude-3-5-sonnet-20241022', 'claude-3-opus-20240229', 'claude-3-haiku-20240307'],
  },
  {
    id: 'groq',
    name: 'Groq',
    icon: '🟠',
    defaultUrl: 'https://api.groq.com/openai/v1',
    defaultModel: 'llama-3.3-70b-versatile',
    description: 'Ultra-fast inference with open-source models',
    models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'mixtral-8x7b-32768', 'gemma2-9b-it'],
  },
  {
    id: 'azure',
    name: 'Azure OpenAI',
    icon: '🔵',
    defaultUrl: 'https://your-resource.openai.azure.com/openai',
    defaultModel: 'gpt-4o',
    description: 'Enterprise-grade OpenAI models on Azure cloud',
    models: ['gpt-4o', 'gpt-4', 'gpt-35-turbo'],
  },
  {
    id: 'ollama',
    name: 'Ollama (Local)',
    icon: '🦙',
    defaultUrl: 'http://localhost:11434',
    defaultModel: 'llama3',
    description: 'Run models locally — no API key needed, fully private',
    models: ['llama3', 'llama3.1', 'mistral', 'phi3', 'gemma2', 'codellama'],
  },
  {
    id: 'custom',
    name: 'Custom API',
    icon: '⚙️',
    defaultUrl: 'https://your-api-endpoint.com/v1',
    defaultModel: '',
    description: 'Any OpenAI-compatible API endpoint',
    models: [],
  },
];

export default function ApiSettings() {
  const [apiKey, setApiKey] = useState('');
  const [baseUrl, setBaseUrl] = useState('');
  const [model, setModel] = useState('');
  const [temperature, setTemperature] = useState(0.3);
  const [maxTokens, setMaxTokens] = useState(2048);
  const [enabled, setEnabled] = useState(false);
  const [provider, setProvider] = useState<string>('openai');
  const [showApiKey, setShowApiKey] = useState(false);
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState(false);
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [testError, setTestError] = useState('');

  // Load current config on mount
  useEffect(() => {
    setApiKey(API_CONFIG.apiKey);
    setBaseUrl(API_CONFIG.baseUrl);
    setModel(API_CONFIG.model);
    setTemperature(API_CONFIG.temperature);
    setMaxTokens(API_CONFIG.maxTokens);
    setEnabled(API_CONFIG.enabled);
    setProvider(API_CONFIG.provider);
  }, []);

  const selectedProvider = PROVIDERS.find(p => p.id === provider) || PROVIDERS[0];

  const handleProviderChange = (newProvider: string) => {
    setProvider(newProvider);
    const p = PROVIDERS.find(pr => pr.id === newProvider);
    if (p) {
      setBaseUrl(p.defaultUrl);
      setModel(p.defaultModel);
    }
  };

  const handleSave = () => {
    // Generate the config code for the user to copy
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleReset = () => {
    setApiKey('');
    setBaseUrl('');
    setModel('gpt-4o');
    setTemperature(0.3);
    setMaxTokens(2048);
    setEnabled(false);
    setProvider('openai');
  };

  const handleTestConnection = async () => {
    setTestStatus('testing');
    setTestError('');

    try {
      if (!baseUrl) {
        throw new Error('Base URL is required');
      }
      if (!apiKey && provider !== 'ollama') {
        throw new Error('API key is required for this provider');
      }

      let url = baseUrl;
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };

      if (provider === 'anthropic') {
        url = `${baseUrl}/v1/messages`;
        headers['x-api-key'] = apiKey;
        headers['anthropic-version'] = '2023-06-01';
      } else if (provider === 'azure') {
        url = `${baseUrl}/deployments/${model}/chat/completions?api-version=2024-06-01`;
        headers['api-key'] = apiKey;
      } else if (provider === 'ollama') {
        url = `${baseUrl}/api/generate`;
      } else {
        url = `${baseUrl}/chat/completions`;
        if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;
      }

      let body: Record<string, unknown>;
      if (provider === 'anthropic') {
        body = {
          model: model,
          max_tokens: 50,
          messages: [{ role: 'user', content: 'Say hello' }],
        };
      } else if (provider === 'ollama') {
        body = {
          model: model,
          prompt: 'Say hello',
          stream: false,
        };
      } else {
        body = {
          model: model,
          messages: [{ role: 'user', content: 'Say hello' }],
          max_tokens: 50,
        };
      }

      const response = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText.substring(0, 200)}`);
      }

      setTestStatus('success');
    } catch (err) {
      setTestStatus('error');
      setTestError(err instanceof Error ? err.message : 'Unknown error');
    }
  };

  const generateConfigCode = () => {
    return `export const API_CONFIG = {
  apiKey: '${apiKey}',
  baseUrl: '${baseUrl}',
  model: '${model}',
  temperature: ${temperature},
  maxTokens: ${maxTokens},
  enabled: ${enabled},
  provider: '${provider}' as 'openai' | 'anthropic' | 'custom' | 'ollama' | 'azure' | 'groq',
};`;
  };

  const handleCopyConfig = () => {
    navigator.clipboard.writeText(generateConfigCode());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isConfigured = enabled && baseUrl && (provider === 'ollama' || apiKey);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-2">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center shadow-lg">
          <Settings size={24} className="text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-slate-800">API Configuration</h1>
          <p className="text-sm text-slate-500">Connect your own LLM provider for real AI responses</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {isConfigured ? (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 border border-green-200 rounded-full">
              <CheckCircle2 size={14} className="text-green-600" />
              <span className="text-xs font-medium text-green-700">Connected</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-full">
              <AlertTriangle size={14} className="text-amber-600" />
              <span className="text-xs font-medium text-amber-700">Not Connected</span>
            </div>
          )}
        </div>
      </div>

      {/* Status Banner */}
      {isRealApiConfigured() ? (
        <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-xl">
          <CheckCircle2 size={20} className="text-green-600 shrink-0" />
          <div>
            <p className="text-sm font-semibold text-green-800">Real API is Active</p>
            <p className="text-xs text-green-600">
              Chat responses are powered by <strong>{API_CONFIG.provider}</strong> using model <strong>{API_CONFIG.model}</strong>
            </p>
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-xl">
          <Info size={20} className="text-blue-600 shrink-0" />
          <div>
            <p className="text-sm font-semibold text-blue-800">Using Simulated Responses</p>
            <p className="text-xs text-blue-600">
              Configure your API key and base URL below, then update <code className="px-1 py-0.5 bg-blue-100 rounded text-xs font-mono">src/config/apiConfig.ts</code> to enable real LLM calls.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Configuration Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Provider Selection */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
              <Cpu size={16} className="text-slate-500" />
              <span className="text-sm font-semibold text-slate-700">Select Provider</span>
            </div>
            <div className="p-5">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {PROVIDERS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleProviderChange(p.id)}
                    className={`p-3 rounded-xl border-2 transition-all text-left ${
                      provider === p.id
                        ? 'border-blue-500 bg-blue-50 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xl">{p.icon}</span>
                      <span className="text-sm font-semibold text-slate-800">{p.name}</span>
                    </div>
                    <p className="text-[10px] text-slate-500 line-clamp-2">{p.description}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Connection Details */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
              <Globe size={16} className="text-slate-500" />
              <span className="text-sm font-semibold text-slate-700">Connection Details</span>
            </div>
            <div className="p-5 space-y-4">
              {/* API Key */}
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-slate-700 mb-1.5">
                  <Key size={14} className="text-slate-400" />
                  API Key
                  {provider === 'ollama' && <span className="text-xs text-slate-400 font-normal">(not required for Ollama)</span>}
                </label>
                <div className="relative">
                  <input
                    type={showApiKey ? 'text' : 'password'}
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder={provider === 'ollama' ? 'Not needed for local Ollama' : 'sk-... or gsk_...'}
                    className="w-full px-4 py-2.5 pr-20 bg-slate-50 border border-slate-200 rounded-lg text-sm font-mono text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition-all"
                  />
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                    <button
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="p-1 rounded hover:bg-slate-200 text-slate-400 transition-colors"
                    >
                      {showApiKey ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Base URL */}
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-slate-700 mb-1.5">
                  <Globe size={14} className="text-slate-400" />
                  Base URL
                </label>
                <input
                  type="text"
                  value={baseUrl}
                  onChange={(e) => setBaseUrl(e.target.value)}
                  placeholder="https://api.example.com/v1"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm font-mono text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition-all"
                />
              </div>

              {/* Model */}
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-slate-700 mb-1.5">
                  <Cpu size={14} className="text-slate-400" />
                  Model
                </label>
                {selectedProvider.models.length > 0 ? (
                  <select
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition-all"
                  >
                    {selectedProvider.models.map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder="Enter model name"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm font-mono text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition-all"
                  />
                )}
              </div>

              {/* Temperature & Max Tokens */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-slate-700 mb-1.5">
                    <Thermometer size={14} className="text-slate-400" />
                    Temperature
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={temperature}
                      onChange={(e) => setTemperature(parseFloat(e.target.value))}
                      className="flex-1 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                    />
                    <span className="text-sm font-mono text-slate-700 w-10 text-right">{temperature.toFixed(1)}</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    {temperature <= 0.3 ? 'Deterministic (focused)' : temperature <= 0.7 ? 'Balanced' : 'Creative (varied)'}
                  </p>
                </div>
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-slate-700 mb-1.5">
                    <FileText size={14} className="text-slate-400" />
                    Max Tokens
                  </label>
                  <input
                    type="number"
                    value={maxTokens}
                    onChange={(e) => setMaxTokens(parseInt(e.target.value) || 0)}
                    min={100}
                    max={8192}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm font-mono text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition-all"
                  />
                </div>
              </div>

              {/* Enable Toggle */}
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Zap size={16} className={enabled ? 'text-green-600' : 'text-slate-400'} />
                  <span className="text-sm font-medium text-slate-700">Enable Real API Calls</span>
                </div>
                <button
                  onClick={() => setEnabled(!enabled)}
                  className={`relative w-12 h-6 rounded-full transition-colors ${
                    enabled ? 'bg-green-500' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                      enabled ? 'translate-x-6' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <button
              onClick={handleTestConnection}
              disabled={testStatus === 'testing'}
              className="flex items-center gap-2 px-5 py-2.5 bg-white border border-slate-200 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-all disabled:opacity-50"
            >
              {testStatus === 'testing' ? (
                <div className="w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" />
              ) : testStatus === 'success' ? (
                <CheckCircle2 size={16} className="text-green-600" />
              ) : testStatus === 'error' ? (
                <XCircle size={16} className="text-red-600" />
              ) : (
                <Zap size={16} />
              )}
              {testStatus === 'testing' ? 'Testing...' : testStatus === 'success' ? 'Connected!' : testStatus === 'error' ? 'Failed' : 'Test Connection'}
            </button>

            {testStatus === 'error' && testError && (
              <span className="text-xs text-red-500 max-w-xs truncate">{testError}</span>
            )}

            <div className="flex-1" />

            <button
              onClick={handleReset}
              className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-500 hover:text-slate-700 transition-colors"
            >
              <RotateCcw size={14} />
              Reset
            </button>

            <button
              onClick={handleSave}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg text-sm font-medium hover:from-blue-700 hover:to-blue-800 transition-all shadow-md"
            >
              {saved ? <Check size={16} /> : <Save size={16} />}
              {saved ? 'Copied!' : 'Generate Config'}
            </button>
          </div>
        </div>

        {/* Right Column: Config Preview & Instructions */}
        <div className="space-y-6">
          {/* Config Code Preview */}
          <div className="bg-slate-900 rounded-xl shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 bg-slate-800 border-b border-slate-700">
              <span className="text-xs font-mono text-slate-400">src/config/apiConfig.ts</span>
              <button
                onClick={handleCopyConfig}
                className="flex items-center gap-1 px-2 py-1 rounded text-xs text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
              >
                {copied ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
                {copied ? 'Copied!' : 'Copy'}
              </button>
            </div>
            <div className="p-4">
              <pre className="text-xs font-mono text-green-400 overflow-x-auto whitespace-pre-wrap break-all leading-relaxed">
                {generateConfigCode()}
              </pre>
            </div>
          </div>

          {/* How to Apply */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-slate-50 border-b border-slate-100">
              <span className="text-sm font-semibold text-slate-700">How to Apply</span>
            </div>
            <div className="p-5 space-y-4">
              {[
                { step: 1, title: 'Configure Above', desc: 'Select your provider, enter API key and base URL' },
                { step: 2, title: 'Copy Config', desc: 'Click "Generate Config" to copy the code' },
                { step: 3, title: 'Update File', desc: 'Paste into src/config/apiConfig.ts' },
                { step: 4, title: 'Rebuild', desc: 'Run npm run build to apply changes' },
              ].map((item) => (
                <div key={item.step} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold shrink-0">
                    {item.step}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-800">{item.title}</p>
                    <p className="text-xs text-slate-500">{item.desc}</p>
                  </div>
                  {item.step < 4 && <ArrowRight size={12} className="text-slate-300 mt-1.5 ml-auto shrink-0" />}
                </div>
              ))}
            </div>
          </div>

          {/* Security Note */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
            <div className="flex items-start gap-2">
              <Shield size={16} className="text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-amber-800">Security Note</p>
                <p className="text-xs text-amber-700 mt-1">
                  API keys are stored in the config file. For production use, consider using environment variables or a backend proxy to keep keys secure.
                </p>
              </div>
            </div>
          </div>

          {/* Provider Quick Info */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-slate-50 border-b border-slate-100">
              <span className="text-sm font-semibold text-slate-700">Provider Info</span>
            </div>
            <div className="p-5 space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{selectedProvider.icon}</span>
                <div>
                  <p className="text-sm font-bold text-slate-800">{selectedProvider.name}</p>
                  <p className="text-xs text-slate-500">{selectedProvider.description}</p>
                </div>
              </div>
              <div className="pt-2 border-t border-slate-100">
                <p className="text-xs font-medium text-slate-600 mb-1">Available Models:</p>
                {selectedProvider.models.length > 0 ? (
                  <div className="flex flex-wrap gap-1">
                    {selectedProvider.models.map((m) => (
                      <span key={m} className="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-mono text-slate-600">
                        {m}
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">Enter any model name manually</p>
                )}
              </div>
              <div className="pt-2 border-t border-slate-100">
                <p className="text-xs font-medium text-slate-600 mb-1">Default URL:</p>
                <code className="text-[10px] font-mono text-slate-500 bg-slate-50 px-2 py-1 rounded block break-all">
                  {selectedProvider.defaultUrl}
                </code>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
