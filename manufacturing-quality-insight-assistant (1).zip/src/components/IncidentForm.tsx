import { useState, useMemo } from 'react';
import {
  AlertTriangle,
  Factory,
  Package,
  Clock,
  FileText,
  Hash,
  Send,
  Loader2,
  Thermometer,
  Gauge,
  Droplets,
  Zap,
  Activity,
  Battery,
} from 'lucide-react';
import { IncidentInput, ProcessParameter, DefectLog, QualityMetric, AnalysisResult } from '../types';
import { DEFECT_TYPE_OPTIONS, LINE_OPTIONS, PRODUCT_OPTIONS } from '../data/syntheticData';
import { analyzeIncident } from '../engine/analysisEngine';

interface IncidentFormProps {
  defectLogs: DefectLog[];
  metrics: QualityMetric[];
  onAnalysisComplete: (result: AnalysisResult) => void;
}

const paramIcons: Record<string, React.ReactNode> = {
  'Temperature': <Thermometer size={16} />,
  'Pressure': <Gauge size={16} />,
  'Humidity': <Droplets size={16} />,
  'Line Speed': <Zap size={16} />,
  'Vibration': <Activity size={16} />,
  'Voltage': <Battery size={16} />,
};

export default function IncidentForm({ defectLogs, metrics, onAnalysisComplete }: IncidentFormProps) {
  const [defectType, setDefectType] = useState('');
  const [productionLine, setProductionLine] = useState('');
  const [productType, setProductType] = useState('');
  const [severity, setSeverity] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');
  const [timeRange, setTimeRange] = useState('last-24h');
  const [description, setDescription] = useState('');
  const [affectedQuantity, setAffectedQuantity] = useState(25);
  const [processParams, setProcessParams] = useState<ProcessParameter[]>([
    { name: 'Temperature', value: 24.5, unit: '°C', lowerLimit: 20, upperLimit: 30, status: 'normal' },
    { name: 'Pressure', value: 1.8, unit: 'bar', lowerLimit: 1.2, upperLimit: 2.5, status: 'normal' },
    { name: 'Humidity', value: 52, unit: '%RH', lowerLimit: 35, upperLimit: 65, status: 'normal' },
    { name: 'Line Speed', value: 65, unit: 'units/min', lowerLimit: 40, upperLimit: 85, status: 'normal' },
    { name: 'Vibration', value: 1.2, unit: 'mm/s', lowerLimit: 0, upperLimit: 2.0, status: 'normal' },
    { name: 'Voltage', value: 228, unit: 'V', lowerLimit: 210, upperLimit: 240, status: 'normal' },
  ]);
  const [analyzing, setAnalyzing] = useState(false);

  const updateParam = (name: string, value: number) => {
    setProcessParams(prev =>
      prev.map(p => {
        if (p.name !== name) return p;
        const status = value < p.lowerLimit || value > p.upperLimit ? 'critical' :
                      value < p.lowerLimit * 1.05 || value > p.upperLimit * 0.95 ? 'warning' : 'normal';
        return { ...p, value, status };
      })
    );
  };

  const handleSubmit = async () => {
    if (!defectType || !productionLine || !productType) return;
    setAnalyzing(true);

    // Simulate analysis delay
    await new Promise(r => setTimeout(r, 1500));

    const input: IncidentInput = {
      defectType,
      productionLine,
      productType,
      severity,
      timeRange,
      description,
      affectedQuantity,
      processParameters: processParams,
    };

    const result = analyzeIncident(input, defectLogs, metrics);
    setAnalyzing(false);
    onAnalysisComplete(result);
  };

  const canSubmit = defectType && productionLine && productType;

  const paramStatusCounts = useMemo(() => ({
    normal: processParams.filter(p => p.status === 'normal').length,
    warning: processParams.filter(p => p.status === 'warning').length,
    critical: processParams.filter(p => p.status === 'critical').length,
  }), [processParams]);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Analyze Quality Incident</h2>
        <p className="text-slate-500 text-sm mt-1">Enter incident details to receive AI-powered root cause analysis and recommendations</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Incident Details */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
            <h3 className="text-sm font-semibold text-slate-700 mb-5 flex items-center gap-2">
              <AlertTriangle size={16} className="text-orange-500" />
              Incident Details
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 flex items-center gap-1.5">
                  <FileText size={13} /> Defect Type *
                </label>
                <select
                  value={defectType}
                  onChange={e => setDefectType(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                >
                  <option value="">Select defect type...</option>
                  {DEFECT_TYPE_OPTIONS.map(dt => <option key={dt} value={dt}>{dt}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 flex items-center gap-1.5">
                  <Factory size={13} /> Production Line *
                </label>
                <select
                  value={productionLine}
                  onChange={e => setProductionLine(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                >
                  <option value="">Select line...</option>
                  {LINE_OPTIONS.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 flex items-center gap-1.5">
                  <Package size={13} /> Product Type *
                </label>
                <select
                  value={productType}
                  onChange={e => setProductType(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                >
                  <option value="">Select product...</option>
                  {PRODUCT_OPTIONS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 flex items-center gap-1.5">
                  <AlertTriangle size={13} /> Severity
                </label>
                <select
                  value={severity}
                  onChange={e => setSeverity(e.target.value as typeof severity)}
                  className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="critical">Critical</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 flex items-center gap-1.5">
                  <Clock size={13} /> Time Range
                </label>
                <select
                  value={timeRange}
                  onChange={e => setTimeRange(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                >
                  <option value="last-4h">Last 4 Hours</option>
                  <option value="last-12h">Last 12 Hours</option>
                  <option value="last-24h">Last 24 Hours</option>
                  <option value="last-7d">Last 7 Days</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 flex items-center gap-1.5">
                  <Hash size={13} /> Affected Quantity
                </label>
                <input
                  type="number"
                  value={affectedQuantity}
                  onChange={e => setAffectedQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                />
              </div>
            </div>
            <div className="mt-4">
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Additional Description</label>
              <textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                rows={3}
                placeholder="Describe the incident, observations, or any relevant context..."
                className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all resize-none"
              />
            </div>
          </div>

          {/* Process Parameters */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                <Activity size={16} className="text-blue-500" />
                Process Parameters
              </h3>
              <div className="flex gap-3 text-xs">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500" /> {paramStatusCounts.normal} Normal</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-yellow-500" /> {paramStatusCounts.warning} Warning</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500" /> {paramStatusCounts.critical} Critical</span>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {processParams.map(param => (
                <div key={param.name} className={`p-3 rounded-lg border transition-all ${
                  param.status === 'critical' ? 'border-red-300 bg-red-50' :
                  param.status === 'warning' ? 'border-yellow-300 bg-yellow-50' :
                  'border-slate-200 bg-slate-50'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-slate-600 flex items-center gap-1.5">
                      {paramIcons[param.name]} {param.name}
                    </span>
                    <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${
                      param.status === 'critical' ? 'bg-red-100 text-red-700' :
                      param.status === 'warning' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {param.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="range"
                      min={param.lowerLimit * 0.7}
                      max={param.upperLimit * 1.3}
                      step={param.unit === '°C' || param.unit === '%RH' || param.unit === 'V' ? 0.5 : 0.05}
                      value={param.value}
                      onChange={e => updateParam(param.name, parseFloat(e.target.value))}
                      className="flex-1 h-1.5 accent-blue-600"
                    />
                    <span className="text-sm font-mono font-medium text-slate-800 w-16 text-right">
                      {param.value}{param.unit}
                    </span>
                  </div>
                  <div className="flex justify-between mt-1 text-[10px] text-slate-400">
                    <span>{param.lowerLimit}{param.unit}</span>
                    <span>Spec: {param.lowerLimit}–{param.upperLimit}{param.unit}</span>
                    <span>{param.upperLimit}{param.unit}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar Summary */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 sticky top-6">
            <h3 className="text-sm font-semibold text-slate-700 mb-4">Incident Summary</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">Defect</span>
                <span className="font-medium text-slate-800 truncate ml-2">{defectType || '—'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Line</span>
                <span className="font-medium text-slate-800">{productionLine || '—'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Product</span>
                <span className="font-medium text-slate-800 truncate ml-2">{productType || '—'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Severity</span>
                <span className={`font-medium px-2 py-0.5 rounded text-xs ${
                  severity === 'critical' ? 'bg-red-100 text-red-700' :
                  severity === 'high' ? 'bg-orange-100 text-orange-700' :
                  severity === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-green-100 text-green-700'
                }`}>{severity}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Qty Affected</span>
                <span className="font-medium text-slate-800">{affectedQuantity}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Param Alerts</span>
                <span className={`font-medium ${paramStatusCounts.critical > 0 ? 'text-red-600' : paramStatusCounts.warning > 0 ? 'text-yellow-600' : 'text-green-600'}`}>
                  {paramStatusCounts.critical + paramStatusCounts.warning} alert(s)
                </span>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100">
              <button
                onClick={handleSubmit}
                disabled={!canSubmit || analyzing}
                className={`w-full py-3 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all ${
                  canSubmit && !analyzing
                    ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-600/20'
                    : 'bg-slate-200 text-slate-500 cursor-not-allowed'
                }`}
              >
                {analyzing ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Send size={16} />
                    Run Analysis
                  </>
                )}
              </button>
            </div>

            {!canSubmit && (
              <p className="text-xs text-slate-400 mt-3 text-center">
                Fill in all required fields (*) to enable analysis
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
