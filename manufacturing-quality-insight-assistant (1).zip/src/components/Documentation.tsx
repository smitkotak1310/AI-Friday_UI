import { BookOpen, Database, Cpu, FileText, Layers, Shield, ArrowRight, Code } from 'lucide-react';

export default function Documentation() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Documentation</h2>
        <p className="text-slate-500 text-sm mt-1">Data structures, usage guide, and system architecture</p>
      </div>

      {/* Overview */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
            <Shield size={20} className="text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">QualityGuard AI</h3>
            <p className="text-sm text-slate-500">Manufacturing Quality Incident Insight Assistant</p>
          </div>
        </div>
        <div className="prose prose-sm text-slate-600 max-w-none">
          <p>
            QualityGuard AI is an intelligent assistant designed to help manufacturing teams rapidly analyze quality incidents
            such as defect spikes, process deviations, and inspection failures. By leveraging a comprehensive knowledge base
            of manufacturing failure modes and real-time process data, the system produces actionable root cause analyses
            that reduce mean time to resolution (MTTR).
          </p>
        </div>
      </div>

      {/* Architecture */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
          <Layers size={16} className="text-blue-500" />
          System Architecture
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            { icon: <Database size={20} />, title: 'Data Layer', desc: 'Synthetic quality metrics, defect logs, and process parameters with timestamps, line IDs, and product metadata.' },
            { icon: <Cpu size={20} />, title: 'Analysis Engine', desc: 'Rule-based root cause analysis using a knowledge base of 12 defect types with failure mode patterns, evidence chains, and corrective actions.' },
            { icon: <FileText size={20} />, title: 'Presentation Layer', desc: 'Interactive dashboard with real-time KPIs, trend charts, incident forms, and detailed analysis reports.' },
          ].map((item, i) => (
            <div key={i} className="p-4 rounded-lg bg-slate-50 border border-slate-200">
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center mb-3">
                {item.icon}
              </div>
              <h4 className="text-sm font-semibold text-slate-800 mb-1">{item.title}</h4>
              <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Data Structure */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
          <Database size={16} className="text-green-500" />
          Data Structures
        </h3>

        <div className="space-y-6">
          {/* QualityMetric */}
          <div>
            <h4 className="text-sm font-semibold text-slate-800 mb-2 flex items-center gap-2">
              <Code size={14} /> QualityMetric
            </h4>
            <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto">
              <pre className="text-xs text-green-300 font-mono">{`{
  timestamp: string;        // ISO 8601 datetime
  line: string;             // Production line ID (e.g., "Line-A1")
  productType: string;      // Product category (e.g., "PCB-Assembly")
  defectRate: number;       // Ratio 0.0–1.0
  yield: number;            // Ratio 0.0–1.0
  temperature: number;      // °C
  pressure: number;         // bar
  humidity: number;         // %RH
  speed: number;            // units/min
  inspectionCount: number;  // Total inspected
  defectCount: number;      // Total defects found
}`}</pre>
            </div>
          </div>

          {/* DefectLog */}
          <div>
            <h4 className="text-sm font-semibold text-slate-800 mb-2 flex items-center gap-2">
              <Code size={14} /> DefectLog
            </h4>
            <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto">
              <pre className="text-xs text-green-300 font-mono">{`{
  id: string;               // Unique incident ID (e.g., "INC-1042")
  timestamp: string;        // ISO 8601 datetime
  line: string;             // Production line
  productType: string;      // Product category
  defectType: string;       // One of 12 defect categories
  severity: 'low' | 'medium' | 'high' | 'critical';
  quantity: number;         // Affected unit count
  description: string;      // Human-readable description
  detectedBy: string;       // Detection method
  status: 'open' | 'investigating' | 'resolved' | 'closed';
}`}</pre>
            </div>
          </div>

          {/* ProcessParameter */}
          <div>
            <h4 className="text-sm font-semibold text-slate-800 mb-2 flex items-center gap-2">
              <Code size={14} /> ProcessParameter
            </h4>
            <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto">
              <pre className="text-xs text-green-300 font-mono">{`{
  name: string;             // Parameter name
  value: number;            // Current reading
  unit: string;             // Unit of measure
  lowerLimit: number;       // Min acceptable value
  upperLimit: number;       // Max acceptable value
  status: 'normal' | 'warning' | 'critical';
}`}</pre>
            </div>
          </div>

          {/* AnalysisResult */}
          <div>
            <h4 className="text-sm font-semibold text-slate-800 mb-2 flex items-center gap-2">
              <Code size={14} /> AnalysisResult
            </h4>
            <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto">
              <pre className="text-xs text-green-300 font-mono">{`{
  incidentId: string;
  timestamp: string;
  summary: string;
  rootCauses: RootCause[];
  relatedIncidents: string[];
  trendAnalysis: string;
  processDeviations: ProcessParameter[];
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  estimatedResolution: string;
}

// RootCause sub-structure:
{
  category: string;          // Equipment, Process, Material, etc.
  description: string;       // Detailed cause description
  confidence: number;        // 0–100 confidence score
  evidence: string[];        // Supporting evidence items
  recommendedAction: string; // Corrective action
  priority: 'high' | 'medium' | 'low';
}`}</pre>
            </div>
          </div>
        </div>
      </div>

      {/* Usage Guide */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
          <BookOpen size={16} className="text-purple-500" />
          Usage Guide
        </h3>
        <div className="space-y-4">
          {[
            {
              step: '1',
              title: 'Review the Dashboard',
              desc: 'Start on the Dashboard to get an overview of current quality metrics, KPIs, defect trends, and recent incidents. Use the charts to identify patterns and anomalies.',
            },
            {
              step: '2',
              title: 'Submit an Incident for Analysis',
              desc: 'Navigate to "Analyze Incident" and fill in the incident details: defect type, production line, product type, severity, and affected quantity. Adjust process parameters using the sliders to reflect current readings from your equipment.',
            },
            {
              step: '3',
              title: 'Review the Analysis Report',
              desc: 'After submitting, the AI engine cross-references the incident with historical data, process parameters, and its knowledge base to produce a detailed root cause analysis. Review the ranked causes, evidence, and recommended actions.',
            },
            {
              step: '4',
              title: 'Take Corrective Action',
              desc: 'Use the recommended action plan at the bottom of the analysis report to guide your response. The actions are prioritized by confidence score and risk level.',
            },
            {
              step: '5',
              title: 'Search Historical Incidents',
              desc: 'Use the Incident Log to search and filter past incidents. Click on any incident to view details and optionally run a new AI analysis on it.',
            },
          ].map((item) => (
            <div key={item.step} className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 text-sm font-bold">
                {item.step}
              </div>
              <div>
                <h4 className="text-sm font-semibold text-slate-800">{item.title}</h4>
                <p className="text-sm text-slate-500 mt-0.5">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Defect Types */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
          <FileText size={16} className="text-orange-500" />
          Supported Defect Types & Root Cause Categories
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            { type: 'Surface Scratch', cat: 'Handling / Equipment' },
            { type: 'Dimensional Deviation', cat: 'Tool / Calibration' },
            { type: 'Solder Bridge', cat: 'Soldering Process' },
            { type: 'Crack/Fracture', cat: 'Material / Stress' },
            { type: 'Contamination', cat: 'Environment / Cleanroom' },
            { type: 'Misalignment', cat: 'Fixture / Vision System' },
            { type: 'Short Circuit', cat: 'Electrical / Assembly' },
            { type: 'Open Circuit', cat: 'Soldering / Component' },
            { type: 'Color Mismatch', cat: 'Coating / Curing' },
            { type: 'Warpage', cat: 'Thermal / Molding' },
            { type: 'Burrs', cat: 'Machining / Tool Wear' },
            { type: 'Incomplete Fill', cat: 'Injection Molding' },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 border border-slate-200">
              <ArrowRight size={14} className="text-blue-500 shrink-0" />
              <div>
                <span className="text-sm font-medium text-slate-800">{item.type}</span>
                <p className="text-xs text-slate-400">{item.cat}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Risk Assessment */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
          <Shield size={16} className="text-red-500" />
          Risk Assessment Methodology
        </h3>
        <div className="prose prose-sm text-slate-600 max-w-none">
          <p>
            The risk level is calculated using a weighted scoring model that considers:
          </p>
          <ul className="space-y-2 mt-2">
            <li className="flex items-start gap-2">
              <span className="text-red-500 mt-1">•</span>
              <span><strong>Severity Weight:</strong> Critical (40pts), High (30pts), Medium (15pts), Low (5pts)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-yellow-500 mt-1">•</span>
              <span><strong>Quantity Impact:</strong> Scaled score based on affected units (up to 30pts)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-500 mt-1">•</span>
              <span><strong>Process Deviations:</strong> Each out-of-spec parameter adds 10pts</span>
            </li>
          </ul>
          <p className="mt-3">
            Score thresholds: Critical (≥60), High (≥40), Medium (≥20), Low (&lt;20).
            The estimated resolution time is derived from the risk level.
          </p>
        </div>
      </div>
    </div>
  );
}
