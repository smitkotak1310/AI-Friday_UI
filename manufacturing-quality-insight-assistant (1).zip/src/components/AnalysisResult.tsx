import {
  AlertTriangle,
  CheckCircle,
  Clock,
  Target,
  Lightbulb,
  ArrowLeft,
  TrendingUp,
  FileText,
  ShieldAlert,
  ShieldCheck,
  Shield,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { useState } from 'react';
import { AnalysisResult as AnalysisResultType } from '../types';

interface AnalysisResultProps {
  result: AnalysisResultType;
  onBack: () => void;
}

const riskConfig: Record<string, { color: string; bg: string; icon: React.ReactNode; label: string }> = {
  low: { color: 'text-green-700', bg: 'bg-green-50 border-green-200', icon: <ShieldCheck size={20} />, label: 'Low Risk' },
  medium: { color: 'text-yellow-700', bg: 'bg-yellow-50 border-yellow-200', icon: <Shield size={20} />, label: 'Medium Risk' },
  high: { color: 'text-orange-700', bg: 'bg-orange-50 border-orange-200', icon: <ShieldAlert size={20} />, label: 'High Risk' },
  critical: { color: 'text-red-700', bg: 'bg-red-50 border-red-200', icon: <ShieldAlert size={20} />, label: 'Critical Risk' },
};

function ConfidenceBar({ value }: { value: number }) {
  const color = value >= 80 ? 'bg-green-500' : value >= 60 ? 'bg-yellow-500' : 'bg-red-500';
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
        <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${value}%` }} />
      </div>
      <span className="text-xs font-mono font-medium text-slate-600 w-10 text-right">{value}%</span>
    </div>
  );
}

function RootCauseCard({ cause, index }: { cause: AnalysisResultType['rootCauses'][0]; index: number }) {
  const [expanded, setExpanded] = useState(index < 2);

  const priorityColor = cause.priority === 'high' ? 'text-red-600 bg-red-50' :
                        cause.priority === 'medium' ? 'text-yellow-600 bg-yellow-50' : 'text-blue-600 bg-blue-50';

  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden hover:shadow-md transition-shadow">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full p-4 flex items-start gap-4 text-left hover:bg-slate-50 transition-colors"
      >
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-sm font-bold ${
          cause.confidence >= 80 ? 'bg-green-100 text-green-700' :
          cause.confidence >= 60 ? 'bg-yellow-100 text-yellow-700' :
          'bg-red-100 text-red-700'
        }`}>
          #{index + 1}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-600">{cause.category}</span>
            <span className={`text-xs font-medium px-2 py-0.5 rounded ${priorityColor}`}>{cause.priority} priority</span>
          </div>
          <p className="text-sm font-medium text-slate-800 mt-1 line-clamp-2">{cause.description}</p>
          <div className="mt-2">
            <ConfidenceBar value={cause.confidence} />
          </div>
        </div>
        {expanded ? <ChevronUp size={18} className="text-slate-400 shrink-0 mt-1" /> : <ChevronDown size={18} className="text-slate-400 shrink-0 mt-1" />}
      </button>

      {expanded && (
        <div className="px-4 pb-4 pt-0 border-t border-slate-100">
          <div className="mt-4 space-y-4">
            {/* Evidence */}
            <div>
              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Target size={13} /> Evidence
              </h4>
              <ul className="space-y-1.5">
                {cause.evidence.map((ev, i) => (
                  <li key={i} className="text-sm text-slate-600 flex items-start gap-2">
                    <span className="text-blue-500 mt-1">•</span>
                    {ev}
                  </li>
                ))}
              </ul>
            </div>

            {/* Recommended Action */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <h4 className="text-xs font-semibold text-blue-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Lightbulb size={13} /> Recommended Action
              </h4>
              <p className="text-sm text-blue-800">{cause.recommendedAction}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function AnalysisResult({ result, onBack }: AnalysisResultProps) {
  const risk = riskConfig[result.riskLevel];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-700 transition-colors"
      >
        <ArrowLeft size={16} />
        Back to Analysis Form
      </button>

      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <div className="flex flex-col sm:flex-row sm:items-start gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <span className="text-xs font-mono text-slate-400">{result.incidentId}</span>
              <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${risk.bg} ${risk.color}`}>
                {risk.label}
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900">Root Cause Analysis Report</h2>
            <p className="text-sm text-slate-500 mt-2">{result.summary}</p>
          </div>
          <div className="flex flex-col gap-2 shrink-0">
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Clock size={14} />
              {new Date(result.timestamp).toLocaleString()}
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Clock size={14} />
              Est. Resolution: <span className="font-medium text-slate-700">{result.estimatedResolution}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Trend Analysis */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
          <TrendingUp size={16} className="text-blue-500" />
          Trend Analysis
        </h3>
        <div className="bg-slate-50 rounded-lg p-4">
          <p className="text-sm text-slate-700 leading-relaxed">{result.trendAnalysis}</p>
        </div>
      </div>

      {/* Process Deviations */}
      {result.processDeviations.length > 0 && (
        <div className="bg-white rounded-xl border border-red-200 shadow-sm p-6">
          <h3 className="text-sm font-semibold text-red-700 mb-3 flex items-center gap-2">
            <AlertTriangle size={16} />
            Process Parameter Deviations ({result.processDeviations.length})
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {result.processDeviations.map(dev => (
              <div key={dev.name} className={`p-3 rounded-lg border ${
                dev.status === 'critical' ? 'border-red-200 bg-red-50' : 'border-yellow-200 bg-yellow-50'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-700">{dev.name}</span>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded ${
                    dev.status === 'critical' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>{dev.status}</span>
                </div>
                <div className="mt-1 text-sm">
                  <span className="font-mono font-bold text-slate-900">{dev.value}{dev.unit}</span>
                  <span className="text-slate-400 mx-1">→</span>
                  <span className="text-slate-500">spec: {dev.lowerLimit}–{dev.upperLimit}{dev.unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Root Causes */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
          <Target size={16} className="text-purple-500" />
          Identified Root Causes ({result.rootCauses.length})
        </h3>
        <div className="space-y-3">
          {result.rootCauses.map((cause, i) => (
            <RootCauseCard key={i} cause={cause} index={i} />
          ))}
        </div>
      </div>

      {/* Related Incidents */}
      {result.relatedIncidents.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
          <h3 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
            <FileText size={16} className="text-slate-500" />
            Related Historical Incidents
          </h3>
          <div className="flex flex-wrap gap-2">
            {result.relatedIncidents.map(id => (
              <span key={id} className="px-3 py-1.5 bg-slate-100 rounded-lg text-xs font-mono text-slate-600 hover:bg-slate-200 transition-colors cursor-default">
                {id}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Action Summary */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg p-6 text-white">
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <CheckCircle size={16} />
          Recommended Action Plan
        </h3>
        <ol className="space-y-2">
          {result.rootCauses.slice(0, 3).map((cause, i) => (
            <li key={i} className="flex items-start gap-3 text-sm">
              <span className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center shrink-0 text-xs font-bold">
                {i + 1}
              </span>
              <span className="text-blue-100">{cause.recommendedAction}</span>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
