import { IncidentInput, AnalysisResult, RootCause, ProcessParameter, DefectLog, QualityMetric } from '../types';

const ROOT_CAUSE_KNOWLEDGE_BASE: Record<string, { causes: string[]; actions: string[]; evidence: string[] }> = {
  'Surface Scratch': {
    causes: [
      'Worn handling fixtures or conveyor guides causing contact damage',
      'Improper material handling procedures during transfer between stations',
      'Contaminated work surfaces with abrasive particles',
      'Excessive line speed causing parts to collide',
    ],
    actions: [
      'Inspect and replace worn fixture components on the affected line',
      'Review and reinforce material handling SOPs with operators',
      'Implement protective film application at upstream station',
      'Reduce line speed by 10-15% and monitor defect recurrence',
    ],
    evidence: [
      'Scratch pattern analysis shows consistent directional marks',
      'Correlation with recent maintenance schedule gaps',
      'Higher incidence during shift changes suggesting handling variability',
    ],
  },
  'Dimensional Deviation': {
    causes: [
      'Tool wear exceeding replacement threshold',
      'Thermal expansion due to ambient temperature fluctuations',
      'Incorrect machine calibration after last maintenance cycle',
      'Raw material lot variation affecting dimensional stability',
    ],
    actions: [
      'Perform immediate tool inspection and replace if wear > 0.05mm',
      'Verify and recalibrate machine axes per calibration protocol CP-004',
      'Check incoming material certificates for lot consistency',
      'Install temperature compensation in CNC program',
    ],
    evidence: [
      'Gradual drift pattern in SPC charts over past 72 hours',
      'Deviation concentrated on specific dimensions suggesting tool-specific issue',
      'Correlation with recent raw material supplier change',
    ],
  },
  'Solder Bridge': {
    causes: [
      'Excessive solder paste deposition due to stencil wear',
      'Incorrect reflow oven temperature profile',
      'Component placement misalignment causing pad overlap',
      'Solder paste viscosity out of specification',
    ],
    actions: [
      'Inspect stencil for wear and replace if aperture degradation detected',
      'Verify reflow profile against specification using thermal profiler',
      'Calibrate pick-and-place machine vision system',
      'Test solder paste viscosity and replace if out of spec',
    ],
    evidence: [
      'Bridge locations correlate with fine-pitch components',
      'AOI data shows increasing trend over past 48 hours',
      'Pattern suggests systematic rather than random occurrence',
    ],
  },
  'Crack/Fracture': {
    causes: [
      'Excessive clamping force during machining operation',
      'Material fatigue from thermal cycling in process',
      'Improper cooling rate causing residual stress',
      'Incoming material defect (micro-cracks in raw stock)',
    ],
    actions: [
      'Reduce clamping pressure by 15% and verify part integrity',
      'Review thermal cycle parameters and adjust cooling rates',
      'Implement incoming material ultrasonic inspection',
      'Add stress-relief annealing step to process flow',
    ],
    evidence: [
      'Fracture surface analysis indicates brittle failure mode',
      'Cracks originate from consistent location suggesting stress concentration',
      'Correlation with specific material batch numbers',
    ],
  },
  'Contamination': {
    causes: [
      'Cleanroom protocol breach or filter degradation',
      'Lubricant leakage from adjacent machinery',
      'Operator PPE non-compliance introducing particulates',
      'Compressed air system contamination',
    ],
    actions: [
      'Perform cleanroom particle count audit and replace HEPA filters if needed',
      'Inspect all lubrication points for leaks in affected area',
      'Reinforce cleanroom entry protocols and conduct compliance audit',
      'Test compressed air quality per ISO 8573-1 standard',
    ],
    evidence: [
      'Contaminant analysis identifies specific particle composition',
      'Spatial distribution suggests localized source',
      'Temporal correlation with maintenance activities',
    ],
  },
  'Misalignment': {
    causes: [
      'Fixture locating pin wear or damage',
      'Vision system calibration drift',
      'Mechanical backlash in positioning system',
      'Thermal expansion mismatch between fixture and part',
    ],
    actions: [
      'Inspect and replace fixture locating pins per PM schedule',
      'Recalibrate vision system using certified reference targets',
      'Check ball screw and linear guide for backlash',
      'Implement thermal compensation in fixture design',
    ],
    evidence: [
      'Misalignment direction is consistent suggesting systematic error',
      'Magnitude increases over production run indicating thermal effect',
      'Pattern correlates with specific fixture position',
    ],
  },
  'Short Circuit': {
    causes: [
      'Conductive debris bridging adjacent traces',
      'Solder splash during wave soldering process',
      'Insulation damage during assembly operation',
      'Component lead bending causing contact',
    ],
    actions: [
      'Implement additional cleaning step post-soldering',
      'Adjust wave soldering parameters (wave height, conveyor speed)',
      'Review assembly tooling for sharp edges causing insulation damage',
      'Add 100% electrical test at current stage',
    ],
    evidence: [
      'Short locations cluster around high-density component areas',
      'ICT data shows specific net pairs affected repeatedly',
      'Correlation with recent solder pot maintenance',
    ],
  },
  'Open Circuit': {
    causes: [
      'Insufficient solder paste volume on pad',
      'Component lead oxidation preventing wetting',
      'Pad contamination inhibiting solder adhesion',
      'Thermal shock during reflow causing joint fracture',
    ],
    actions: [
      'Verify solder paste print volume using SPI system',
      'Check component storage conditions and shelf life',
      'Implement plasma cleaning before solder paste application',
      'Review reflow profile ramp rates',
    ],
    evidence: [
      'Open joints show poor wetting characteristics under microscope',
      'Affected components share common supplier or date code',
      'Failure rate increases with board complexity',
    ],
  },
  'Color Mismatch': {
    causes: [
      'Paint/coating batch variation from supplier',
      'Incorrect curing temperature or time',
      'UV degradation from improper storage conditions',
      'Mixing ratio error in coating preparation',
    ],
    actions: [
      'Verify incoming coating material against color standard',
      'Calibrate curing oven temperature sensors',
      'Review storage conditions for light exposure compliance',
      'Audit coating preparation procedures and mixing logs',
    ],
    evidence: [
      'Spectrophotometer readings show consistent delta-E shift',
      'Affected parts trace to specific coating batch',
      'Variation pattern suggests process rather than material issue',
    ],
  },
  'Warpage': {
    causes: [
      'Uneven cooling rate across part geometry',
      'Mold temperature imbalance',
      'Material moisture content exceeding specification',
      'Insufficient packing pressure during molding',
    ],
    actions: [
      'Optimize cooling channel flow rates for uniform temperature',
      'Verify mold temperature controller calibration',
      'Implement material drying protocol (4hrs at 80°C)',
      'Increase packing pressure by 10% and monitor',
    ],
    evidence: [
      'Warpage direction consistent with thermal gradient analysis',
      'Correlation with material lot changes',
      'Magnitude increases with part wall thickness variation',
    ],
  },
  'Burrs': {
    causes: [
      'Dull cutting tool exceeding recommended tool life',
      'Incorrect feed rate or spindle speed combination',
      'Improper tool path strategy for material type',
      'Insufficient coolant flow at cutting interface',
    ],
    actions: [
      'Replace cutting tool and reset tool life counter',
      'Optimize cutting parameters per material specification',
      'Implement trochoidal milling strategy for difficult features',
      'Verify coolant nozzle alignment and flow rate',
    ],
    evidence: [
      'Burr size correlates with tool usage hours',
      'Location pattern matches specific machining operation',
      'Surface finish degradation accompanies burr formation',
    ],
  },
  'Incomplete Fill': {
    causes: [
      'Insufficient injection pressure or speed',
      'Material viscosity too high (temperature too low)',
      'Vent blockage preventing air escape',
      'Gate size too small for part geometry',
    ],
    actions: [
      'Increase injection pressure by 10-15% incrementally',
      'Verify barrel temperature profile and increase if needed',
      'Clean and inspect all mold vents',
      'Evaluate gate design and consider modification',
    ],
    evidence: [
      'Short shots occur at consistent locations (furthest from gate)',
      'Issue correlates with material changeover events',
      'Process parameter logs show pressure fluctuations',
    ],
  },
};

function analyzeProcessDeviations(params: ProcessParameter[]): ProcessParameter[] {
  return params.filter(p => p.status !== 'normal');
}

function calculateRiskLevel(severity: string, quantity: number, deviations: number): string {
  let score = 0;
  switch (severity) {
    case 'critical': score += 40; break;
    case 'high': score += 30; break;
    case 'medium': score += 15; break;
    default: score += 5;
  }
  score += Math.min(quantity / 5, 30);
  score += deviations * 10;
  if (score >= 60) return 'critical';
  if (score >= 40) return 'high';
  if (score >= 20) return 'medium';
  return 'low';
}

function findRelatedIncidents(input: IncidentInput, logs: DefectLog[]): string[] {
  return logs
    .filter(log =>
      log.defectType === input.defectType ||
      (log.line === input.productionLine && log.productType === input.productType)
    )
    .slice(0, 5)
    .map(l => l.id);
}

function generateTrendAnalysis(input: IncidentInput, metrics: QualityMetric[]): string {
  const relevantMetrics = metrics.filter(
    m => m.line === input.productionLine || m.productType === input.productType
  );

  if (relevantMetrics.length < 5) {
    return 'Insufficient historical data for trend analysis. Recommend increasing monitoring frequency.';
  }

  const recent = relevantMetrics.slice(-10);
  const older = relevantMetrics.slice(-20, -10);
  const recentAvg = recent.reduce((s, m) => s + m.defectRate, 0) / recent.length;
  const olderAvg = older.length > 0 ? older.reduce((s, m) => s + m.defectRate, 0) / older.length : recentAvg;

  const change = ((recentAvg - olderAvg) / olderAvg) * 100;

  if (change > 20) {
    return `⚠️ UPWARD TREND DETECTED: Defect rate has increased by ${change.toFixed(1)}% compared to the previous period. This indicates a deteriorating process condition requiring immediate intervention. The trend suggests a progressive failure mode such as tool wear or parameter drift.`;
  } else if (change > 5) {
    return `📈 SLIGHT INCREASE: Defect rate shows a ${change.toFixed(1)}% increase. Monitor closely over the next 24-48 hours. Consider preventive maintenance if the trend continues.`;
  } else if (change < -20) {
    return `✅ IMPROVING TREND: Defect rate has decreased by ${Math.abs(change).toFixed(1)}%. Recent process adjustments appear effective. Continue monitoring to confirm sustained improvement.`;
  } else {
    return `📊 STABLE: Defect rate variation is within normal range (${change.toFixed(1)}%). The current incident may be an isolated event. Focus investigation on specific batch or shift conditions.`;
  }
}

function estimateResolution(riskLevel: string, _severity: string): string {
  const estimates: Record<string, string> = {
    'critical': '4-8 hours with cross-functional team escalation',
    'high': '2-4 hours with engineering support',
    'medium': '1-2 hours with line technician',
    'low': '30-60 minutes with operator intervention',
  };
  return estimates[riskLevel] || estimates['medium'];
}

export function analyzeIncident(
  input: IncidentInput,
  defectLogs: DefectLog[],
  metrics: QualityMetric[]
): AnalysisResult {
  const knowledge = ROOT_CAUSE_KNOWLEDGE_BASE[input.defectType];
  const deviations = analyzeProcessDeviations(input.processParameters);
  const riskLevel = calculateRiskLevel(input.severity, input.affectedQuantity, deviations.length);

  let rootCauses: RootCause[] = [];

  if (knowledge) {
    const numCauses = Math.min(3 + Math.floor(Math.random() * 2), knowledge.causes.length);
    for (let i = 0; i < numCauses; i++) {
      const baseConfidence = 95 - i * 15 - Math.floor(Math.random() * 10);
      const deviationBoost = deviations.length > 0 ? 5 : 0;

      rootCauses.push({
        category: ['Equipment', 'Process', 'Material', 'Environment', 'Human Factor'][i % 5],
        description: knowledge.causes[i],
        confidence: Math.max(30, Math.min(98, baseConfidence + deviationBoost)),
        evidence: knowledge.evidence.slice(0, 2 + Math.floor(Math.random() * 2)),
        recommendedAction: knowledge.actions[i],
        priority: i < 2 ? 'high' : 'medium',
      });
    }
  }

  // Add process deviation-based causes
  for (const dev of deviations) {
    rootCauses.push({
      category: 'Process Parameter',
      description: `${dev.name} is ${dev.value}${dev.unit}, outside the acceptable range of ${dev.lowerLimit}-${dev.upperLimit}${dev.unit}. This deviation may directly contribute to the observed ${input.defectType.toLowerCase()} defect.`,
      confidence: dev.status === 'critical' ? 85 : 65,
      evidence: [`Real-time sensor reading: ${dev.value}${dev.unit}`, `Specification limit: ${dev.lowerLimit}-${dev.upperLimit}${dev.unit}`],
      recommendedAction: `Immediately adjust ${dev.name.toLowerCase()} to within specification range. Investigate root cause of parameter drift.`,
      priority: dev.status === 'critical' ? 'high' : 'medium',
    });
  }

  // Sort by confidence
  rootCauses.sort((a, b) => b.confidence - a.confidence);

  const relatedIncidents = findRelatedIncidents(input, defectLogs);
  const trendAnalysis = generateTrendAnalysis(input, metrics);

  return {
    incidentId: `INC-${String(Math.floor(Math.random() * 9000) + 1000)}`,
    timestamp: new Date().toISOString(),
    summary: `Analysis of ${input.defectType} incident on ${input.productionLine} affecting ${input.productType}. ${input.affectedQuantity} units affected with ${input.severity} severity. ${rootCauses.length} potential root causes identified with ${deviations.length} process parameter deviation(s) detected.`,
    rootCauses,
    relatedIncidents,
    trendAnalysis,
    processDeviations: deviations,
    riskLevel: riskLevel as AnalysisResult['riskLevel'],
    estimatedResolution: estimateResolution(riskLevel, input.severity),
  };
}
