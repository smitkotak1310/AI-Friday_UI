import { API_CONFIG } from '../config/apiConfig';
import { ChatMessage } from '../types';

// ============================================================
// 📡 REAL LLM API CLIENT
// Handles calls to OpenAI, Anthropic, Azure, Groq, Ollama, Custom
// ============================================================

interface ApiResponse {
  content: string;
  accuracy: number;
  confidence: number;
  responseTime: number;
  tokensUsed: number;
  sources: string[];
  thinkingSteps: string[];
  rawResponse?: string;
}

const SYSTEM_PROMPT = `You are QualityGuard AI, an expert manufacturing quality incident analysis assistant. You help engineers identify root causes of quality defects, suggest corrective actions, and provide insights based on manufacturing best practices.

Your expertise covers:
- Root cause analysis for manufacturing defects (surface scratches, dimensional deviations, solder bridges, cracks, contamination, misalignment, electrical faults, cosmetic issues)
- Statistical Process Control (SPC) interpretation
- Quality standards (ISO 9001, AS9100, IATF 16949, IPC-A-610)
- Process parameter analysis
- Corrective and preventive action (CAPA) recommendations

When analyzing incidents:
1. Identify the defect type and severity
2. Consider process parameters and environmental factors
3. Suggest probable root causes ranked by likelihood
4. Provide specific, actionable corrective actions
5. Reference relevant quality standards
6. Assess risk level and urgency

Be concise, technical, and actionable. Use markdown formatting for structure.`;

function buildOpenAIMessages(
  userQuery: string,
  context: string,
  history: ChatMessage[]
): { role: string; content: string }[] {
  const messages: { role: string; content: string }[] = [
    { role: 'system', content: SYSTEM_PROMPT + '\n\nCurrent plant context:\n' + context },
  ];

  // Add conversation history (last 10 messages)
  const recentHistory = history.slice(-10);
  for (const msg of recentHistory) {
    if (msg.role === 'user' || msg.role === 'assistant') {
      messages.push({ role: msg.role, content: msg.content });
    }
  }

  messages.push({ role: 'user', content: userQuery });
  return messages;
}

function buildContext(defectLogs: any[], metrics: any[]): string {
  const recentDefects = defectLogs.slice(-5);
  const recentMetrics = metrics.slice(-3);

  let context = `=== CURRENT PLANT DATA ===\n`;
  context += `Total defect logs: ${defectLogs.length}\n`;
  context += `Total quality metrics: ${metrics.length}\n\n`;

  if (recentDefects.length > 0) {
    context += `--- Recent Defects ---\n`;
    for (const d of recentDefects) {
      context += `[${d.id}] ${d.timestamp} | Line: ${d.line} | Type: ${d.defectType} | Severity: ${d.severity} | Qty: ${d.quantity}\n`;
    }
    context += '\n';
  }

  if (recentMetrics.length > 0) {
    context += `--- Recent Metrics ---\n`;
    for (const m of recentMetrics) {
      context += `${m.timestamp} | Line: ${m.line} | Defect Rate: ${m.defectRate}% | Yield: ${m.yield}% | Temp: ${m.temperature}°C | Pressure: ${m.pressure} PSI\n`;
    }
    context += '\n';
  }

  return context;
}

function calculateAccuracy(response: string, query: string): number {
  // Heuristic accuracy scoring based on response quality
  let score = 75;

  // Length factor (longer, more detailed responses tend to be more accurate)
  if (response.length > 200) score += 5;
  if (response.length > 500) score += 5;
  if (response.length > 1000) score += 3;

  // Domain relevance keywords
  const domainKeywords = ['root cause', 'corrective', 'preventive', 'ISO', 'defect', 'quality', 'process', 'parameter', 'tolerance', 'SPC', 'inspection', 'calibration', 'specification'];
  const queryLower = query.toLowerCase();
  const responseLower = response.toLowerCase();

  let keywordMatches = 0;
  for (const kw of domainKeywords) {
    if (responseLower.includes(kw)) keywordMatches++;
  }
  score += Math.min(keywordMatches * 1.5, 10);

  // Query alignment
  const queryWords = queryLower.split(/\s+/).filter(w => w.length > 3);
  let queryAlignment = 0;
  for (const word of queryWords) {
    if (responseLower.includes(word)) queryAlignment++;
  }
  if (queryWords.length > 0) {
    score += Math.min((queryAlignment / queryWords.length) * 8, 8);
  }

  // Structure bonus (markdown formatting indicates structured thinking)
  if (response.includes('**') || response.includes('##')) score += 2;
  if (response.includes('- ') || response.includes('* ')) score += 1;

  return Math.min(Math.round(score * 10) / 10, 98.5);
}

function calculateConfidence(response: string, model: string): number {
  let base = 70;

  // Model-specific base confidence
  const modelConfidence: Record<string, number> = {
    'gpt-4o': 88,
    'gpt-4o-mini': 84,
    'gpt-3.5-turbo': 80,
    'claude-3-5-sonnet-20241022': 90,
    'claude-3-opus-20240229': 92,
    'llama-3.3-70b-versatile': 85,
    'mixtral-8x7b-32768': 82,
    'llama3': 80,
    'mistral': 78,
  };

  base = modelConfidence[model] || 78;

  // Response quality adjustments
  if (response.length > 300) base += 3;
  if (response.includes('root cause')) base += 2;
  if (response.includes('recommend') || response.includes('suggest')) base += 2;

  return Math.min(Math.round(base * 10) / 10, 97.0);
}

function extractThinkingSteps(response: string, provider: string): string[] {
  const steps: string[] = [];

  steps.push(`Connected to ${provider} API`);
  steps.push('Parsed user query for defect context');
  steps.push('Cross-referenced with plant data');

  if (response.toLowerCase().includes('root cause')) {
    steps.push('Identified potential root causes');
  }
  if (response.toLowerCase().includes('corrective') || response.toLowerCase().includes('action')) {
    steps.push('Generated corrective action recommendations');
  }
  if (response.toLowerCase().includes('iso') || response.toLowerCase().includes('standard')) {
    steps.push('Referenced applicable quality standards');
  }
  if (response.toLowerCase().includes('risk') || response.toLowerCase().includes('severity')) {
    steps.push('Assessed risk level and priority');
  }

  steps.push('Formatted response with accuracy scoring');

  return steps;
}

// ============================================================
// OPENAI-COMPATIBLE API CALL (OpenAI, Groq, Azure, Ollama, Custom)
// ============================================================
async function callOpenAICompatible(
  messages: { role: string; content: string }[],
  baseUrl: string,
  apiKey: string,
  model: string,
  temperature: number,
  maxTokens: number,
  provider: string
): Promise<{ content: string; tokens: number }> {
  let url = `${baseUrl}/chat/completions`;

  // Azure uses a different URL pattern
  if (provider === 'azure') {
    url = `${baseUrl}/deployments/${model}/chat/completions?api-version=2024-06-01`;
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (provider === 'azure') {
    headers['api-key'] = apiKey;
  } else if (provider !== 'ollama' || apiKey) {
    headers['Authorization'] = `Bearer ${apiKey}`;
  }

  const body: Record<string, unknown> = {
    model: model,
    messages: messages,
    temperature: temperature,
    max_tokens: maxTokens,
  };

  // Ollama doesn't need max_tokens in some versions
  if (provider === 'ollama') {
    body.options = {
      temperature: temperature,
      num_predict: maxTokens,
    };
    delete body.max_tokens;
  }

  const response = await fetch(url, {
    method: 'POST',
    headers: headers,
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API Error (${response.status}): ${errorText}`);
  }

  const data = await response.json();

  // Handle different response formats
  let content = '';
  let tokens = 0;

  if (provider === 'ollama' && data.message) {
    content = data.message.content || '';
    tokens = data.prompt_eval_count || 0;
  } else if (data.choices && data.choices[0]) {
    content = data.choices[0].message?.content || '';
    tokens = data.usage?.total_tokens || 0;
  }

  return { content, tokens };
}

// ============================================================
// ANTHROPIC API CALL
// ============================================================
async function callAnthropic(
  messages: { role: string; content: string }[],
  baseUrl: string,
  apiKey: string,
  model: string,
  temperature: number,
  maxTokens: number
): Promise<{ content: string; tokens: number }> {
  // Anthropic uses a different message format (no system role in messages array)
  const systemMessage = messages.find(m => m.role === 'system');
  const chatMessages = messages.filter(m => m.role !== 'system').map(m => ({
    role: m.role,
    content: m.content,
  }));

  const response = await fetch(`${baseUrl}/v1/messages`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: model,
      max_tokens: maxTokens,
      temperature: temperature,
      system: systemMessage?.content,
      messages: chatMessages,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Anthropic API Error (${response.status}): ${errorText}`);
  }

  const data = await response.json();
  const content = data.content?.[0]?.text || '';
  const tokens = data.usage?.input_tokens || 0;

  return { content, tokens };
}

// ============================================================
// MAIN API CALL FUNCTION
// ============================================================
export async function callRealLLM(
  userQuery: string,
  defectLogs: any[],
  metrics: any[],
  history: ChatMessage[]
): Promise<ApiResponse> {
  const startTime = Date.now();

  const config = API_CONFIG;

  if (!config.enabled) {
    throw new Error('Real API calls are not enabled. Configure API_CONFIG in src/config/apiConfig.ts');
  }

  if (!config.apiKey && config.provider !== 'ollama') {
    throw new Error('API key is required. Please configure it in src/config/apiConfig.ts');
  }

  if (!config.baseUrl) {
    throw new Error('Base URL is required. Please configure it in src/config/apiConfig.ts');
  }

  const context = buildContext(defectLogs, metrics);
  const messages = buildOpenAIMessages(userQuery, context, history);

  let result: { content: string; tokens: number };

  try {
    if (config.provider === 'anthropic') {
      result = await callAnthropic(
        messages,
        config.baseUrl,
        config.apiKey,
        config.model,
        config.temperature,
        config.maxTokens
      );
    } else {
      result = await callOpenAICompatible(
        messages,
        config.baseUrl,
        config.apiKey,
        config.model,
        config.temperature,
        config.maxTokens,
        config.provider
      );
    }
  } catch (error) {
    const elapsed = Date.now() - startTime;
    throw new Error(`LLM API call failed after ${elapsed}ms: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }

  const responseTime = Date.now() - startTime;
  const accuracy = calculateAccuracy(result.content, userQuery);
  const confidence = calculateConfidence(result.content, config.model);
  const thinkingSteps = extractThinkingSteps(result.content, config.provider);

  const sources = [`${config.provider.toUpperCase()} API (${config.model})`];
  if (defectLogs.length > 0) sources.push('Plant Defect Logs');
  if (metrics.length > 0) sources.push('Quality Metrics');

  return {
    content: result.content,
    accuracy,
    confidence,
    responseTime,
    tokensUsed: result.tokens || Math.ceil(result.content.length / 4),
    sources,
    thinkingSteps,
  };
}

// ============================================================
// CHECK IF REAL API IS CONFIGURED
// ============================================================
export function isRealApiConfigured(): boolean {
  const config = API_CONFIG;
  return config.enabled && !!config.baseUrl && (config.provider === 'ollama' || !!config.apiKey);
}

// ============================================================
// GET CURRENT CONFIG (for display in UI)
// ============================================================
export function getCurrentConfig() {
  return {
    ...API_CONFIG,
    apiKey: API_CONFIG.apiKey ? `${API_CONFIG.apiKey.substring(0, 8)}...${API_CONFIG.apiKey.substring(API_CONFIG.apiKey.length - 4)}` : '(not set)',
    isConfigured: isRealApiConfigured(),
  };
}
