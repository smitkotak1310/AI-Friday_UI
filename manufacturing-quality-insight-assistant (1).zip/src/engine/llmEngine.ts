import { LLMModel, ChatMessage, DefectLog, QualityMetric } from '../types';

export const LLM_MODELS: LLMModel[] = [
  {
    id: 'qualityguard-custom',
    name: 'QualityGuard Custom',
    provider: 'QualityGuard AI',
    description: 'Domain-specific model fine-tuned on manufacturing quality data. Highest accuracy for quality incident analysis.',
    baseAccuracy: 0.96,
    baseConfidence: 0.94,
    responseSpeed: 'medium',
    specialties: ['Root Cause Analysis', 'Defect Classification', 'Process Optimization', 'SPC Interpretation'],
    icon: '🛡️',
    color: 'from-blue-600 to-cyan-500',
  },
  {
    id: 'gpt-4o',
    name: 'GPT-4o',
    provider: 'OpenAI',
    description: 'Latest multimodal model with strong reasoning capabilities. Excellent at complex technical analysis.',
    baseAccuracy: 0.93,
    baseConfidence: 0.91,
    responseSpeed: 'medium',
    specialties: ['General Reasoning', 'Technical Writing', 'Pattern Recognition', 'Multi-step Analysis'],
    icon: '🟢',
    color: 'from-green-600 to-emerald-500',
  },
  {
    id: 'claude-3.5-sonnet',
    name: 'Claude 3.5 Sonnet',
    provider: 'Anthropic',
    description: 'Advanced reasoning model with strong analytical capabilities. Great at structured problem-solving.',
    baseAccuracy: 0.92,
    baseConfidence: 0.90,
    responseSpeed: 'medium',
    specialties: ['Analytical Reasoning', 'Structured Output', 'Safety Analysis', 'Code Interpretation'],
    icon: '🟣',
    color: 'from-purple-600 to-violet-500',
  },
  {
    id: 'llama-3-70b',
    name: 'LLaMA 3 70B',
    provider: 'Meta',
    description: 'Open-source model with strong general capabilities. Fast response with good accuracy.',
    baseAccuracy: 0.88,
    baseConfidence: 0.85,
    responseSpeed: 'fast',
    specialties: ['General Knowledge', 'Quick Analysis', 'Summarization', 'Classification'],
    icon: '🔵',
    color: 'from-blue-500 to-indigo-500',
  },
  {
    id: 'gemini-1.5-pro',
    name: 'Gemini 1.5 Pro',
    provider: 'Google DeepMind',
    description: 'Strong at data analysis and pattern recognition. Excellent for statistical quality analysis.',
    baseAccuracy: 0.91,
    baseConfidence: 0.89,
    responseSpeed: 'slow',
    specialties: ['Data Analysis', 'Statistical Reasoning', 'Pattern Detection', 'Long Context'],
    icon: '🔴',
    color: 'from-red-500 to-orange-500',
  },
  {
    id: 'mistral-large',
    name: 'Mistral Large 2',
    provider: 'Mistral AI',
    description: 'Efficient model with balanced performance. Good for rapid incident triage and classification.',
    baseAccuracy: 0.87,
    baseConfidence: 0.84,
    responseSpeed: 'fast',
    specialties: ['Rapid Triage', 'Classification', 'Multilingual', 'Efficient Processing'],
    icon: '🟡',
    color: 'from-amber-500 to-yellow-500',
  },
];

const DEFECT_KEYWORDS: Record<string, string[]> = {
  'scratch': ['scratch', 'surface scratch', 'abrasion', 'scuff', 'mark', 'cosmetic'],
  'dimensional': ['dimensional', 'dimension', 'tolerance', 'size', 'measurement', 'out of spec', 'deviation'],
  'solder': ['solder', 'bridge', 'soldering', 'reflow', 'paste', 'joint'],
  'crack': ['crack', 'fracture', 'break', 'split', 'brittle', 'stress'],
  'contamination': ['contamination', 'contaminant', 'particle', 'dust', 'foreign', 'debris', 'dirty'],
  'misalignment': ['misalignment', 'misaligned', 'offset', 'shift', 'position', 'alignment'],
  'electrical': ['short circuit', 'open circuit', 'electrical', 'continuity', 'resistance', 'voltage'],
  'cosmetic': ['color', 'cosmetic', 'appearance', 'finish', 'discoloration', 'warpage', 'warp'],
  'general': ['defect', 'quality', 'incident', 'issue', 'problem', 'failure', 'reject', 'non-conformance'],
};

const KNOWLEDGE_BASE: Record<string, {
  rootCauses: string[];
  correctiveActions: string[];
  preventiveMeasures: string[];
  relevantStandards: string[];
}> = {
  'scratch': {
    rootCauses: [
      'Worn conveyor guides or handling fixtures creating contact points',
      'Improper operator handling during manual transfer operations',
      'Abrasive particles accumulated on work surfaces or tooling',
      'Excessive line speed causing part-to-part collision',
      'Inadequate protective packaging between processing stages',
    ],
    correctiveActions: [
      'Inspect and replace all worn fixture components on the affected line',
      'Implement protective film application at the upstream station',
      'Reduce line speed by 10-15% and monitor for defect recurrence',
      'Conduct operator retraining on proper handling procedures',
    ],
    preventiveMeasures: [
      'Establish fixture wear monitoring schedule (weekly inspections)',
      'Install soft-touch guides and bumpers at all transfer points',
      'Implement automated visual inspection for early scratch detection',
    ],
    relevantStandards: ['ISO 9001:2015 Clause 8.5.1', 'IPC-A-610 Section 4', 'ASTM D3359'],
  },
  'dimensional': {
    rootCauses: [
      'Tool wear exceeding replacement threshold causing gradual drift',
      'Thermal expansion from ambient temperature fluctuations',
      'Incorrect machine calibration after last preventive maintenance',
      'Raw material lot variation affecting dimensional stability',
      'Fixture clamping inconsistency leading to part movement during machining',
    ],
    correctiveActions: [
      'Perform immediate tool inspection; replace if wear exceeds 0.05mm',
      'Recalibrate all machine axes per calibration protocol CP-004',
      'Verify incoming material certificates for lot-to-lot consistency',
      'Implement temperature compensation in CNC program offsets',
    ],
    preventiveMeasures: [
      'Implement real-time SPC monitoring with automated alerts at ±2σ',
      'Establish tool life management system with predictive replacement',
      'Install environmental monitoring with temperature compensation',
    ],
    relevantStandards: ['ISO 2768-mK', 'ASME Y14.5-2018', 'ISO 1101'],
  },
  'solder': {
    rootCauses: [
      'Excessive solder paste deposition due to stencil aperture wear',
      'Incorrect reflow oven temperature profile (preheat/soak/reflow zones)',
      'Component placement misalignment causing pad-to-pad bridging',
      'Solder paste viscosity out of specification due to improper storage',
      'Flux activation temperature mismatch with reflow profile',
    ],
    correctiveActions: [
      'Inspect stencil for aperture degradation; replace if wear detected',
      'Verify reflow profile using thermal profiler (KIC or equivalent)',
      'Calibrate pick-and-place machine vision alignment system',
      'Test solder paste viscosity; replace batch if out of specification',
    ],
    preventiveMeasures: [
      'Implement solder paste inspection (SPI) with volume monitoring',
      'Establish stencil cleaning and inspection schedule (every 5000 prints)',
      'Monitor reflow oven zone temperatures with continuous data logging',
    ],
    relevantStandards: ['IPC-A-610 Class 2/3', 'IPC-J-STD-001', 'IPC-7525'],
  },
  'crack': {
    rootCauses: [
      'Excessive clamping force during machining or assembly operation',
      'Material fatigue from repeated thermal cycling in process',
      'Improper cooling rate creating residual tensile stresses',
      'Incoming material defect (micro-cracks in raw stock or casting)',
      'Design stress concentration at sharp corners or transitions',
    ],
    correctiveActions: [
      'Reduce clamping pressure by 15% and verify part integrity',
      'Review and adjust thermal cycle parameters and cooling rates',
      'Implement incoming material ultrasonic inspection protocol',
      'Add stress-relief annealing step to the process flow',
    ],
    preventiveMeasures: [
      'Implement FMEA for crack-prone features and geometries',
      'Establish regular NDT (non-destructive testing) sampling schedule',
      'Review design for stress concentrations and add fillet radii',
    ],
    relevantStandards: ['ASTM E1444', 'ISO 3452-1', 'ASME BPVC Section V'],
  },
  'contamination': {
    rootCauses: [
      'Cleanroom protocol breach or HEPA filter degradation',
      'Lubricant or hydraulic fluid leakage from adjacent machinery',
      'Operator PPE non-compliance introducing particulates or oils',
      'Compressed air system contamination (oil, water, particles)',
      'Cross-contamination from adjacent production processes',
    ],
    correctiveActions: [
      'Perform cleanroom particle count audit; replace HEPA filters if needed',
      'Inspect all lubrication points for leaks in the affected area',
      'Test compressed air quality per ISO 8573-1 standard',
      'Conduct PPE compliance audit and reinforce entry protocols',
    ],
    preventiveMeasures: [
      'Implement continuous particle monitoring with automated alerts',
      'Establish compressed air quality testing schedule (weekly)',
      'Install physical barriers between contamination-sensitive processes',
    ],
    relevantStandards: ['ISO 14644-1', 'ISO 8573-1', 'IEST-RP-CC004'],
  },
  'misalignment': {
    rootCauses: [
      'Worn positioning pins or locating fixtures causing reference drift',
      'Machine vision system calibration drift or lighting inconsistency',
      'Thermal expansion mismatch between fixture and workpiece',
      'Vibration from adjacent equipment affecting precision positioning',
      'Incorrect program coordinates or datum reference errors',
    ],
    correctiveActions: [
      'Inspect and replace all locating pins and reference surfaces',
      'Recalibrate machine vision system with certified calibration target',
      'Verify and correct CNC program datum references',
      'Install vibration isolation mounts on precision equipment',
    ],
    preventiveMeasures: [
      'Implement automated vision system calibration verification (daily)',
      'Establish fixture maintenance schedule with wear tracking',
      'Install vibration monitoring on critical positioning equipment',
    ],
    relevantStandards: ['ISO 10791-1', 'ASME B89.4.1', 'VDI/VDE 2630'],
  },
  'electrical': {
    rootCauses: [
      'Insulation breakdown due to thermal overstress or aging',
      'Conductive contamination creating unintended current paths',
      'Component damage from ESD (electrostatic discharge) during handling',
      'Solder joint fatigue from thermal cycling creating intermittent opens',
      'Design margin insufficient for operating environment conditions',
    ],
    correctiveActions: [
      'Perform insulation resistance testing on affected assemblies',
      'Review ESD control program and verify grounding integrity',
      'Conduct thermal imaging survey to identify hot spots',
      'Implement burn-in testing for early failure detection',
    ],
    preventiveMeasures: [
      'Establish ESD monitoring with continuous wrist strap and mat testing',
      'Implement automated electrical testing at multiple process stages',
      'Review design margins against worst-case operating conditions',
    ],
    relevantStandards: ['IPC-A-610 Section 10', 'ANSI/ESD S20.20', 'IEC 61000-4-2'],
  },
  'cosmetic': {
    rootCauses: [
      'Inconsistent raw material color or surface finish from supplier',
      'Process parameter variation affecting surface treatment quality',
      'UV exposure or environmental degradation during storage',
      'Mold surface degradation or contamination in injection molding',
      'Coating thickness variation from spray pattern inconsistency',
    ],
    correctiveActions: [
      'Verify incoming material color against approved master samples',
      'Inspect and refurbish mold surfaces; apply appropriate coating',
      'Calibrate coating application equipment and verify spray patterns',
      'Review storage conditions for UV and environmental protection',
    ],
    preventiveMeasures: [
      'Implement color measurement with spectrophotometer at incoming QC',
      'Establish mold maintenance schedule with surface quality tracking',
      'Install controlled storage environment with UV protection',
    ],
    relevantStandards: ['ASTM D2244', 'ISO 3664', 'ISO 105-A02'],
  },
  'general': {
    rootCauses: [
      'Process parameter drift outside control limits',
      'Equipment degradation or maintenance schedule non-compliance',
      'Raw material quality variation from supplier',
      'Operator training gaps or procedural non-compliance',
      'Environmental condition changes (temperature, humidity, vibration)',
    ],
    correctiveActions: [
      'Conduct comprehensive process audit on the affected production line',
      'Review and verify all process parameters against specification',
      'Perform equipment health check and address any maintenance backlogs',
      'Verify incoming material quality certificates and perform spot checks',
    ],
    preventiveMeasures: [
      'Implement real-time SPC monitoring across all critical parameters',
      'Establish predictive maintenance program with condition monitoring',
      'Conduct regular operator competency assessments and refresher training',
    ],
    relevantStandards: ['ISO 9001:2015', 'IATF 16949', 'ISO 14001'],
  },
};

function classifyQuery(query: string): string[] {
  const lower = query.toLowerCase();
  const matched: string[] = [];
  for (const [category, keywords] of Object.entries(DEFECT_KEYWORDS)) {
    if (keywords.some(kw => lower.includes(kw))) {
      matched.push(category);
    }
  }
  return matched.length > 0 ? matched : ['general'];
}

function extractContext(query: string, defectLogs: DefectLog[], metrics: QualityMetric[]): string {
  const lower = query.toLowerCase();
  let context = '';

  // Check for line references
  const lines = ['Line-A1', 'Line-A2', 'Line-B1', 'Line-B2', 'Line-C1'];
  const mentionedLines = lines.filter(l => lower.includes(l.toLowerCase().replace('-', '')) || lower.includes(l.toLowerCase()));

  // Check for severity references
  const severities = ['critical', 'high', 'medium', 'low'];
  const mentionedSeverity = severities.find(s => lower.includes(s));

  // Check for incident ID references
  const incidentMatch = lower.match(/inc-\d+/i);

  if (mentionedLines.length > 0) {
    const lineLogs = defectLogs.filter(l => mentionedLines.some(ml => l.line.toLowerCase().includes(ml.toLowerCase().replace('line-', ''))));
    const openIncidents = lineLogs.filter(l => l.status === 'open' || l.status === 'investigating');
    context += `\n\n**Relevant Line Data (${mentionedLines.join(', ')}):**`;
    context += `\n- Open/Investigating incidents: ${openIncidents.length}`;
    context += `\n- Total logged incidents: ${lineLogs.length}`;
    if (openIncidents.length > 0) {
      context += `\n- Recent open incidents: ${openIncidents.slice(0, 3).map(i => `${i.id} (${i.defectType}, ${i.severity})`).join(', ')}`;
    }
  }

  if (mentionedSeverity) {
    const severityLogs = defectLogs.filter(l => l.severity === mentionedSeverity);
    context += `\n\n**${mentionedSeverity.charAt(0).toUpperCase() + mentionedSeverity.slice(1)} Severity Incidents:**`;
    context += `\n- Total count: ${severityLogs.length}`;
    context += `\n- Top defect types: ${Object.entries(
      severityLogs.reduce((acc, l) => { acc[l.defectType] = (acc[l.defectType] || 0) + 1; return acc; }, {} as Record<string, number>)
    ).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([type, count]) => `${type} (${count})`).join(', ')}`;
  }

  if (incidentMatch) {
    const incident = defectLogs.find(l => l.id.toLowerCase() === incidentMatch[0].toLowerCase());
    if (incident) {
      context += `\n\n**Incident ${incident.id} Details:**`;
      context += `\n- Type: ${incident.defectType}`;
      context += `\n- Line: ${incident.line}`;
      context += `\n- Product: ${incident.productType}`;
      context += `\n- Severity: ${incident.severity}`;
      context += `\n- Quantity: ${incident.quantity}`;
      context += `\n- Status: ${incident.status}`;
      context += `\n- Description: ${incident.description}`;
    }
  }

  // General statistics
  const openCount = defectLogs.filter(l => l.status === 'open' || l.status === 'investigating').length;
  const criticalCount = defectLogs.filter(l => l.severity === 'critical').length;
  const avgDefectRate = metrics.length > 0 ? (metrics.reduce((sum, m) => sum + m.defectRate, 0) / metrics.length * 100).toFixed(2) : 'N/A';

  context += `\n\n**Current Plant Overview:**`;
  context += `\n- Open/Investigating incidents: ${openCount}`;
  context += `\n- Critical incidents: ${criticalCount}`;
  context += `\n- Average defect rate (30-day): ${avgDefectRate}%`;
  context += `\n- Total incidents logged: ${defectLogs.length}`;

  return context;
}

function generateResponseForCategories(
  categories: string[],
  query: string,
  model: LLMModel,
  context: string
): { content: string; accuracy: number; confidence: number; sources: string[]; thinkingSteps: string[] } {
  const thinkingSteps: string[] = [
    'Parsing query for manufacturing quality keywords...',
    `Classified query into categories: ${categories.join(', ')}`,
    'Retrieving relevant knowledge base entries...',
    'Cross-referencing with current plant data...',
    'Analyzing process parameters and defect patterns...',
    'Generating root cause hypotheses...',
    'Ranking hypotheses by probability and evidence strength...',
    'Formulating corrective and preventive recommendations...',
    'Compiling final response with confidence assessment...',
  ];

  const sources: string[] = [];
  let content = '';
  let totalAccuracy = model.baseAccuracy;
  let totalConfidence = model.baseConfidence;

  const isGreeting = /^(hi|hello|hey|good morning|good afternoon|good evening|howdy|greetings)/i.test(query.trim());
  const isHelpRequest = /^(help|what can you|how do i|how to|capabilities|what are you)/i.test(query.trim());

  if (isGreeting) {
    content = `Hello! 👋 I'm your **QualityGuard AI Assistant**, powered by **${model.name}** (${model.provider}).

I'm here to help you analyze quality incidents, identify root causes, and recommend corrective actions. Here are some things you can ask me:

🔍 **Root Cause Analysis** — *"What could be causing surface scratches on Line-A1?"*
📊 **Trend Analysis** — *"Show me the defect trend for solder bridges"*
🔧 **Process Parameters** — *"Are temperature deviations causing our dimensional issues?"*
📋 **Incident Review** — *"Tell me about INC-1001"*
⚡ **Quick Triage** — *"We have a critical contamination issue, what should I check first?"*

What quality incident would you like me to help you investigate?`;
    totalAccuracy = 0.99;
    totalConfidence = 0.98;
    sources.push('QualityGuard AI System Prompt');
    return { content, accuracy: totalAccuracy, confidence: totalConfidence, sources, thinkingSteps: thinkingSteps.slice(0, 2) };
  }

  if (isHelpRequest) {
    content = `## 🤖 QualityGuard AI Assistant — Capabilities

Powered by **${model.name}** (${model.provider}), I can assist with:

### 🔍 Root Cause Analysis
Analyze quality incidents and identify probable root causes with confidence scoring.
*Example: "What's causing the dimensional deviation on Line-B1?"*

### 📊 Statistical Analysis
Review defect trends, yield rates, and process capability across production lines.
*Example: "How has the defect rate changed over the past week?"*

### 🔧 Process Parameter Review
Evaluate whether process parameters are within specification and contributing to defects.
*Example: "Could temperature be causing our crack issues?"*

### 📋 Incident Investigation
Look up specific incidents and provide detailed analysis with recommendations.
*Example: "Tell me about incident INC-1005"*

### ⚡ Rapid Triage
Quick assessment of critical incidents with prioritized action items.
*Example: "We have a critical solder bridge issue, what do I do?"*

### 📚 Standards & Compliance
Reference relevant quality standards and compliance requirements.
*Example: "What standards apply to contamination control?"*

**Current Model:** ${model.name} | **Accuracy:** ${(model.baseAccuracy * 100).toFixed(1)}% | **Specialties:** ${model.specialties.join(', ')}`;
    totalAccuracy = 0.99;
    totalConfidence = 0.97;
    sources.push('QualityGuard AI System Documentation');
    return { content, accuracy: totalAccuracy, confidence: totalConfidence, sources, thinkingSteps: thinkingSteps.slice(0, 2) };
  }

  // Build the main response
  content = `## 🔍 Quality Incident Analysis\n\n`;

  const allRootCauses: string[] = [];
  const allActions: string[] = [];
  const allPreventive: string[] = [];
  const allStandards: string[] = [];

  for (const category of categories) {
    const kb = KNOWLEDGE_BASE[category];
    if (kb) {
      allRootCauses.push(...kb.rootCauses);
      allActions.push(...kb.correctiveActions);
      allPreventive.push(...kb.preventiveMeasures);
      allStandards.push(...kb.relevantStandards);
      sources.push(`QualityGuard Knowledge Base — ${category.charAt(0).toUpperCase() + category.slice(1)} Module`);
    }
  }

  // Deduplicate
  const uniqueCauses = [...new Set(allRootCauses)];
  const uniqueActions = [...new Set(allActions)];
  const uniquePreventive = [...new Set(allPreventive)];
  const uniqueStandards = [...new Set(allStandards)];

  // Adjust accuracy/confidence based on query specificity
  const queryLength = query.split(' ').length;
  const specificityBonus = Math.min(queryLength / 30, 0.05);
  const categoryBonus = categories.filter(c => c !== 'general').length * 0.01;

  totalAccuracy = Math.min(totalAccuracy + specificityBonus + categoryBonus, 0.99);
  totalConfidence = Math.min(totalConfidence + specificityBonus * 0.8 + categoryBonus * 0.5, 0.98);

  // Add model-specific flavor
  if (model.id === 'qualityguard-custom') {
    content += `> 🛡️ **Analysis by QualityGuard Custom Model** — Domain-optimized for manufacturing quality\n\n`;
  } else if (model.id === 'gpt-4o') {
    content += `> 🟢 **Analysis by GPT-4o** — Advanced reasoning with multi-step chain of thought\n\n`;
  } else if (model.id === 'claude-3.5-sonnet') {
    content += `> 🟣 **Analysis by Claude 3.5 Sonnet** — Structured analytical reasoning\n\n`;
  }

  content += `Based on your query and analysis of current plant data, here are the findings:\n`;

  // Root Causes section
  content += `\n### 🎯 Probable Root Causes (Ranked by Likelihood)\n\n`;
  const topCauses = uniqueCauses.slice(0, 5);
  topCauses.forEach((cause, i) => {
    const confidenceLevel = (95 - i * 8 - (model.id === 'mistral-large' ? 5 : 0) - (model.id === 'llama-3-70b' ? 3 : 0));
    content += `${i + 1}. **${cause}** (Confidence: ${confidenceLevel}%)\n`;
  });

  // Corrective Actions
  content += `\n### 🔧 Immediate Corrective Actions\n\n`;
  uniqueActions.slice(0, 4).forEach((action, i) => {
    content += `${i + 1}. ${action}\n`;
  });

  // Preventive Measures
  content += `\n### 🛡️ Preventive Measures\n\n`;
  uniquePreventive.slice(0, 3).forEach((measure, i) => {
    content += `${i + 1}. ${measure}\n`;
  });

  // Relevant Standards
  if (uniqueStandards.length > 0) {
    content += `\n### 📚 Relevant Standards & References\n\n`;
    content += uniqueStandards.slice(0, 5).map(s => `- ${s}`).join('\n');
  }

  // Context data
  if (context) {
    content += `\n${context}`;
  }

  // Risk Assessment
  content += `\n\n### ⚠️ Risk Assessment\n\n`;
  const riskLevel = categories.includes('crack') || categories.includes('electrical') ? 'HIGH' : categories.includes('general') ? 'MEDIUM' : 'MODERATE';
  content += `- **Risk Level:** ${riskLevel}\n`;
  content += `- **Recommended Response Time:** ${riskLevel === 'HIGH' ? 'Immediate (< 1 hour)' : riskLevel === 'MODERATE' ? 'Within 4 hours' : 'Within 24 hours'}\n`;
  content += `- **Escalation Required:** ${riskLevel === 'HIGH' ? 'Yes — Notify Quality Manager' : 'No — Handle at line level'}\n`;

  // Model-specific note
  content += `\n---\n*Analysis generated by ${model.name} (${model.provider}) | Response accuracy and confidence scores are displayed in the metadata panel.*`;

  sources.push('Plant Quality Metrics Database');
  sources.push('Historical Defect Log Repository');
  if (categories.length > 0 && !categories.includes('general')) {
    sources.push(`Domain Expert System — ${categories.map(c => c.charAt(0).toUpperCase() + c.slice(1)).join(', ')} Module`);
  }

  return {
    content,
    accuracy: parseFloat((totalAccuracy * 100).toFixed(1)),
    confidence: parseFloat((totalConfidence * 100).toFixed(1)),
    sources,
    thinkingSteps,
  };
}

export async function generateChatResponse(
  query: string,
  modelId: string,
  defectLogs: DefectLog[],
  metrics: QualityMetric[],
  conversationHistory: ChatMessage[] = []
): Promise<{
  content: string;
  accuracy: number;
  confidence: number;
  responseTime: number;
  tokensUsed: number;
  sources: string[];
  thinkingSteps: string[];
}> {
  const model = LLM_MODELS.find(m => m.id === modelId) || LLM_MODELS[0];
  const startTime = Date.now();

  // Simulate processing delay based on model speed
  const delayMs = model.responseSpeed === 'fast' ? 800 + Math.random() * 600
    : model.responseSpeed === 'medium' ? 1500 + Math.random() * 1000
    : 2500 + Math.random() * 1500;

  await new Promise(resolve => setTimeout(resolve, delayMs));

  // Classify query
  const categories = classifyQuery(query);

  // Extract context from plant data
  const context = extractContext(query, defectLogs, metrics);

  // Generate response
  const result = generateResponseForCategories(categories, query, model, context);

  const responseTime = Date.now() - startTime;
  const tokensUsed = Math.floor(query.length / 4 + result.content.length / 4 + Math.random() * 100);

  // Slight randomization of accuracy/confidence based on conversation context
  const historyBonus = Math.min(conversationHistory.length * 0.003, 0.02);
  const finalAccuracy = Math.min(result.accuracy + historyBonus * 100, 99.5);
  const finalConfidence = Math.min(result.confidence + historyBonus * 50, 99.0);

  return {
    content: result.content,
    accuracy: parseFloat(finalAccuracy.toFixed(1)),
    confidence: parseFloat(finalConfidence.toFixed(1)),
    responseTime,
    tokensUsed,
    sources: result.sources,
    thinkingSteps: result.thinkingSteps,
  };
}

export function getThinkingStepsForModel(modelId: string): string[] {
  const model = LLM_MODELS.find(m => m.id === modelId) || LLM_MODELS[0];
  const base = [
    `Initializing ${model.name} model...`,
    'Parsing query for manufacturing quality keywords...',
    'Classifying defect category...',
    'Retrieving knowledge base entries...',
    'Cross-referencing with plant data...',
    'Analyzing process parameters...',
    'Generating root cause hypotheses...',
    'Ranking by probability...',
    'Formulating recommendations...',
    'Computing confidence scores...',
  ];

  if (modelId === 'claude-3.5-sonnet') {
    base.splice(3, 0, 'Building structured reasoning chain...');
    base.splice(6, 0, 'Evaluating constitutional safety constraints...');
  } else if (modelId === 'gpt-4o') {
    base.splice(3, 0, 'Activating multi-modal reasoning pathways...');
    base.splice(7, 0, 'Running chain-of-thought verification...');
  } else if (modelId === 'qualityguard-custom') {
    base.splice(2, 0, 'Loading manufacturing domain embeddings...');
    base.splice(5, 0, 'Querying defect pattern database...');
    base.splice(8, 0, 'Applying industry-specific heuristics...');
  }

  return base;
}
