// ============================================================
// 🔧 API CONFIGURATION — Edit this file to connect your LLM
// ============================================================
//
// HOW TO USE:
// 1. Enter your API key below
// 2. Enter the base URL for your LLM provider
// 3. Select the provider type
// 4. The chat assistant will automatically use real API calls
//
// SUPPORTED PROVIDERS:
//   - 'openai'    → OpenAI API (https://api.openai.com/v1)
//   - 'anthropic' → Anthropic API (https://api.anthropic.com)
//   - 'azure'     → Azure OpenAI (your endpoint + /openai)
//   - 'groq'      → Groq API (https://api.groq.com/openai/v1)
//   - 'ollama'    → Local Ollama (http://localhost:11434)
//   - 'custom'    → Any OpenAI-compatible API
//
// ============================================================

export const API_CONFIG = {
  // 🔑 YOUR API KEY — paste your key between the quotes
  apiKey: '',

  // 🌐 BASE URL — the endpoint for your LLM provider
  // Examples:
  //   OpenAI:    'https://api.openai.com/v1'
  //   Anthropic: 'https://api.anthropic.com'
  //   Azure:     'https://YOUR_RESOURCE.openai.azure.com/openai'
  //   Groq:      'https://api.groq.com/openai/v1'
  //   Ollama:    'http://localhost:11434'
  //   Custom:    'https://your-custom-endpoint.com/v1'
  baseUrl: '',

  // 🤖 MODEL NAME — the model identifier
  // Examples:
  //   OpenAI:    'gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo'
  //   Anthropic: 'claude-3-5-sonnet-20241022', 'claude-3-opus-20240229'
  //   Groq:      'llama-3.3-70b-versatile', 'mixtral-8x7b-32768'
  //   Ollama:    'llama3', 'mistral', 'phi3'
  model: 'gpt-4o',

  // 🌡️ TEMPERATURE — controls randomness (0.0 = deterministic, 1.0 = creative)
  temperature: 0.3,

  // 📏 MAX TOKENS — maximum response length
  maxTokens: 2048,

  // ✅ ENABLED — set to true to use real API calls, false for simulated responses
  enabled: false,

  // 🏢 PROVIDER — select your provider type
  // Options: 'openai' | 'anthropic' | 'azure' | 'groq' | 'ollama' | 'custom'
  provider: 'openai' as 'openai' | 'anthropic' | 'custom' | 'ollama' | 'azure' | 'groq',
};

// ============================================================
// QUICK START EXAMPLES (uncomment one and fill in your key):
// ============================================================

// --- OpenAI Example ---
// export const API_CONFIG = {
//   apiKey: 'sk-proj-xxxxxxxxxxxxxxxxxxxxxxxx',
//   baseUrl: 'https://api.openai.com/v1',
//   model: 'gpt-4o',
//   temperature: 0.3,
//   maxTokens: 2048,
//   enabled: true,
//   provider: 'openai' as 'openai' | 'anthropic' | 'custom' | 'ollama' | 'azure' | 'groq',
// };

// --- Groq Example (Free tier available) ---
// export const API_CONFIG = {
//   apiKey: 'gsk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
//   baseUrl: 'https://api.groq.com/openai/v1',
//   model: 'llama-3.3-70b-versatile',
//   temperature: 0.3,
//   maxTokens: 2048,
//   enabled: true,
//   provider: 'groq' as 'openai' | 'anthropic' | 'custom' | 'ollama' | 'azure' | 'groq',
// };

// --- Ollama Example (Local, free) ---
// export const API_CONFIG = {
//   apiKey: '',
//   baseUrl: 'http://localhost:11434',
//   model: 'llama3',
//   temperature: 0.3,
//   maxTokens: 2048,
//   enabled: true,
//   provider: 'ollama' as 'openai' | 'anthropic' | 'custom' | 'ollama' | 'azure' | 'groq',
// };

// --- Anthropic Example ---
// export const API_CONFIG = {
//   apiKey: 'sk-ant-xxxxxxxxxxxxxxxxxxxxxxxx',
//   baseUrl: 'https://api.anthropic.com',
//   model: 'claude-3-5-sonnet-20241022',
//   temperature: 0.3,
//   maxTokens: 2048,
//   enabled: true,
//   provider: 'anthropic' as 'openai' | 'anthropic' | 'custom' | 'ollama' | 'azure' | 'groq',
// };

// --- Azure OpenAI Example ---
// export const API_CONFIG = {
//   apiKey: 'your-azure-api-key',
//   baseUrl: 'https://your-resource.openai.azure.com/openai',
//   model: 'gpt-4o',
//   temperature: 0.3,
//   maxTokens: 2048,
//   enabled: true,
//   provider: 'azure' as 'openai' | 'anthropic' | 'custom' | 'ollama' | 'azure' | 'groq',
// };

// --- Custom OpenAI-Compatible API ---
// export const API_CONFIG = {
//   apiKey: 'your-custom-api-key',
//   baseUrl: 'https://your-api-endpoint.com/v1',
//   model: 'your-model-name',
//   temperature: 0.3,
//   maxTokens: 2048,
//   enabled: true,
//   provider: 'custom' as 'openai' | 'anthropic' | 'custom' | 'ollama' | 'azure' | 'groq',
// };
