import { useState, useMemo, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import IncidentForm from './components/IncidentForm';
import AnalysisResult from './components/AnalysisResult';
import IncidentLog from './components/IncidentLog';
import Documentation from './components/Documentation';
import ChatAssistant from './components/ChatAssistant';
import ApiSettings from './components/ApiSettings';
import { Page, AnalysisResult as AnalysisResultType, DefectLog } from './types';
import { generateQualityMetrics, generateDefectLogs, getKPIs } from './data/syntheticData';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResultType | null>(null);

  // Generate synthetic data once
  const metrics = useMemo(() => generateQualityMetrics(), []);
  const defectLogs = useMemo(() => generateDefectLogs(), []);
  const kpis = useMemo(() => getKPIs(defectLogs, metrics), [defectLogs, metrics]);

  const handleAnalysisComplete = useCallback((result: AnalysisResultType) => {
    setAnalysisResult(result);
    setCurrentPage('analyze');
  }, []);

  const handleBackToForm = useCallback(() => {
    setAnalysisResult(null);
  }, []);

  const handleViewAnalysis = useCallback((_log: DefectLog) => {
    setCurrentPage('analyze');
    setAnalysisResult(null);
  }, []);

  const navigate = useCallback((page: Page) => {
    if (page === 'analyze') {
      setAnalysisResult(null);
    }
    setCurrentPage(page);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar
        currentPage={currentPage}
        onNavigate={navigate}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      <main
        className={`transition-all duration-300 ${
          sidebarCollapsed ? 'ml-16' : 'ml-64'
        }`}
      >
        {/* Top bar */}
        <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200 px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs text-slate-500">System Online · 5 Production Lines Monitored</span>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-500">
              <span>{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
              <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded-md font-medium">v2.1.0</span>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-6">
          {currentPage === 'dashboard' && (
            <Dashboard
              metrics={metrics}
              defectLogs={defectLogs}
              kpis={kpis}
              onNavigate={navigate}
            />
          )}

          {currentPage === 'analyze' && (
            analysisResult ? (
              <AnalysisResult result={analysisResult} onBack={handleBackToForm} />
            ) : (
              <IncidentForm
                defectLogs={defectLogs}
                metrics={metrics}
                onAnalysisComplete={handleAnalysisComplete}
              />
            )
          )}

          {currentPage === 'log' && (
            <IncidentLog defectLogs={defectLogs} onViewAnalysis={handleViewAnalysis} />
          )}

          {currentPage === 'docs' && <Documentation />}

          {currentPage === 'chat' && (
            <ChatAssistant defectLogs={defectLogs} metrics={metrics} />
          )}

          {currentPage === 'settings' && <ApiSettings />}
        </div>
      </main>
    </div>
  );
}
