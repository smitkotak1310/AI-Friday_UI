"""
Enhanced Database Analysis Multi-Agent System with MCP Integration
A sophisticated multi-agent system that analyzes database schemas, executes natural language queries,
and creates interactive visualizations.

Architecture:
1. Schema Agent - Reads and understands database schema with relationships
2. Query Agent - Converts natural language to SQL using LLM (supports complex GROUP BY)
3. Execution Agent - Executes SQL queries via MCP tools or direct execution
4. Visualization Agent - Creates intelligent charts from query results

Features:
- Automatic schema discovery with foreign keys
- Complex query support (GROUP BY, JOIN, aggregations)
- Intelligent visualization selection
- Error recovery and helpful feedback
- Sample complex database with multiple tables
"""

from typing import TypedDict, Annotated, Literal, Optional, List, Dict, Any
from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from pydantic import BaseModel, Field, field_validator
from langgraph.types import Command
import re
import asyncio
import json
import os
import sqlite3
from typing import TypedDict, Annotated, List, Dict, Any, Optional
from pathlib import Path
from datetime import datetime

import httpx
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
import operator

# Apply nest_asyncio to allow nested event loops
import nest_asyncio
nest_asyncio.apply()

# Configuration
API_KEY = "sk-QibkR-xrOxD2AsMgdaL0Pg"
DB_PATH = "./employee_details.db"  # Path to your .db file

# Create token cache directory
token_dir = "./token"
os.makedirs(token_dir, exist_ok=True)
os.environ["TIKTOKEN_CACHE_DIR"] = token_dir

# Initialize LLM
http_client = httpx.Client(verify=False)
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key=API_KEY,
    http_client=http_client,
    temperature=0  # More deterministic SQL generation
)


# ============= STATE DEFINITION =============

class DatabaseState(TypedDict):
    """State that flows through the workflow"""
    db_path: str
    schema_info: Dict[str, Any]
    user_query: str
    reject_reason: str
    sql_query: str
    query_results: List[Dict]
    visualization_type: str
    visualization_data: Dict
    history: Annotated[list, operator.add]
    next_agent: str
    error: str
    query_metadata: Dict  # Store info about query type
    summary: str
    user_role : str
    user_empid: str


# ============= SCHEMA AGENT =============

class SchemaAgent:
    """Agent that reads and understands database schema with relationships"""
    
    def __init__(self):
        self.name = "Schema Agent"
    
    def read_schema(self, db_path: str) -> Dict[str, Any]:
        """Read comprehensive database schema from SQLite file"""
        if not os.path.exists(db_path):
            return {"error": f"Database file not found: {db_path}"}
        
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Get all tables
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = cursor.fetchall()
            
            schema = {}
            for (table_name,) in tables:
                # Get table info
                cursor.execute(f"PRAGMA table_info({table_name});")
                columns = cursor.fetchall()
                
                # Get foreign keys
                cursor.execute(f"PRAGMA foreign_key_list({table_name});")
                foreign_keys = cursor.fetchall()
                
                schema[table_name] = {
                    "columns": [
                        {
                            "id": col[0],
                            "name": col[1],
                            "type": col[2],
                            "not_null": bool(col[3]),
                            "default": col[4],
                            "primary_key": bool(col[5])
                        }
                        for col in columns
                    ],
                    "foreign_keys": [
                        {
                            "column": fk[3],
                            "references_table": fk[2],
                            "references_column": fk[4]
                        }
                        for fk in foreign_keys
                    ]
                }
                
                # Get sample row count
                cursor.execute(f"SELECT COUNT(*) FROM {table_name};")
                count = cursor.fetchone()[0]
                schema[table_name]["row_count"] = count
                
                # Get sample data (first 3 rows)
                cursor.execute(f"SELECT * FROM {table_name} LIMIT 3;")
                sample_rows = cursor.fetchall()
                col_names = [desc[0] for desc in cursor.description]
                schema[table_name]["sample_data"] = [
                    dict(zip(col_names, row)) for row in sample_rows
                ]
            
            conn.close()
            return schema
            
        except Exception as e:
            return {"error": str(e)}
    
    def format_schema_display(self, schema: Dict) -> str:
        """Format schema for display with relationships"""
        if "error" in schema:
            return f"❌ Error: {schema['error']}"
        
        output = []
        output.append("\n" + "="*80)
        output.append("🗄️  DATABASE SCHEMA ANALYSIS")
        output.append("="*80)
        
        for table_name, table_info in schema.items():
            output.append(f"\n┌─ 📋 Table: {table_name.upper()}")
            output.append(f"│  📊 Rows: {table_info['row_count']:,}")
            output.append("│")
            output.append("│  📐 Columns:")
            
            for col in table_info['columns']:
                pk = " 🔑 PRIMARY KEY" if col['primary_key'] else ""
                nn = " ⚠️ NOT NULL" if col['not_null'] else ""
                output.append(f"│     • {col['name']:20} {col['type']:15}{pk}{nn}")
            
            # Show foreign keys
            if table_info['foreign_keys']:
                output.append("│")
                output.append("│  🔗 Relationships:")
                for fk in table_info['foreign_keys']:
                    output.append(
                        f"│     • {fk['column']} → {fk['references_table']}.{fk['references_column']}"
                    )
            
            # Show sample data
            if table_info['sample_data']:
                output.append("│")
                output.append("│  📝 Sample Data (first row):")
                first_row = table_info['sample_data'][0]
                for key, value in first_row.items():
                    display_value = str(value)[:50]
                    output.append(f"│     • {key}: {display_value}")
            
            output.append("└" + "─"*78)
        
        output.append("\n" + "="*80)
        output.append("✅ I'm your Database Analysis Assistant!")
        output.append("="*80)
        output.append("\n💡 You can ask me questions like:")
        output.append("   • 'Show all records from [table_name]'")
        output.append("   • 'What is the total sales by category?'")
        output.append("   • 'Count orders per customer'")
        output.append("   • 'Show average price grouped by supplier'")
        output.append("   • 'Get top 5 customers by total order amount'")
        output.append("   • 'Compare sales across different regions'")
        output.append("="*80)
        
        return "\n".join(output)
    
    def execute(self, state: DatabaseState) -> DatabaseState:
        """Execute schema reading"""
        db_path = state["db_path"]
        
        print(f"\n{'='*80}")
        print(f"🤖 AGENT: {self.name}")
        print(f"📂 Database: {db_path}")
        print(f"{'='*80}")
        
        schema = self.read_schema(db_path)
        schema_display = self.format_schema_display(schema)
        
        print(schema_display)
        
        history_entry = f"📊 {self.name}: Analyzed database schema"
        
        if "error" in schema:
            return {
                **state,
                "schema_info": schema,
                "history": [history_entry, f"  ❌ Error: {schema['error']}"],
                "next_agent": END,
                "error": schema["error"]
            }
        
        table_count = len(schema)
        total_rows = sum(t["row_count"] for t in schema.values())
        
        return {
            **state,
            "schema_info": schema,
            "history": [
                history_entry,
                f"  ✅ Found {table_count} table(s) with {total_rows:,} total rows"
            ],
            "next_agent": "query_agent" if state.get("user_query") else END
        }


# ============= QUERY AGENT =============

class QueryAgent:
    """Agent that converts natural language to SQL with complex query support"""
    
    def __init__(self, llm):
        self.name = "Query Agent"
        self.llm = llm
    
    def format_schema_for_llm(self, schema: Dict) -> str:
        """Format schema with relationships for LLM context"""
        schema_parts = []
        
        for table_name, table_info in schema.items():
            # Table definition
            columns = []
            for col in table_info['columns']:
                col_def = f"{col['name']} {col['type']}"
                if col['primary_key']:
                    col_def += " PRIMARY KEY"
                if col['not_null']:
                    col_def += " NOT NULL"
                columns.append(col_def)
            
            table_def = f"Table: {table_name}\n  Columns: {', '.join(columns)}"
            
            # Foreign keys
            if table_info['foreign_keys']:
                fk_list = [
                    f"{fk['column']} REFERENCES {fk['references_table']}({fk['references_column']})"
                    for fk in table_info['foreign_keys']
                ]
                table_def += f"\n  Foreign Keys: {', '.join(fk_list)}"
            
            # Sample data hint
            if table_info['sample_data']:
                sample = table_info['sample_data'][0]
                sample_str = ", ".join([f"{k}={v}" for k, v in list(sample.items())[:3]])
                table_def += f"\n  Sample: {sample_str}"
            
            schema_parts.append(table_def)
        
        return "\n\n".join(schema_parts)
    
    def generate_sql(self, user_query: str, schema: Dict) -> Dict[str, Any]:
        """Use LLM to generate SQL from natural language with metadata"""
        
        schema_str = self.format_schema_for_llm(schema)
        
        prompt = f"""You are an expert SQL developer. Convert the natural language query to a valid SQLite SQL query.

Database Schema:
{schema_str}

User Query: "{user_query}"

IMPORTANT RULES:
1. Return ONLY the SQL query, no explanations or markdown
2. Use proper SQLite syntax
3. For complex queries, use JOINs when data spans multiple tables
4. Support GROUP BY, ORDER BY, HAVING clauses as needed
5. For aggregations, use appropriate functions (SUM, COUNT, AVG, MAX, MIN)
6. Limit SELECT results to 100 rows unless user specifies otherwise
7. Use table aliases for clarity in JOINs
8. Ensure all column and table names match the schema exactly
9. For "top N" queries, use ORDER BY with LIMIT
10. Handle edge cases like NULL values appropriately

Examples of complex queries you should handle:
- "total sales by category" → GROUP BY with SUM
- "top 5 customers" → ORDER BY + LIMIT
- "average price per supplier" → JOIN + GROUP BY + AVG
- "count orders per month" → GROUP BY date functions

SQL Query:"""

        try:
            response = self.llm.invoke(prompt)
            sql = response.content.strip()
            
            # Clean up markdown formatting
            if sql.startswith('```'):
                sql = sql.split('```')[1]
                if sql.startswith('sql'):
                    sql = sql[3:]
                sql = sql.strip()
            
            # Remove trailing semicolons
            sql = sql.rstrip(';')
            
            # Analyze query type
            sql_upper = sql.upper()
            metadata = {
                "is_aggregation": any(kw in sql_upper for kw in ['GROUP BY', 'COUNT(', 'SUM(', 'AVG(', 'MAX(', 'MIN(']),
                "has_join": 'JOIN' in sql_upper,
                "has_order": 'ORDER BY' in sql_upper,
                "is_select": sql_upper.startswith('SELECT'),
                "complexity": "complex" if ('GROUP BY' in sql_upper or 'JOIN' in sql_upper) else "simple"
            }
            
            return {
                "sql": sql,
                "metadata": metadata,
                "error": None
            }
            
        except Exception as e:
            return {
                "sql": None,
                "metadata": {},
                "error": str(e)
            }
    
    def execute(self, state: DatabaseState) -> DatabaseState:
        """Execute query generation"""
        user_query = state["user_query"]
        schema = state["schema_info"]
        
        print(f"\n{'='*80}")
        print(f"🤖 AGENT: {self.name}")
        print(f"💬 User Query: '{user_query}'")
        print(f"{'='*80}")
        print(f"🧠 Analyzing query and generating SQL...")
        
        result = self.generate_sql(user_query, schema)
        
        if result["error"]:
            print(f"\n❌ SQL Generation Error: {result['error']}")
            history_entry = f"🔍 {self.name}: Failed to generate SQL"
            return {
                **state,
                "history": [history_entry, f"  ❌ {result['error']}"],
                "next_agent": END,
                "error": result["error"]
            }
        
        sql_query = result["sql"]
        metadata = result["metadata"]
        
        print(f"\n✅ Generated SQL:")
        print(f"   {sql_query}")
        print(f"\n📊 Query Analysis:")
        print(f"   • Type: {metadata['complexity'].upper()}")
        if metadata['is_aggregation']:
            print(f"   • Contains aggregation functions")
        if metadata['has_join']:
            print(f"   • Joins multiple tables")
        if metadata['has_order']:
            print(f"   • Results will be sorted")
        
        history_entry = f"🔍 {self.name}: Generated {metadata['complexity']} SQL query"
        
        return {
            **state,
            "sql_query": sql_query,
            "query_metadata": metadata,
            "history": [history_entry, f"  ✅ SQL: {sql_query[:100]}..."],
            "next_agent": "sqlqueryvalidation_agent"
        }

class SQLValidationResult(BaseModel):
    """Validation result for user query relevance"""
    relevance_score: float = Field(ge=0.0, le=1.0, description="Whether the sql query is complying with user role permisions and safety of database")
    reasoning: str = Field(description="Explanation of the validation decision")
    
    @field_validator('relevance_score')
    @classmethod
    def score_must_be_valid(cls, v):
        if not 0 <= v <= 1:
            raise ValueError('Score must be between 0 and 1')
        return v

class SQLQueryValidationAgent:

    def __init__(self, llm):
        self.name = "SQL query validation Agent"
        self.llm = llm


    def execute(self, state: DatabaseState) -> DatabaseState:
        """Validate the generated SQL query for correctness and safety and role operations"""
        print("SQL Validation Node: Checking SQL query permissions...")
        prompt = f"""You are a SQL query validation agent for a database chatbot system. 
        Analyze if the user's query is relevant to database operations and data retrieval. 
        User Query: "{state['user_query']}"
        User Role: "{state['user_role']}"
        Role permissions:-
        if role is: 
            1. Employee
                - Can view their own data in all tables - only matches his emp.id {state['user_empid']}
                - query must include {state['user_empid']} and output should be one row
            2. Admin
                - Can view all data
            3. HR
                - Can view all employee data from all these tables except for [Salaries]
                - Can perform only read queries
            4. Finance
                - Can view all data from only these tables:- [Employees, Salaries, Departments, Jobs]
                - Can perform only read queries
        Determine: 
        1. Is this query complying with the user's role permissions? 
        2. is the query destructive
        Respond with ONLY a JSON object matching this structure:
        {{
            "relevance_score": 0.9,
            "reasoning": "explanation to user for rejection"
        }} 
    """
        try:
            messages = [HumanMessage(content=prompt)]
            response = self.llm.with_structured_output(SQLValidationResult).invoke(messages)
            if response.relevance_score >= 0.6:
                print(f"SQL User Query Validation passed with score: '{response.relevance_score}'")
                return {**state, "next_agent":"execution_agent"} 
            else:
                print(f"SQL User Query Validation failed with reason: '{response.reasoning}'")
                return {**state, "next_agent":END, "reject_reason":response.reasoning}
        except Exception as e:
            print(e)
            return {**state, "next_agent":END, "error": str(e)}
        #return {**state, "next_agent":END, "summary" :response.summary}


# ============= EXECUTION AGENT =============

class ExecutionAgent:
    """Agent that executes SQL queries with comprehensive error handling"""
    
    def __init__(self, mcp_client):
        self.name = "Execution Agent"
        self.mcp_client = mcp_client
        self.tools_cache = None
    
    async def get_tool(self, tool_name: str):
        """Get tool from MCP client"""
        if self.tools_cache is None and self.mcp_client:
            try:
                self.tools_cache = await self.mcp_client.get_tools()
            except:
                self.tools_cache = []
        
        if self.tools_cache:
            return next((tool for tool in self.tools_cache if tool.name == tool_name), None)
        return None
    
    async def execute_query_async(self, db_path: str, sql_query: str) -> Dict[str, Any]:
        """Execute SQL query using MCP tool or direct execution"""
        
        # Try MCP tool first
        query_tool = await self.get_tool("execute_query")
        
        if query_tool:
            try:
                result_str = await query_tool.ainvoke({
                    "db_path": db_path,
                    "query": sql_query
                })
                result = json.loads(result_str)
                return {
                    "results": result.get("results", []),
                    "method": "MCP",
                    "error": None
                }
            except Exception as e:
                print(f"⚠️  MCP tool failed: {e}, using direct execution")
        
        # Fallback to direct execution
        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute(sql_query)
            
            # Handle SELECT queries
            if sql_query.strip().upper().startswith('SELECT'):
                rows = cursor.fetchall()
                results = [dict(row) for row in rows]
            else:
                conn.commit()
                results = [{"affected_rows": cursor.rowcount, "message": "Query executed successfully"}]
            
            conn.close()
            return {
                "results": results,
                "method": "Direct",
                "error": None
            }
            
        except sqlite3.Error as e:
            return {
                "results": [],
                "method": "Direct",
                "error": f"Database error: {str(e)}"
            }
        except Exception as e:
            return {
                "results": [],
                "method": "Direct",
                "error": f"Execution error: {str(e)}"
            }
    
    async def execute_async(self, state: DatabaseState) -> DatabaseState:
        """Execute SQL query"""
        db_path = state["db_path"]
        sql_query = state["sql_query"]
        
        print(f"\n{'='*80}")
        print(f"🤖 AGENT: {self.name}")
        print(f"⚡ Executing SQL query...")
        print(f"{'='*80}")
        
        result = await self.execute_query_async(db_path, sql_query)
        
        if result["error"]:
            print(f"\n❌ Query Execution Error: {result['error']}")
            history_entry = f"⚡ {self.name}: Query execution failed"
            return {
                **state,
                "history": [history_entry, f"  ❌ {result['error']}"],
                "next_agent": END,
                "error": result["error"]
            }
        
        results = result["results"]
        method = result["method"]
        
        print(f"\n✅ Query executed successfully via {method}!")
        print(f"   📊 Retrieved {len(results):,} record(s)")
        
        # Display results preview
        if results and len(results) > 0:
            print(f"\n📋 Results Preview (first 3 rows):")
            for i, row in enumerate(results[:3], 1):
                # Format row nicely
                row_str = ", ".join([f"{k}={v}" for k, v in list(row.items())[:5]])
                if len(row) > 5:
                    row_str += ", ..."
                print(f"   {i}. {row_str}")
            
            if len(results) > 3:
                print(f"   ... and {len(results) - 3} more rows")
        
        history_entry = f"⚡ {self.name}: Executed SQL query via {method}"
        
        return {
            **state,
            "query_results": results,
            "history": [history_entry, f"  ✅ Retrieved {len(results):,} record(s)"],
            "next_agent": "visualization_agent" if len(results) > 0 else END
        }


# ============= VISUALIZATION AGENT =============

class VisualizationAgent:
    """Agent that creates intelligent visualizations from query results"""
    
    def __init__(self, llm):
        self.name = "Visualization Agent"
        self.llm = llm
    
    def determine_visualization(self, results: List[Dict], metadata: Dict, user_query: str) -> str:
        """Intelligently determine best visualization type"""
        if not results:
            return "none"
        
        first_row = results[0]
        num_columns = len(first_row)
        num_rows = len(results)
        
        # Analyze column types
        numeric_cols = []
        text_cols = []
        date_cols = []
        
        for key, value in first_row.items():
            if isinstance(value, (int, float)):
                numeric_cols.append(key)
            elif isinstance(value, str):
                # Check if it might be a date
                try:
                    datetime.strptime(value[:10], '%Y-%m-%d')
                    date_cols.append(key)
                except:
                    text_cols.append(key)
        
        # Decision logic
        if num_rows == 1 and num_columns == 1:
            return "metric"
        
        elif metadata.get("is_aggregation") and len(numeric_cols) >= 1:
            # For GROUP BY queries with aggregations
            if num_rows <= 20:
                return "bar_chart"
            else:
                return "table"
        
        elif len(numeric_cols) >= 2 and num_rows <= 50:
            # Multiple numeric columns - could be comparison
            return "multi_bar_chart"
        
        elif len(date_cols) >= 1 and len(numeric_cols) >= 1:
            return "time_series"
        
        elif num_rows <= 15 and len(numeric_cols) >= 1:
            return "bar_chart"
        
        else:
            return "table"
    
    def create_visualization_data(self, results: List[Dict], viz_type: str, metadata: Dict) -> Dict:
        """Prepare data for visualization"""
        
        if viz_type == "metric":
            first_row = results[0]
            key = list(first_row.keys())[0]
            value = first_row[key]
            
            # Format large numbers
            if isinstance(value, (int, float)) and value >= 1000:
                formatted = f"{value:,.2f}" if isinstance(value, float) else f"{value:,}"
            else:
                formatted = str(value)
            
            return {
                "type": "metric",
                "value": value,
                "formatted_value": formatted,
                "label": key.replace('_', ' ').title()
            }
        
        elif viz_type == "bar_chart":
            first_row = results[0]
            keys = list(first_row.keys())
            
            # Find label and value columns
            numeric_cols = [k for k, v in first_row.items() if isinstance(v, (int, float))]
            text_cols = [k for k in keys if k not in numeric_cols]
            
            label_col = text_cols[0] if text_cols else keys[0]
            value_col = numeric_cols[0] if numeric_cols else keys[-1]
            
            labels = [str(row.get(label_col, ''))[:30] for row in results]
            values = [float(row.get(value_col, 0)) if isinstance(row.get(value_col), (int, float)) else 0 
                     for row in results]
            
            return {
                "type": "bar_chart",
                "labels": labels,
                "values": values,
                "x_label": label_col.replace('_', ' ').title(),
                "y_label": value_col.replace('_', ' ').title()
            }
        
        elif viz_type == "multi_bar_chart":
            first_row = results[0]
            numeric_cols = [k for k, v in first_row.items() if isinstance(v, (int, float))]
            text_cols = [k for k in first_row.keys() if k not in numeric_cols]
            
            label_col = text_cols[0] if text_cols else list(first_row.keys())[0]
            
            return {
                "type": "multi_bar_chart",
                "labels": [str(row.get(label_col, ''))[:20] for row in results],
                "datasets": [
                    {
                        "name": col.replace('_', ' ').title(),
                        "values": [float(row.get(col, 0)) for row in results]
                    }
                    for col in numeric_cols[:3]  # Limit to 3 series
                ],
                "x_label": label_col.replace('_', ' ').title()
            }
        
        else:  # table
            return {
                "type": "table",
                "columns": list(results[0].keys()) if results else [],
                "rows": results
            }
    
    def display_visualization(self, viz_data: Dict):
        """Display visualization in console with enhanced formatting"""
        viz_type = viz_data["type"]
        
        print(f"\n{'='*80}")
        print(f"📊 VISUALIZATION: {viz_type.replace('_', ' ').upper()}")
        print(f"{'='*80}")
        
        if viz_type == "metric":
            print(f"\n   🎯 {viz_data['label']}")
            print(f"   {'─'*50}")
            print(f"   {viz_data['formatted_value']}")
            print()
        
        elif viz_type == "bar_chart":
            print(f"\n   {viz_data['y_label']} by {viz_data['x_label']}")
            print(f"   {'─'*70}")
            
            max_value = max(viz_data['values']) if viz_data['values'] else 1
            
            for label, value in zip(viz_data['labels'][:15], viz_data['values'][:15]):
                bar_length = int((value / max_value) * 50) if max_value > 0 else 0
                bar = '█' * bar_length
                
                # Format value
                if value >= 1000:
                    value_str = f"{value:,.0f}"
                else:
                    value_str = f"{value:.2f}"
                
                print(f"   {label:25} │{bar} {value_str}")
            
            if len(viz_data['labels']) > 15:
                print(f"\n   ... and {len(viz_data['labels']) - 15} more rows")
        
        elif viz_type == "multi_bar_chart":
            print(f"\n   Comparison by {viz_data['x_label']}")
            print(f"   {'─'*70}")
            
            # Show legend
            print("\n   Legend:")
            for i, dataset in enumerate(viz_data['datasets']):
                symbols = ['█', '▓', '▒']
                print(f"   {symbols[i % 3]} {dataset['name']}")
            
            print()
            
            for i, label in enumerate(viz_data['labels'][:10]):
                print(f"   {label:20}", end=" ")
                for j, dataset in enumerate(viz_data['datasets']):
                    value = dataset['values'][i]
                    symbols = ['█', '▓', '▒']
                    print(f" {symbols[j % 3]}{value:8.1f}", end="")
                print()
            
            if len(viz_data['labels']) > 10:
                print(f"\n   ... and {len(viz_data['labels']) - 10} more rows")
        
        elif viz_type == "table":
            columns = viz_data['columns']
            rows = viz_data['rows']
            
            # Calculate column widths
            col_widths = {col: max(len(str(col)), 15) for col in columns}
            
            # Print header
            header = " │ ".join([f"{col[:col_widths[col]]:^{col_widths[col]}}" for col in columns])
            print(f"\n   {header}")
            print(f"   {'─' * len(header)}")
            
            # Print rows (limit to 20)
            for row in rows[:20]:
                values = [str(row.get(col, ''))[:col_widths[col]] for col in columns]
                print(f"   {' │ '.join([f'{v:<{col_widths[col]}}' for v, col in zip(values, columns)])}")
            
            if len(rows) > 20:
                print(f"\n   ... and {len(rows) - 20} more rows")
        
        print(f"\n{'='*80}")
    
    def execute(self, state: DatabaseState) -> DatabaseState:
        """Execute visualization creation"""
        results = state["query_results"]
        user_query = state["user_query"]
        metadata = state.get("query_metadata", {})
        
        print(f"\n{'='*80}")
        print(f"🤖 AGENT: {self.name}")
        print(f"{'='*80}")
        print(f"🎨 Analyzing results and creating visualization...")
        
        viz_type = self.determine_visualization(results, metadata, user_query)
        viz_data = self.create_visualization_data(results, viz_type, metadata)
        
        print(f"   Selected visualization: {viz_type.replace('_', ' ').upper()}")
        
        self.display_visualization(viz_data)
        
        history_entry = f"📈 {self.name}: Created {viz_type} visualization"
        
        return {
            **state,
            "visualization_type": viz_type,
            "visualization_data": viz_data,
            "history": [history_entry, f"  ✅ Rendered {viz_type} with {len(results)} data points"],
            "next_agent": "summarizer_agent"
        }

class ValidationResult(BaseModel):
    """Validation result for user query relevance"""
    relevance_score: float = Field(ge=0.0, le=1.0, description="Whether the query is relevant to database operations. Relevance score between 0 and 1")
    reasoning: str = Field(description="Explanation of the validation decision")
    
    @field_validator('relevance_score')
    @classmethod
    def score_must_be_valid(cls, v):
        if not 0 <= v <= 1:
            raise ValueError('Score must be between 0 and 1')
        return v

class UserQueryValidationAgent:
    def __init__(self, llm):
        self.name = "User Query Validation Agent"
        self.llm = llm


    def execute(self, state: DatabaseState) -> Command[Literal["query_agent", END]]:
        """Validate user query for relevance and safety"""
        print("🔍 Validation Node: Checking query relevance...")
        prompt = f"""You are a query validation agent for a database chatbot system.
Analyze if the user's query is relevant to database operations and data retrieval.

User Query: "{state['user_query']}"

Determine:
1. Is this query asking for data from a database?
2. Can this be translated into a SQL query?

Respond with ONLY a JSON object matching this structure:
{{
    "relevance_score": 0.9,
    "reasoning": "explanation for the score",
}}"""
        
        messages = [HumanMessage(content=prompt)]
        response = self.llm.invoke(messages)
        
        # Parse structured output
        try:
            json_match = re.search(r'\{.*\}', response.content, re.DOTALL)
            if json_match:
                result_dict = json.loads(json_match.group())
                validation_result = ValidationResult(**result_dict)
            else:
                # Fallback
                validation_result = ValidationResult(
                    relevance_score=0.7,
                    reasoning="Could not parse validation result",
                )
        except Exception as e:
            print(f"⚠️ Validation parsing error: {e}")
            validation_result = ValidationResult(
                relevance_score=0.5,
                reasoning="Validation error, proceeding with caution",
            )
        
        if validation_result.relevance_score >=0.6:
            print(f"User Query Validation passed with score: '{validation_result.relevance_score}'")
            return {**state, "next_agent":"schema_agent"} 
        else:
            print(f"User Query Validation faild with reason: '{validation_result.reasoning}'")
            return {**state, "next_agent":END, "reject_reason":validation_result.reasoning}

class Summary(BaseModel):
    """Summary of query results"""
    summary: str

class SummarizerAgent:
    def __init__(self, llm):
        self.name = "Summarizer Agent"
        self.llm = llm


    def execute(self, state: DatabaseState) -> DatabaseState:
        """Summarize query results"""
        print("Summarization Node: Creating summary...")
        prompt = f"""You are a summarization agent for a database chatbot system.
Your task is to create a concise summary of the query results.

User Query: "{state['user_query']}"

SQL query is ran and these are the tool results:
 Tool Results:
 {state["query_results"]}

Answer and the user based on the tool results. Provide a brief summary of the results in 2-3 sentences.
"""
        
        messages = [HumanMessage(content=prompt)]
        response = self.llm.with_structured_output(Summary).invoke(messages)
        return {**state, "next_agent":END, "summary" :response.summary}


# ============= WORKFLOW SETUP =============

def create_database_workflow(mcp_client):
    """Create LangGraph workflow with all agents"""
    
    schema_agent = SchemaAgent()
    query_agent = QueryAgent(llm)
    user_query_validation_agent = UserQueryValidationAgent(llm)
    sqlqueryvalidation_agent = SQLQueryValidationAgent(llm)
    execution_agent = ExecutionAgent(mcp_client)
    visualization_agent = VisualizationAgent(llm)
    summarizer_agent = SummarizerAgent(llm)
    workflow = StateGraph(DatabaseState)
    
    # Add nodes
    workflow.add_node("userqueryvalidationagent", user_query_validation_agent.execute)
    workflow.add_node("schema_agent", schema_agent.execute)
    # workflow.add_node("userqueryvalidationagent", user_query_validation_agent.execute)
    workflow.add_node("query_agent", query_agent.execute)
    workflow.add_node("sqlqueryvalidation_agent", sqlqueryvalidation_agent.execute)
    workflow.add_node("visualization_agent", visualization_agent.execute)
    workflow.add_node("summarizer_agent", summarizer_agent.execute)


    # Wrap async execution agent
    def execution_wrapper(state):
        return asyncio.run(execution_agent.execute_async(state))
    
    workflow.add_node("execution_agent", execution_wrapper)
    
    # Define routing
    def route_next(state: DatabaseState) -> str:
        return state["next_agent"]

    workflow.add_conditional_edges(
        "userqueryvalidationagent",
        route_next,
        {
            "schema_agent": "schema_agent",
            END: END
        }
    )

    # Add edges
    workflow.add_conditional_edges(
        "schema_agent",
        route_next,
        {
            "query_agent": "query_agent",
            END: END
        }
    )
    
    workflow.add_conditional_edges(
        "query_agent",
        route_next,
        {
            "sqlqueryvalidation_agent": "sqlqueryvalidation_agent",
            END: END
        }
    )
    
    workflow.add_conditional_edges(
        "sqlqueryvalidation_agent",
        route_next,
        {
            "execution_agent": "execution_agent",
            END: END
        }
    )


    workflow.add_conditional_edges(
        "execution_agent",
        route_next,
        {
            "visualization_agent": "visualization_agent",
            END: END
        }
    )
    
    workflow.add_conditional_edges(
        "visualization_agent",
        route_next,
        {
            "summarizer_agent": "summarizer_agent"
        }
    )

    # Set entry point
    workflow.set_entry_point("userqueryvalidationagent")

    return workflow.compile()





# ============= MAIN EXECUTION =============

async def analyze_database_async(db_path: str, user_query: str = None):
    """Analyze database with optional query"""
    
    print("🔌 Initializing MCP connection...")
    
    # Try to connect to MCP server
    mcp_client = None
    try:
        mcp_client = MultiServerMCPClient({
            "db_server": {
                "url": "http://localhost:8000/sse",
                "transport": "sse"
            }
        })
        
        tools = await mcp_client.get_tools()
        print(f"✅ MCP Server Connected - {len(tools)} tool(s) available")
    except Exception as e:
        print(f"⚠️  MCP server not available: {e}")
        print(f"   Using direct database execution")
    
    # Create workflow
    workflow = create_database_workflow(mcp_client)
    
    # Initial state
    initial_state = {
        "db_path": db_path,
        "schema_info": {},
        "user_query": user_query or "",
        "sql_query": "",
        "query_results": [],
        "visualization_type": "",
        "visualization_data": {},
        "history": [],
        "next_agent": "schema_agent",
        "error": "",
        "query_metadata": {},
        "user role": "",
        "user_empid": ""
    }
    
    # Run workflow
    final_state = workflow.invoke(initial_state)
    return final_state


def analyze_database(db_path: str, user_query: str = None):
    """Synchronous wrapper"""
    return asyncio.run(analyze_database_async(db_path, user_query))


# ============= MAIN =============

if __name__ == "__main__":
    
    # Test queries covering various complexities
    test_queries = [
        "count of employees with 20k or above salary",
        # Simple queries
        #"Show all products in the Electronics category",
        
        # Aggregation queries
        #"What is the total revenue by category?",
        #"Count orders per customer",
        
        # Complex GROUP BY queries
        #"Show average product price grouped by supplier",
        #"Get total sales amount for each product",
        
        # Multi-table JOIN queries
        #"Show top 5 customers by total order value",
        #"List all orders with customer names and order totals",
        
        # Time-based aggregation
        #"Count orders by month in 2024",
        
        # Complex business query
        #"Which suppliers provide the most profitable products?"
    ]
    
    for i, query in enumerate(test_queries, 1):
        print(f"\n\n{'#'*80}")
        print(f"💬 QUERY {i}/{len(test_queries)}: {query}")
        print(f"{'#'*80}")
        
        try:
            result = analyze_database(DB_PATH, query)
            print(result)
            # Show execution summary

            print("\n"*5)
            print(f"Summary:- {result['summary']}")
            print(f"\n{'='*80}")
            print("📋 EXECUTION SUMMARY:")
            print(f"{'='*80}")
            for step in result["history"]:
                # print(step)
                pass
            
            if result.get("error"):
                print(f"\n❌ Error encountered: {result['error']}")
            
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n\n" + "=" * 80)
    print("✅ ALL ANALYSES COMPLETED!")
    print("=" * 80)
    print("\n💡 Try your own queries!")
    print("   Example: analyze_database(DB_PATH, 'your query here')")
    print("=" * 80)

