# 🚀 Policy Assistant AI with RAG (Retrieval-Augmented Generation)

> **Production-Ready Insurance Policy Question-Answering System**

## 📊 Project Status: ✅ COMPLETE & TESTED

All features implemented, tested (6/6 tests passing), and documented.

---

## ✨ What This Project Does

This is an intelligent **Policy Assistant** that:

1. **📄 Indexes Documents** - Upload PDFs/TXT files containing policy documents
2. **🔍 Semantic Search** - Find relevant policy sections using AI-powered search
3. **🤖 Answers Questions** - DeepSeek LLM answers policy questions based on YOUR documents
4. **📊 Live Dashboard** - Real-time statistics and system health monitoring
5. **💾 Data Persistence** - All data survives app restart

### Example Conversation

```
User: "What's my deductible?"
     ↓
System searches your policy documents
     ↓
Finds: "$500 deductible for all claims"
     ↓
AI Response: "Based on your policy documents, your deductible 
is $500 for all claims."
```

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────┐
│               React Frontend (Port 5173)             │
│  Dashboard | Chat | Documents                        │
└────────────────────┬────────────────────────────────┘
                     │ HTTP/REST API
                     ↓
┌─────────────────────────────────────────────────────┐
│            FastAPI Backend (Port 8000)               │
│                                                      │
│  Input Validation (Local SLM) → ChromaDB Search     │
│              ↓                                        │
│  Document Extraction & Embedding → DeepSeek LLM     │
└────────────────────┬────────────────────────────────┘
                     │
        ┌────────────┴────────────┬──────────────┐
        ↓                         ↓              ↓
   ./chroma_db/          ./uploads/       localStorage
  (Vector DB)        (PDF/TXT Files)    (Chat History)
```

---

## 🎯 Key Features

### ✅ Document Management
- Upload PDF and TXT files (max 50MB)
- Automatic text extraction
- Automatic embedding generation (OpenAI)
- Persistent storage (survives restart)

### ✅ Semantic Search
- Find relevant policy sections by meaning
- Not just keyword matching
- Similarity scoring (0-100%)
- Top-K results (configurable)

### ✅ AI-Powered Q&A
- DeepSeek V3 LLM
- Grounded in YOUR documents (RAG)
- Reduces hallucinations
- Multi-document context support

### ✅ Real-Time Dashboard
- Document count from ChromaDB (live)
- System health monitoring
- Activity tracking
- Auto-refresh every 30 seconds

### ✅ Data Persistence
- Vector embeddings: ChromaDB (permanent)
- Original files: Filesystem (permanent)
- Chat history: localStorage (browser-local)

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
cd backend
pip install -r requirements.txt
```

### 2. Start Backend
```bash
cd backend
python main.py
```

Expected output:
```
✓ ChatOpenAI (DeepSeek V3) initialized successfully
✓ OpenAIEmbeddings initialized successfully
✓ ChromaDB initialized with collection 'policy_documents'
✓ Ollama service status: healthy
```

### 3. Start Frontend (new terminal)
```bash
npm run dev
```

Expected output:
```
✓ Local: http://localhost:5173/
```

### 4. Open Browser
```
http://localhost:5173
```

---

## 🧪 Testing

### Run Comprehensive Test Suite
```bash
cd backend
python test_chromadb_integration.py
```

Expected result:
```
✅ TEST 1: Health Check - PASSED
✅ TEST 2: Document Statistics - PASSED
✅ TEST 3: Upload Document - PASSED
✅ TEST 4: Semantic Search - PASSED
✅ TEST 5: Chat with RAG - PASSED
✅ TEST 6: Dashboard Updates - PASSED

🎉 ALL TESTS PASSED (6/6)
```

---

## 📁 Project Structure

```
UI_FF1/
├── backend/
│   ├── chroma_service.py          ← ChromaDB management
│   ├── document_extractor.py      ← Text extraction
│   ├── main.py                    ← FastAPI server
│   ├── requirements.txt            ← Dependencies
│   ├── test_chromadb_integration.py ← Test suite
│   ├── chroma_db/                 ← Vector database
│   └── uploads/                   ← Uploaded files
│
├── src/
│   ├── App.tsx                    ← Main component
│   ├── components/
│   │   ├── chat/ChatInterface.tsx
│   │   └── dashboard/Dashboard.tsx
│   └── types/
│
└── Documentation/
    ├── QUICK_START_CHROMADB.md
    ├── CHROMADB_IMPLEMENTATION.md
    ├── CHROMADB_COMPLETE_SUMMARY.md
    ├── VISUAL_ARCHITECTURE_GUIDE.md
    └── COMPLETE_CHECKLIST.md
```

---

## 📊 API Endpoints

### Health & Statistics
```bash
GET /health/
├─ Status: ok
├─ External LLM: healthy
├─ ChromaDB: healthy
└─ Indexed documents: 2

GET /documents/stats/
├─ Total indexed: 2
├─ ChromaDB healthy: true
└─ Status: ok
```

### Documents
```bash
POST /upload
├─ Input: multipart/form-data (file)
└─ Output: {"success": true, "indexed": true, "total_indexed": 3}

POST /search/?query=deductible&top_k=3
├─ Input: query parameter
└─ Output: Array of 3 most relevant documents
```

### Chat & RAG
```bash
POST /chat/
├─ Input: {"message": "What's my deductible?", "model": "deepseek"}
└─ Output: {
    "response": "Based on your documents...",
    "used_rag": true,
    "rag_source": "chroma_db",
    "documents_referenced": 3
  }
```

---

## 💻 Technology Stack

### Frontend
- **Framework**: React + TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **HTTP Client**: Fetch API
- **Storage**: localStorage

### Backend
- **Framework**: FastAPI
- **LLM**: DeepSeek V3 (via Azure GenAI Lab)
- **Embeddings**: OpenAI Text-Embedding-3-Large
- **Vector DB**: ChromaDB
- **Local SLM**: Ollama (Llama2, Neural Chat, Mistral)
- **PDF Extraction**: PyPDF

### Infrastructure
- **Backend Port**: 8000
- **Frontend Port**: 5173
- **Vector DB Storage**: SQLite + Parquet
- **File Upload**: Filesystem (./uploads/)
- **Chat History**: Browser localStorage

---

## 🔐 Security Features

✅ **Input Validation**
- Policy-relevance checking (local SLM)
- Irrelevant query filtering
- File type validation (PDF/TXT only)

✅ **File Protection**
- Size limit: 50MB max
- Type validation
- Safe storage in ./uploads/

✅ **Data Privacy**
- LocalStorage for client-side data
- No sensitive data in logs
- CORS protection enabled

---

## 📈 Performance

| Metric | Value |
|--------|-------|
| Embedding Generation | 5-10 seconds per document |
| Search Speed | <1 second |
| Chat Response | 3-10 seconds |
| Dashboard Refresh | 30 seconds (auto) |
| Max File Size | 50 MB |
| Supported File Types | PDF, TXT |
| Vector Dimensions | 3,072 |
| Index Type | HNSW (hierarchical) |

---

## 📚 Documentation

Comprehensive documentation included:

1. **[QUICK_START_CHROMADB.md](./QUICK_START_CHROMADB.md)**
   - Quick reference guide
   - Getting started in 5 minutes
   - Common operations

2. **[CHROMADB_IMPLEMENTATION.md](./CHROMADB_IMPLEMENTATION.md)**
   - Detailed technical implementation
   - Component descriptions
   - Configuration details

3. **[CHROMADB_COMPLETE_SUMMARY.md](./CHROMADB_COMPLETE_SUMMARY.md)**
   - Complete project overview
   - Test results
   - Architecture details

4. **[VISUAL_ARCHITECTURE_GUIDE.md](./VISUAL_ARCHITECTURE_GUIDE.md)**
   - ASCII diagrams
   - Data flow visualizations
   - Component interactions

5. **[COMPLETE_CHECKLIST.md](./COMPLETE_CHECKLIST.md)**
   - Setup checklist
   - Daily usage checklist
   - Troubleshooting guide
   - Deployment checklist

---

## 🧪 How RAG Works

**RAG = Retrieval-Augmented Generation**

### Without RAG
```
Q: "What's my deductible?"
LLM: Generic answer (no document knowledge)
```

### With RAG (This System)
```
Q: "What's my deductible?"
  ↓
1. Search your documents for "deductible"
2. Find: "$500 deductible for all claims"
3. Send to LLM with context
4. LLM answers based on YOUR document
  ↓
A: "Based on your policy, your deductible is $500..."
```

---

## 🎓 Usage Examples

### Upload a Document
```bash
curl -F "file=@policy.pdf" http://localhost:8000/upload

Response:
{
  "success": true,
  "filename": "policy.pdf",
  "indexed": true,
  "total_indexed": 1
}
```

### Search Documents
```bash
curl "http://localhost:8000/search/?query=coverage&top_k=3"

Response:
{
  "query": "coverage",
  "results_count": 2,
  "results": [
    {
      "content": "Your coverage includes...",
      "similarity": 0.87
    }
  ]
}
```

### Ask a Question
```bash
curl -X POST http://localhost:8000/chat/ \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What is covered?",
    "model": "deepseek"
  }'

Response:
{
  "response": "Based on your policy documents, coverage includes...",
  "used_rag": true,
  "rag_source": "chroma_db",
  "documents_referenced": 2
}
```

---

## 🚨 Troubleshooting

### Backend Won't Start?
```bash
# Check Python installed
python --version

# Install dependencies
pip install -r requirements.txt

# Check port 8000 is free
netstat -ano | findstr :8000
```

### Documents Not Indexing?
```bash
# Check file format (PDF or TXT only)
# Check file size (<50MB)
# Check backend logs for errors
tail -f backend.log
```

### Dashboard Stats Not Updating?
```bash
# Check API endpoint
curl http://localhost:8000/documents/stats/

# Refresh browser
Ctrl+R

# Check browser console
F12 → Console tab
```

### RAG Not Working?
```bash
# Check documents uploaded
curl http://localhost:8000/documents/stats/

# Verify search works
curl "http://localhost:8000/search/?query=test&top_k=1"

# Check embeddings
# Verify OpenAI API key in .env
```

---

## 📝 Configuration

### Environment Variables
Create `.env` file in `backend/` directory:
```env
OPENAI_API_KEY=your-api-key-here
OPENAI_BASE_URL=https://genailab.tcs.in
```

### Customization
Edit `backend/main.py` to adjust:
- Document search top_k (default: 3)
- LLM temperature (default: 0.7)
- File size limit (default: 50MB)
- Dashboard refresh rate (default: 30s)

---

## 🔄 Data Persistence

All data is automatically saved to:

1. **Vector Embeddings**: `./chroma_db/`
   - Persists forever
   - Survives app restart
   - Indexed for fast search

2. **Original Files**: `./uploads/`
   - Persists forever
   - Uploaded PDFs and TXTs
   - Source documents

3. **Chat History**: Browser localStorage
   - Persists in browser
   - Lost if browser cache cleared
   - Can be exported

---

## 📊 Dashboard Features

### Statistics Cards
- **Total Documents**: Real count from ChromaDB
- **AI Queries**: Count from chat history
- **System Health**: Overall system status (99.9%)

### Recent Activity
- Document uploads
- Query processing
- System status

### Upload Zone
- Drag & drop support
- File selection
- Real-time progress

---

## 🎯 Next Steps

1. **Upload your policy documents** via Dashboard
2. **Ask policy-specific questions** in Chat
3. **Monitor statistics** in real-time
4. **Export chat history** for records
5. **Scale** by adding more documents

---

## 💡 Tips & Tricks

### For Best Results
- Upload **clear, well-formatted** documents
- Use **specific search terms** ("deductible" vs "cost")
- Ask **complete questions** with context
- Wait for document indexing to complete

### For Production Use
- Backup `chroma_db/` regularly
- Monitor `backend.log` for errors
- Track `/health/` endpoint status
- Review dashboard statistics daily

---

## 🤝 Support

### Documentation
- Check [QUICK_START_CHROMADB.md](./QUICK_START_CHROMADB.md) for quick help
- Review [COMPLETE_CHECKLIST.md](./COMPLETE_CHECKLIST.md) for troubleshooting
- See [VISUAL_ARCHITECTURE_GUIDE.md](./VISUAL_ARCHITECTURE_GUIDE.md) for system design

### Health Check
```bash
curl http://localhost:8000/health/
```

### Run Tests
```bash
python backend/test_chromadb_integration.py
```

---

## 📄 License

This project uses:
- OpenAI APIs for embeddings
- DeepSeek V3 for LLM
- ChromaDB for vector storage
- FastAPI for backend
- React for frontend

---

## ✨ Project Highlights

✅ **Production-Ready**
- Fully tested (6/6 tests passing)
- Comprehensive error handling
- Detailed logging

✅ **Feature-Complete**
- Document upload & indexing
- Semantic search
- RAG-powered Q&A
- Live dashboard
- Data persistence

✅ **Well-Documented**
- Quick start guide
- Technical documentation
- Architecture diagrams
- Troubleshooting guide
- Complete checklist

✅ **Easy to Deploy**
- Docker-ready (optional)
- Environment configuration
- Database persistence
- Error recovery

---

## 🎉 Summary

This is a **complete, production-ready** Policy Assistant AI system featuring:

- 🔍 **Semantic Document Search** - Find relevant policy sections
- 🤖 **RAG-Powered Q&A** - Intelligent answers from your documents
- 📊 **Live Dashboard** - Real-time system statistics
- 💾 **Data Persistence** - Everything saves automatically
- 🧪 **Fully Tested** - All 6 integration tests passing

**Ready to deploy and use today!** 🚀

---

**For detailed information, see the [Documentation](./Documentation/) folder.**

**Questions? Check [COMPLETE_CHECKLIST.md](./COMPLETE_CHECKLIST.md) for troubleshooting.**

---

**Built with ❤️ using ChromaDB, DeepSeek V3, OpenAI Embeddings, FastAPI, and React**

**Status**: ✅ **COMPLETE & OPERATIONAL**
