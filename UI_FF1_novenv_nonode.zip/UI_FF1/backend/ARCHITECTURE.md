# 🚀 Multimodal AI Backend - Complete Architecture

## 📋 Overview

This is a **FastAPI-based multimodal backend** that integrates:
- **External LLM**: DeepSeek V3 via Azure GenAILab MaaS (using LangChain)
- **Local SLMs** (Small Language Models): Llama, Gemma, Qwen, Deepseek-r1
- **Embedding Models**: Azure OpenAI Embeddings + Gte-large (local)

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    FRONTEND (React/Vite)                    │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ HTTP/REST API
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    FASTAPI BACKEND                           │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────┐  ┌──────────────────────┐         │
│  │  External LLM        │  │  Local SLMs          │         │
│  ├──────────────────────┤  ├──────────────────────┤         │
│  │ • DeepSeek V3        │  │ • Llama-3.2-3b-it    │         │
│  │ • ChatOpenAI         │  │ • Gemma-3-4b-it      │         │
│  │ • LangChain          │  │ • Qwen-2.5.1-coder   │         │
│  │ • Azure GenAILab     │  │ • Deepseek-r1        │         │
│  └──────────────────────┘  └──────────────────────┘         │
│                                                               │
│  ┌──────────────────────┐  ┌──────────────────────┐         │
│  │  Embedding Models    │  │  Endpoints           │         │
│  ├──────────────────────┤  ├──────────────────────┤         │
│  │ • OpenAI Ada-002     │  │ POST /chat/          │         │
│  │ • Gte-large (local)  │  │ POST /reason/        │         │
│  │ • LangChain          │  │ POST /embed/         │         │
│  │                      │  │ GET /models/         │         │
│  └──────────────────────┘  │ GET /health/         │         │
│                             └──────────────────────┘         │
└─────────────────────────────────────────────────────────────┘
```

---

## 📁 Project Structure

```
backend/
├── main.py                  # FastAPI app with LangChain integration
├── models.py                # Local SLM management
├── requirements.txt         # Python dependencies
├── .env                     # Configuration (API keys, URLs)
├── test_api.py             # Comprehensive test suite
└── README.md               # This file
```

---

## 🔧 Setup & Installation

### Prerequisites
- Python 3.8+
- Virtual environment (venv)

### 1. Create Virtual Environment
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 2. Install Dependencies
```powershell
pip install -r requirements.txt
```

### 3. Configure Environment Variables
Edit `.env` file:
```properties
OPENAI_API_KEY=your_api_key_here
OPENAI_BASE_URL=https://genailab.tcs.in
```

### 4. Run the Server
```powershell
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The backend will be available at: `http://localhost:8000`

---

## 📚 API Endpoints

### 1. **Health Check**
```
GET /health/
Response: { "status": "ok" }
```

### 2. **List Available Models**
```
GET /models/
Response:
{
  "llm_models": ["deepseek"],
  "slm_models": ["llama", "gemma", "qwen", "deepseek"],
  "embedding_models": ["openai", "gte"]
}
```

### 3. **Chat Endpoint**
```
POST /chat/
Request:
{
  "message": "What is AI?",
  "model": "deepseek",  // or "llama", "gemma", "qwen"
  "history": []         // optional chat history
}

Response:
{
  "response": "AI is...",
  "model": "deepseek",
  "success": true
}
```

### 4. **Reasoning Endpoint**
```
POST /reason/
Request:
{
  "task": "Solve 2x + 5 = 13",
  "model": "deepseek",
  "context": "Linear algebra problem"
}

Response:
{
  "response": "x = 4 because...",
  "model": "deepseek",
  "success": true
}
```

### 5. **Embedding Endpoint**
```
POST /embed/
Request:
{
  "text": "Machine learning is powerful",
  "model": "openai"  // or "gte"
}

Response:
{
  "embedding": [0.1234, 0.5678, ...],
  "model": "openai",
  "success": true
}
```

---

## 🎯 Model Details

### External LLM (Azure GenAILab MaaS)
- **Model**: `azure_ai/genailab-maas-DeepSeek-V3-0324`
- **Framework**: LangChain's ChatOpenAI
- **Use Cases**: Main reasoning, complex queries, large tasks
- **Temperature**: 0.7 (chat), 0.5 (reasoning)
- **Max Tokens**: 512 (chat), 1024 (reasoning)

### Local SLMs (When Installed)
| Model | Type | Purpose |
|-------|------|---------|
| Llama-3.2-3b-it | Chat | Lightweight conversations |
| Gemma-3-4b-it | Chat | Balanced performance |
| Qwen-2.5.1-coder-it | Chat | Code-focused tasks |
| Deepseek-r1 | Reasoning | Complex reasoning tasks |

### Embedding Models
| Model | Type | Framework |
|-------|------|-----------|
| Azure OpenAI Ada-002 | External | LangChain OpenAIEmbeddings |
| Gte-large | Local | sentence-transformers |

---

## 🧪 Testing

Run the comprehensive test suite:
```powershell
python test_api.py
```

This will test:
- ✓ Health check
- ✓ Available models endpoint
- ✓ DeepSeek chat (external LLM)
- ✓ Local SLMs (Llama, Gemma)
- ✓ Reasoning with DeepSeek
- ✓ OpenAI embeddings
- ✓ GTE embeddings

---

## 🔌 LangChain Integration

The backend uses LangChain for model abstraction:

```python
# Chat Model
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="YOUR_API_KEY",
    temperature=0.7,
    max_tokens=512
)

# Embedding Model
from langchain_openai import OpenAIEmbeddings

embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key="YOUR_API_KEY"
)
```

---

## 📊 Response Examples

### Chat Response
```json
{
  "response": "Paris is the capital of France, known for the Eiffel Tower...",
  "model": "deepseek",
  "success": true
}
```

### Reasoning Response
```json
{
  "response": "To solve 2x + 5 = 13:\n1. Subtract 5 from both sides: 2x = 8\n2. Divide by 2: x = 4",
  "model": "deepseek",
  "success": true
}
```

### Embedding Response
```json
{
  "embedding": [0.123, 0.456, 0.789, ...],
  "model": "openai",
  "success": true
}
```

---

## 🛠️ Environment Setup for Local SLMs

To use local SLMs, install them:

```powershell
# For Llama (via llama-cpp-python)
pip install llama-cpp-python

# For Gemma, Qwen, Deepseek (via transformers)
pip install transformers torch

# For Embeddings (Gte-large)
pip install sentence-transformers
```

Then place models in: `../models/` directory:
```
models/
├── llama-3.2-3b-it/
│   └── llama-3.2-3b-it.Q4_K_M.gguf
├── gemma-3-4b-it/
├── qwen-2.5.1-coder-it/
├── deepseek-r1/
└── gte-large/
```

---

## 🌐 Frontend Integration

In your React frontend (`App.tsx`):

```typescript
const API_BASE_URL = 'http://localhost:8000';

// Chat with DeepSeek
const response = await fetch(`${API_BASE_URL}/chat/`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    message: "Hello!",
    model: "deepseek"
  })
});

const data = await response.json();
console.log(data.response);
```

---

## 🚀 Performance Tips

1. **Model Selection Strategy**:
   - Use local SLMs for lightweight tasks (saves API calls)
   - Use DeepSeek for complex reasoning
   - Batch embeddings when possible

2. **Optimization**:
   - Cache embeddings for repeated texts
   - Implement request rate limiting
   - Add response caching

3. **Monitoring**:
   - Check logs in terminal
   - Monitor API usage via Azure portal
   - Track response times

---

## 📝 Logging

The backend includes comprehensive logging:
```
INFO:main:✓ ChatOpenAI (DeepSeek V3) initialized successfully
INFO:main:✓ OpenAIEmbeddings initialized successfully
```

---

## ⚠️ Troubleshooting

### "Connection error" from DeepSeek
- ✓ Check API key in `.env`
- ✓ Verify base URL is correct
- ✓ Check network connectivity

### Local SLM not available
- ✓ Install required packages: `pip install transformers torch`
- ✓ Ensure model files are in correct path
- ✓ Check logs for specific error messages

### CORS errors
- ✓ CORS is enabled for all origins (development)
- ✓ In production, restrict to specific domains

---

## 📦 Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| fastapi | 0.109.0 | Web framework |
| uvicorn | 0.27.0 | ASGI server |
| langchain | 0.1.7 | LLM framework |
| langchain-openai | 0.0.8 | OpenAI integration |
| openai | 1.3.9 | OpenAI library |
| pydantic | 2.5.0 | Data validation |
| python-dotenv | 1.0.0 | Environment variables |

---

## 🎓 Learning Resources

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [LangChain Documentation](https://python.langchain.com/)
- [OpenAI API Reference](https://platform.openai.com/docs/)

---

## 📄 License

This project is provided as-is for educational and development purposes.

---

**Backend Status**: ✅ Running on `http://localhost:8000`
