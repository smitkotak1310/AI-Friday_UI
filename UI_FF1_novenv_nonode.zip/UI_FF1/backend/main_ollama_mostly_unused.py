# filepath: c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend\main.py
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict
import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
import logging

# Import local SLM functions
from models import (
    llama_chat, gemma_chat, qwen_chat, deepseek_reason, gte_embed
)

# Import Ollama service (follows validation_service.py pattern)
from ollama_service import ollama_service

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

app = FastAPI()

# Allow CORS for local frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize LangChain models with Azure endpoint
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://genailab.tcs.in")

try:
    # Initialize ChatOpenAI with DeepSeek V3
    llm = ChatOpenAI(
        base_url=OPENAI_BASE_URL,
        model="azure_ai/genailab-maas-DeepSeek-V3-0324",
        api_key=OPENAI_API_KEY,
        temperature=0.7,
        max_tokens=512
    )
    logger.info("✓ ChatOpenAI (DeepSeek V3) initialized successfully")
except Exception as e:
    logger.error(f"✗ Failed to initialize ChatOpenAI: {e}")
    llm = None

try:
    # Initialize OpenAI Embeddings
    embedding_model = OpenAIEmbeddings(
        base_url=OPENAI_BASE_URL,
        model="azure/genailab-maas-text-embedding-3-large",
        api_key=OPENAI_API_KEY
    )
    logger.info("✓ OpenAIEmbeddings initialized successfully")
except Exception as e:
    logger.error(f"✗ Failed to initialize OpenAIEmbeddings: {e}")
    embedding_model = None

# Log Ollama service status
if ollama_service and ollama_service.available:
    health = ollama_service.health_check()
    logger.info(f"✓ Ollama service status: {health['status']}")
    if health.get("available_models"):
        logger.info(f"  Available models: {', '.join(health['available_models'][:3])}...")
else:
    logger.warning("⚠ Ollama service not available (optional for local SLMs)")

# ==================== Request Models ====================

class ChatRequest(BaseModel):
    """Chat request with model selection"""
    message: str
    model: str  # 'deepseek', 'ollama_llama2', 'ollama_neural_chat', etc.
    history: Optional[List[dict]] = None
    temperature: Optional[float] = 0.7

class ReasonRequest(BaseModel):
    """Reasoning request"""
    task: str
    model: str  # 'deepseek', 'ollama_neural_chat', etc.
    context: Optional[str] = None
    temperature: Optional[float] = 0.5

class EmbedRequest(BaseModel):
    """Embedding request"""
    text: str
    model: str  # 'openai', 'gte'

class ValidationRequest(BaseModel):
    """Validation request (like validation_service.py)"""
    query: str
    rules: str
    model: Optional[str] = "llama2"
    temperature: Optional[float] = 0.3

class OllamaModelListResponse(BaseModel):
    """Response with list of Ollama models"""
    models: List[str]

# ==================== Health & Status Endpoints ====================

@app.get("/health/")
def health_check():
    """Health check endpoint"""
    ollama_status = "healthy" if (ollama_service and ollama_service.available) else "unavailable"
    return {
        "status": "ok",
        "external_llm": "healthy" if llm else "unavailable",
        "ollama_service": ollama_status,
        "embeddings": "healthy" if embedding_model else "unavailable"
    }

@app.get("/models/")
def get_available_models():
    """List all available models"""
    ollama_models = []
    if ollama_service and ollama_service.available:
        ollama_models = ollama_service.list_models()
    
    return {
        "llm_models": ["deepseek"],
        "slm_models": ["ollama_llama2", "ollama_neural_chat", "ollama_mistral"],
        "embedding_models": ["openai", "gte"],
        "ollama_available_models": ollama_models,
        "ollama_status": "healthy" if (ollama_service and ollama_service.available) else "unavailable"
    }

@app.get("/ollama/models/")
def get_ollama_models():
    """Get Ollama models"""
    if not ollama_service or not ollama_service.available:
        raise HTTPException(status_code=503, detail="Ollama service not available")
    
    models = ollama_service.list_models()
    return {"models": models, "count": len(models)}

# ==================== Chat Endpoints ====================

@app.post("/chat/")
def chat(req: ChatRequest):
    """Chat endpoint supporting both external LLM and local SLMs via Ollama"""
    try:
        if req.model == "deepseek":
            return chat_with_deepseek(req.message, req.history, req.temperature)
        
        # Ollama-based models
        elif req.model.startswith("ollama_"):
            model_name = req.model.replace("ollama_", "")
            return chat_with_ollama(req.message, model_name, req.temperature, req.history)
        
        # Legacy local SLM support
        elif req.model == "llama":
            response = llama_chat(req.message, req.history)
            return {"response": response, "model": "llama", "success": True}
        elif req.model == "gemma":
            response = gemma_chat(req.message, req.history)
            return {"response": response, "model": "gemma", "success": True}
        elif req.model == "qwen":
            response = qwen_chat(req.message, req.history)
            return {"response": response, "model": "qwen", "success": True}
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown model: {req.model}")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Chat error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/reason/")
def reason(req: ReasonRequest):
    """Reasoning endpoint"""
    try:
        if req.model == "deepseek":
            return reason_with_deepseek(req.task, req.context, req.temperature)
        
        elif req.model.startswith("ollama_"):
            model_name = req.model.replace("ollama_", "")
            return reason_with_ollama(req.task, model_name, req.context, req.temperature)
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown reasoning model: {req.model}")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Reasoning error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/embed/")
def embed(req: EmbedRequest):
    """Embedding endpoint"""
    try:
        if req.model == "openai":
            return embed_with_openai(req.text)
        elif req.model == "gte":
            embedding = gte_embed(req.text)
            return {"embedding": embedding, "model": "gte", "success": True}
        else:
            raise HTTPException(status_code=400, detail=f"Unknown embedding model: {req.model}")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Embedding error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ==================== Validation Endpoint (Ollama Pattern) ====================

@app.post("/validate/")
def validate_input(req: ValidationRequest):
    """
    Validate input using local SLM via Ollama
    Pattern: Similar to validation_service.py from reference project
    """
    if not ollama_service or not ollama_service.available:
        raise HTTPException(status_code=503, detail="Ollama service not available")
    
    try:
        result = ollama_service.validate(
            query=req.query,
            validation_rules=req.rules,
            model=req.model,
            temperature=req.temperature
        )
        return result
    except Exception as e:
        logger.error(f"Validation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ==================== Model Integration Functions ====================

def chat_with_deepseek(message: str, history: Optional[List[dict]] = None, temperature: float = 0.7) -> dict:
    """Chat with Azure DeepSeek model using LangChain"""
    try:
        if llm is None:
            return {"response": "LLM not initialized", "model": "deepseek", "error": True}
        
        response = llm.invoke(message)
        
        return {
            "response": response.content,
            "model": "deepseek",
            "success": True
        }
    except Exception as e:
        logger.error(f"DeepSeek chat error: {e}")
        return {"response": f"Error: {str(e)}", "model": "deepseek", "error": True}

def chat_with_ollama(message: str, model: str, temperature: float = 0.7, history: Optional[List[dict]] = None) -> dict:
    """Chat with Ollama-based local SLM (pattern from validation_service.py)"""
    try:
        if not ollama_service or not ollama_service.available:
            return {"response": "Ollama service not available", "model": model, "error": True}
        
        response = ollama_service.chat(
            prompt=message,
            model=model,
            temperature=temperature,
            max_tokens=256,
            history=history
        )
        
        return {
            "response": response,
            "model": model,
            "success": True
        }
    except Exception as e:
        logger.error(f"Ollama chat error: {e}")
        return {"response": f"Error: {str(e)}", "model": model, "error": True}

def reason_with_deepseek(task: str, context: Optional[str] = None, temperature: float = 0.5) -> dict:
    """Reasoning with DeepSeek model using LangChain"""
    try:
        if llm is None:
            return {"response": "LLM not initialized", "model": "deepseek", "error": True}
        
        prompt = f"Task: {task}"
        if context:
            prompt += f"\n\nContext: {context}"
        
        response = llm.invoke(prompt)
        
        return {
            "response": response.content,
            "model": "deepseek",
            "success": True
        }
    except Exception as e:
        logger.error(f"DeepSeek reasoning error: {e}")
        return {"response": f"Error: {str(e)}", "model": "deepseek", "error": True}

def reason_with_ollama(task: str, model: str, context: Optional[str] = None, temperature: float = 0.5) -> dict:
    """Reasoning with Ollama-based local SLM"""
    try:
        if not ollama_service or not ollama_service.available:
            return {"response": "Ollama service not available", "model": model, "error": True}
        
        response = ollama_service.reason(
            task=task,
            context=context,
            model=model,
            temperature=temperature,
            max_tokens=512
        )
        
        return {
            "response": response,
            "model": model,
            "success": True
        }
    except Exception as e:
        logger.error(f"Ollama reasoning error: {e}")
        return {"response": f"Error: {str(e)}", "model": model, "error": True}

def embed_with_openai(text: str) -> dict:
    """Embedding with Azure OpenAI using LangChain"""
    try:
        if embedding_model is None:
            return {"embedding": [], "model": "openai", "error": True, "message": "Embedding model not initialized"}
        
        embedding = embedding_model.embed_query(text)
        
        return {
            "embedding": embedding,
            "model": "openai",
            "success": True
        }
    except Exception as e:
        logger.error(f"OpenAI embedding error: {e}")
        return {"embedding": [], "model": "openai", "error": True, "message": str(e)}
