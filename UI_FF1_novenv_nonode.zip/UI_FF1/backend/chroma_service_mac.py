"""
ChromaDB Vector Database Service — Mac Version
================================================
Difference from chroma_service.py:
  - Original (Windows env): relied on ChromaDB's built-in default embedding
    function (all-MiniLM-L6-v2 via ONNX) which triggered a ~100MB download
    on every fresh environment.
  - This file (Mac): explicitly uses the Azure OpenAI embeddings model that
    is already initialised in main.py, so NO local model download happens.

Usage: imported in main.py instead of chroma_service.py on Mac/CI environments.
"""

import chromadb
from pathlib import Path
import logging
from typing import List, Dict, Optional, Tuple

logger = logging.getLogger(__name__)


class ChromaDBServiceMac:
    """
    ChromaDB service that uses pre-computed OpenAI embeddings.

    Key difference: add_document() and search_documents() call
    self.embedding_model.embed_query() / embed_documents() directly
    and pass the resulting vectors to ChromaDB — so ChromaDB never
    needs to download or run a local embedding model.
    """

    def __init__(self, persist_dir: str = "./chroma_db", embedding_model=None):
        """
        Args:
            persist_dir:      Directory for persistent ChromaDB storage.
            embedding_model:  A LangChain OpenAIEmbeddings (or compatible)
                              instance.  Must not be None for Mac operation.
        """
        self.persist_dir = Path(persist_dir)
        self.persist_dir.mkdir(exist_ok=True)

        # MAC: embedding_model is mandatory here (Azure OpenAI)
        self.embedding_model = embedding_model

        self.client = None
        self.collection = None

        try:
            # Use ChromaDB PersistentClient WITHOUT an embedding_function
            # — we will supply pre-computed vectors ourselves.
            self.client = chromadb.PersistentClient(path=str(self.persist_dir))

            # Get-or-create collection.  No embedding_function kwarg means
            # ChromaDB stores/retrieves raw vectors we hand it.
            self.collection = self.client.get_or_create_collection(
                name="policy_documents",
                metadata={"hnsw:space": "cosine"},
            )

            logger.info("✓ [MAC] ChromaDB initialised with collection 'policy_documents'")
            logger.info(f"  Persist directory: {self.persist_dir}")

        except Exception as e:
            logger.error(f"✗ [MAC] Failed to initialise ChromaDB: {e}")
            self.client = None
            self.collection = None

    # ------------------------------------------------------------------
    # Internal helper
    # ------------------------------------------------------------------

    def _embed(self, text: str) -> Optional[List[float]]:
        """
        Generate an embedding vector using Azure OpenAI.
        Returns None if the embedding model is unavailable.
        """
        if self.embedding_model is None:
            logger.error("[MAC] No embedding model provided — cannot embed text")
            return None
        try:
            vector = self.embedding_model.embed_query(text)
            return vector
        except Exception as e:
            logger.error(f"[MAC] Embedding error: {e}")
            return None

    # ------------------------------------------------------------------
    # Public API  (same signatures as ChromaDBService in chroma_service.py)
    # ------------------------------------------------------------------

    def add_document(self, doc_id: str, content: str, metadata: Dict = None) -> bool:
        """
        Embed content with Azure OpenAI and store in ChromaDB.

        Unlike the original service, this method generates the embedding
        explicitly so ChromaDB never falls back to all-MiniLM-L6-v2.
        """
        try:
            if not self.collection:
                logger.error("[MAC] ChromaDB collection not initialised")
                return False

            if not content or not content.strip():
                logger.warning(f"[MAC] Empty content for document {doc_id}")
                return False

            if metadata is None:
                metadata = {}

            # MAC: generate embedding via Azure OpenAI
            vector = self._embed(content)
            if vector is None:
                logger.error(f"[MAC] Could not embed document {doc_id} — skipping")
                return False

            # Store with pre-computed embedding so ChromaDB skips its own model
            self.collection.add(
                ids=[doc_id],
                documents=[content],     # stored for retrieval / display
                embeddings=[vector],     # ← explicit vector: no ONNX needed
                metadatas=[metadata],
            )

            logger.info(f"✓ [MAC] Document added to ChromaDB: {doc_id}")
            logger.info(f"  Content length: {len(content)} characters")
            return True

        except Exception as e:
            logger.error(f"✗ [MAC] Failed to add document {doc_id}: {e}")
            return False

    def search_documents(self, query: str, top_k: int = 3) -> List[Tuple[str, float]]:
        """
        Embed query with Azure OpenAI and run cosine similarity search.
        """
        try:
            if not self.collection:
                logger.error("[MAC] ChromaDB collection not initialised")
                return []

            # MAC: embed the query ourselves
            query_vector = self._embed(query)
            if query_vector is None:
                logger.error("[MAC] Could not embed query — search aborted")
                return []

            results = self.collection.query(
                query_embeddings=[query_vector],   # ← explicit vector
                n_results=top_k,
            )

            if not results or not results.get("documents") or not results["documents"][0]:
                logger.warning(f"[MAC] No results found for query: {query}")
                return []

            documents = results["documents"][0]
            distances = results["distances"][0] if results.get("distances") else []

            results_list = [
                (doc, 1 - dist)   # convert cosine distance → similarity
                for doc, dist in zip(documents, distances)
            ]

            logger.info(f"✓ [MAC] Found {len(results_list)} documents for query")
            return results_list

        except Exception as e:
            logger.error(f"✗ [MAC] Search failed: {e}")
            return []

    def get_document_count(self) -> int:
        """Return number of documents in the collection."""
        try:
            if not self.collection:
                return 0
            return self.collection.count()
        except Exception as e:
            logger.error(f"[MAC] Failed to get document count: {e}")
            return 0

    def get_all_documents(self) -> List[Dict]:
        """Return all stored documents with their metadata."""
        try:
            if not self.collection:
                return []

            results = self.collection.get()
            documents = []
            if results and results.get("documents"):
                for doc_id, content, metadata in zip(
                    results["ids"],
                    results["documents"],
                    results.get("metadatas", []),
                ):
                    documents.append(
                        {"id": doc_id, "content": content, "metadata": metadata or {}}
                    )
            return documents

        except Exception as e:
            logger.error(f"[MAC] Failed to get documents: {e}")
            return []

    def delete_document(self, doc_id: str) -> bool:
        """Delete a document by ID."""
        try:
            if not self.collection:
                return False
            self.collection.delete(ids=[doc_id])
            logger.info(f"✓ [MAC] Document deleted: {doc_id}")
            return True
        except Exception as e:
            logger.error(f"✗ [MAC] Failed to delete document {doc_id}: {e}")
            return False

    def clear_all(self) -> bool:
        """Delete every document from the collection."""
        try:
            if not self.collection:
                return False
            results = self.collection.get()
            if results and results.get("ids"):
                self.collection.delete(ids=results["ids"])
            logger.info("✓ [MAC] All documents cleared from ChromaDB")
            return True
        except Exception as e:
            logger.error(f"✗ [MAC] Failed to clear documents: {e}")
            return False

    def is_healthy(self) -> bool:
        """Basic health check — verifies collection is accessible."""
        try:
            if self.collection is None:
                return False
            self.collection.count()   # lightweight operation
            return True
        except Exception as e:
            logger.error(f"[MAC] Health check failed: {e}")
            return False


# ---------------------------------------------------------------------------
# Module-level singleton helpers  (same interface as chroma_service.py)
# ---------------------------------------------------------------------------

_chroma_service_mac: Optional[ChromaDBServiceMac] = None


def initialize_chroma_service_mac(embedding_model=None) -> Optional[ChromaDBServiceMac]:
    """
    Initialise and return the global ChromaDBServiceMac instance.
    Call this from main.py instead of initialize_chroma_service().
    """
    global _chroma_service_mac
    try:
        _chroma_service_mac = ChromaDBServiceMac(
            persist_dir="./chroma_db",
            embedding_model=embedding_model,
        )
        logger.info("✓ [MAC] Global ChromaDB (Mac) service initialised")
        return _chroma_service_mac
    except Exception as e:
        logger.error(f"✗ [MAC] Failed to initialise ChromaDB (Mac) service: {e}")
        _chroma_service_mac = None
        return None


def get_chroma_service_mac() -> Optional[ChromaDBServiceMac]:
    """Return the global ChromaDBServiceMac instance."""
    return _chroma_service_mac
