# 🚀 Quick Start Guide - ChromaDB RAG Application

## 🎯 What You Now Have

A fully functional **Policy Assistant with RAG (Retrieval-Augmented Generation)**:
- 📄 Upload PDFs/TXT → Automatically indexed in ChromaDB
- 🔍 Semantic search → Find relevant policy sections
- 🤖 Smart Q&A → DeepSeek uses YOUR documents for answers
- 📊 Live dashboard → Real-time statistics

---

## ⚡ Getting Started

### Step 1: Start the Application

```powershell
# Terminal 1: Start Backend
cd c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend
python main.py

# Terminal 2: Start Frontend (different terminal)
cd c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1
npm run dev
```

Both should show "ready" messages:
```
Backend:  ✓ ChromaDB initialized successfully
Frontend: ✓ Local: http://localhost:5173/
```

### Step 2: Open the Application

```
http://localhost:5173
```

### Step 3: Try It Out

**Upload a document:**
1. Click "Dashboard" tab
2. Scroll to "Index New Policy" section
3. Upload a PDF or TXT file
4. See document count increase in stats

**Ask a question:**
1. Click "Chat" tab
2. Type: "What is my deductible?"
3. Get answer based on your document!

---

## 📁 File Structure

```
UI_FF1/
├── backend/
│   ├── chroma_service.py       ← ChromaDB management
│   ├── document_extractor.py   ← Text extraction
│   ├── main.py                 ← FastAPI server
│   ├── chroma_db/              ← Vector database (persistent)
│   └── uploads/                ← Uploaded files
├── src/
│   ├── App.tsx                 ← Main app
│   ├── components/
│   │   ├── chat/ChatInterface.tsx
│   │   └── dashboard/Dashboard.tsx
│   └── types/
└── package.json
```

---

## 🔧 API Endpoints

### Get Statistics
```bash
curl http://localhost:8000/documents/stats/
# Returns: { "total_indexed": 2, "chroma_db_healthy": true }
```

### Upload Document
```bash
curl -F "file=@policy.pdf" http://localhost:8000/upload
# Returns: { "success": true, "indexed": true, "total_indexed": 2 }
```

### Search Documents
```bash
curl "http://localhost:8000/search/?query=deductible&top_k=3" \
  -X POST
# Returns: Array of 3 most relevant document excerpts
```

### Chat with RAG
```bash
curl -X POST http://localhost:8000/chat/ \
  -H "Content-Type: application/json" \
  -d '{"message": "What is my deductible?", "model": "deepseek"}'
# Returns: Answer based on your documents!
```

### Health Check
```bash
curl http://localhost:8000/health/
# Returns: All services status including ChromaDB
```

---

## 🎯 Key Features

| Feature | Status | Details |
|---------|--------|---------|
| **Document Upload** | ✅ | PDF & TXT support, auto-indexed |
| **Text Extraction** | ✅ | PyPDF for PDFs, UTF-8 for text |
| **Vector Embeddings** | ✅ | OpenAI Text-Embedding-3-Large (3072-D) |
| **Semantic Search** | ✅ | Find relevant content by meaning |
| **RAG Chat** | ✅ | DeepSeek answers with document context |
| **Dashboard** | ✅ | Real-time stats from ChromaDB |
| **Data Persistence** | ✅ | ChromaDB survives restart |
| **Input Validation** | ✅ | Filter out non-policy questions |

---

## 💾 Where Data Is Stored

| Data | Location | Persistence |
|------|----------|-------------|
| **Vector Embeddings** | `./chroma_db/` | ✅ Permanent |
| **Original Files** | `./uploads/` | ✅ Permanent |
| **Chat History** | localStorage | ✅ Permanent |
| **Document List** | localStorage | ✅ Permanent |

---

## 🔍 Understanding RAG

**RAG = Retrieval-Augmented Generation**

Without RAG:
```
Q: "What's my deductible?"
LLM: Generic answer (no document knowledge)
```

With RAG:
```
Q: "What's my deductible?"
  ↓
Search: Find "deductible" in your documents
  ↓
Retrieve: "The deductible is $500 for all claims"
  ↓
Augment: Add this to the LLM prompt
  ↓
Generate: "Based on YOUR policy, the deductible is $500..."
```

**Result: Accurate, document-grounded answers!**

---

## 🧪 Testing

### Quick Test
```bash
cd backend
python test_chromadb_integration.py
```

Expected output:
```
✅ TEST 1: Health Check - PASSED
✅ TEST 2: Document Statistics - PASSED
✅ TEST 3: Upload Document - PASSED
✅ TEST 4: Semantic Search - PASSED
✅ TEST 5: Chat with RAG - PASSED
✅ TEST 6: Dashboard Stats - PASSED

🎉 ALL TESTS PASSED!
```

---

## ⚙️ Configuration

### Embeddings
- **Provider**: OpenAI
- **Model**: text-embedding-3-large
- **Dimensions**: 3072
- **Cost**: $0.02 per 1M tokens

### LLM
- **Provider**: DeepSeek V3
- **Via**: Azure GenAI Lab
- **Temperature**: 0.7 (for chat)

### Vector DB
- **System**: ChromaDB
- **Backend**: DuckDB + Parquet
- **Distance**: Cosine similarity
- **Storage**: `./chroma_db/`

---

## 🛠️ Troubleshooting

### Backend won't start?
```bash
# Check Python installed
python --version

# Install dependencies
pip install -r requirements.txt

# Check port 8000 is free
netstat -ano | findstr :8000
```

### Frontend won't start?
```bash
# Check Node installed
node --version

# Install dependencies
npm install

# Clear cache and rebuild
npm run dev
```

### ChromaDB not found?
```bash
# Verify directory created
dir chroma_db

# Check permissions
# Ensure ./chroma_db/ is readable/writable
```

### Uploads not working?
```bash
# Check uploads directory
dir uploads

# Verify file size < 50MB
# Only PDF and TXT allowed
```

---

## 📊 Dashboard Guide

**Total Documents**: Count from ChromaDB (live)
- Updates every 30 seconds
- Reflects newly uploaded documents
- Source: `/documents/stats/` endpoint

**AI Queries**: Count from chat history
- Counts user messages only
- Stored in localStorage
- Persists across sessions

**System Health**: Overall status
- Green (99.9%): All systems healthy
- Orange/Red: Some service down
- Includes ChromaDB health

**Recent Activity**: Auto-generated from data
- Shows actual uploads
- Shows actual queries
- Shows system status

---

## 🔐 Best Practices

✅ **DO**
- Upload relevant policy documents
- Ask specific questions about your policies
- Wait 30 seconds for dashboard updates
- Check health endpoint if issues occur

❌ **DON'T**
- Upload unrelated files (will be filtered)
- Rely on RAG for non-policy topics
- Delete chroma_db/ while app running
- Modify files in ./uploads/ manually

---

## 📈 Performance Tips

**For Best Results:**
1. Upload **clear, well-formatted** policy documents
2. Use **specific terms** when searching ("deductible" vs "cost")
3. Break **long documents** into sections
4. **Wait** for embedding to complete before asking

**Expected Times:**
- Document upload: 1-2 seconds
- Text extraction: Depends on size
- Embedding generation: 5-10 seconds
- Search query: <1 second
- Chat response: 3-10 seconds

---

## 🚀 Advanced Usage

### Add Custom Documents
```bash
# Drop PDFs/TXTs in ./uploads/
cp my_policy.pdf uploads/

# Upload via API
curl -F "file=@policy.pdf" http://localhost:8000/upload
```

### Search Programmatically
```python
import requests

response = requests.post(
    "http://localhost:8000/search/",
    params={"query": "coverage", "top_k": 5}
)
results = response.json()
```

### Batch Upload
```bash
# Upload multiple files
for file in *.pdf; do
    curl -F "file=@$file" http://localhost:8000/upload
done
```

---

## 📞 Support

### Check Logs
```bash
# Backend logs
tail -f backend.log

# Frontend logs
# Check browser console (F12)
```

### Health Check
```bash
curl http://localhost:8000/health/
# Verify all services show "healthy"
```

### Document Count
```bash
curl http://localhost:8000/documents/stats/
# Check total_indexed matches uploaded documents
```

---

## 🎓 Learning Resources

**RAG Concept**: https://docs.llamaindex.ai/en/stable/getting_started/concepts.html

**ChromaDB Docs**: https://docs.trychroma.com/

**DeepSeek Model**: https://github.com/deepseek-ai

**FastAPI**: https://fastapi.tiangolo.com/

---

## ✨ Summary

You have a **production-ready RAG application** with:
- ✅ Document indexing
- ✅ Semantic search  
- ✅ Intelligent Q&A
- ✅ Live statistics
- ✅ Data persistence

**Ready to deploy!** 🚀

---

**Questions? Check:**
1. CHROMADB_IMPLEMENTATION.md (detailed guide)
2. Backend logs (error messages)
3. /health/ endpoint (service status)
4. README files in each directory
