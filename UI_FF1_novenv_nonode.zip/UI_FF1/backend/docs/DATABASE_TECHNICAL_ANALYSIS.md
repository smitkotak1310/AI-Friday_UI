# Database Architecture - Technical Deep Dive

## Executive Summary

| Aspect | Answer |
|--------|--------|
| **Database File** | ❌ NONE - Hybrid storage |
| **Chat Storage** | ✅ Browser localStorage |
| **Document Storage** | ✅ Filesystem (`./uploads/`) |
| **RAG Database** | ❌ Missing - Only document names sent |
| **Vector Store** | ❌ Not implemented |
| **Persistent DB** | ❌ No PostgreSQL/MySQL |

---

## 1️⃣ STORAGE LAYER 1: Browser localStorage

### **Code Location:**
- File: `src/App.tsx` (Lines 56-85)
- Technology: Browser built-in Web Storage API
- Implementation: JSON serialization

### **Code Snippet:**
```typescript
// src/App.tsx - Lines 78-85
useEffect(() => {
  localStorage.setItem('documents', JSON.stringify(documents));
}, [documents]);

useEffect(() => {
  localStorage.setItem('chatMessages', JSON.stringify(chatMessages));
}, [chatMessages]);
```

### **Initialization Code:**
```typescript
// src/App.tsx - Lines 56-72
useEffect(() => {
  const savedDocuments = localStorage.getItem('documents');
  const savedMessages = localStorage.getItem('chatMessages');
  
  if (savedDocuments) {
    try {
      setDocuments(JSON.parse(savedDocuments));
    } catch (e) {
      console.error('Failed to load documents:', e);
    }
  }
  
  if (savedMessages) {
    try {
      setChatMessages(JSON.parse(savedMessages));
    } catch (e) {
      console.error('Failed to load messages:', e);
    }
  }
}, []);
```

### **Data Schema:**
```typescript
// Type: DocumentInfo
{
  id: string;
  name: string;           // Filename
  size: string;           // "2.4 MB"
  type: "PDF" | "TXT";
  uploadedAt: string;     // "2025-01-10"
}

// Type: ChatMessage
{
  role: "user" | "assistant";
  content: string;
}
```

### **Storage Limits:**
```
Max Size: 5-10 MB per domain
Current Usage: ~2-5 KB (small)
Auto-Clear: 30 days (browser dependent)
Scope: Same origin only
```

---

## 2️⃣ STORAGE LAYER 2: Filesystem (`./uploads/`)

### **Code Location:**
- File: `backend/main.py` (Lines 323-365)
- Directory: `backend/uploads/`
- Technology: Direct filesystem write

### **Upload Endpoint Code:**
```python
# backend/main.py - Lines 319-365
@app.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    """Upload document to knowledge base"""
    try:
        # Create uploads directory if it doesn't exist
        upload_dir = Path(__file__).parent / "uploads"
        upload_dir.mkdir(exist_ok=True)
        
        # Validate file type
        allowed_types = {".pdf", ".txt", ".doc", ".docx"}
        file_ext = Path(file.filename).suffix.lower()
        if file_ext not in allowed_types:
            raise HTTPException(status_code=400, detail="File type not allowed")
        
        file_path = upload_dir / file.filename
        
        # Write file with size tracking
        file_size = 0
        with open(file_path, "wb") as buffer:
            while chunk := await file.read(1024 * 1024):  # 1MB chunks
                if file_size + len(chunk) > 50 * 1024 * 1024:  # 50MB limit
                    raise HTTPException(status_code=413, detail="File too large (max 50MB)")
                buffer.write(chunk)
                file_size += len(chunk)
        
        logger.info(f"Document uploaded: {file.filename} ({file_size} bytes)")
        
        return {
            "success": True,
            "message": f"Document '{file.filename}' uploaded successfully",
            "filename": file.filename,
            "size": file_size,
            "path": str(file_path)
        }
```

### **Files Currently Stored:**
```
c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend\uploads\
├── AI-Powered-Customer-Feedback-Intelligence.pdf  (~5MB)
└── test_document.txt                              (small)
```

### **How Files Are Listed:**
```typescript
// src/App.tsx - Initial state (Lines 47-50)
const [documents, setDocuments] = useState<DocumentInfo[]>([
  { id: '1', name: 'Standard_Policy_2024.pdf', size: '2.4 MB', type: 'PDF', uploadedAt: '2025-01-10' },
  { id: '2', name: 'Terms_and_Conditions.txt', size: '45 KB', type: 'TXT', uploadedAt: '2025-01-12' },
]);
```

**Note:** Files are uploaded to `./uploads/` but not automatically indexed or parsed.

---

## 3️⃣ STORAGE LAYER 3: RAG Context (In-Memory)

### **Code Location:**
- File: `backend/main.py` (Lines 375-395)
- Technology: String concatenation
- Persistence: None (request lifetime only)

### **RAG Implementation Code:**
```python
# backend/main.py - Lines 375-395
def chat_with_deepseek(
    message: str, 
    history: Optional[List[dict]] = None, 
    temperature: float = 0.7, 
    rag_context: Optional[str] = None, 
    documents: Optional[List[dict]] = None
) -> dict:
    """Chat with Azure DeepSeek model using LangChain with RAG context"""
    try:
        if llm is None:
            return {"response": "LLM not initialized", "model": "deepseek", "error": True}
        
        # Build prompt with RAG context if available
        enhanced_message = message
        if rag_context or documents:
            context_str = rag_context or ", ".join([d.get("name", "document") for d in documents]) if documents else "uploaded documents"
            enhanced_message = f"""You are an Insurance Policy Assistant. 
You have access to the following documents: {context_str}

Please answer the user's question based on the content of these documents. 
If the question is about general insurance topics not covered in the documents, you can provide general knowledge but clarify that it's not from their specific documents.

User Question: {message}"""
        
        response = llm.invoke(enhanced_message)
        
        return {
            "response": response.content,
            "model": "deepseek",
            "success": True,
            "used_rag": bool(rag_context or documents)
        }
    except Exception as e:
        logger.error(f"DeepSeek chat error: {e}")
        return {"response": f"Error: {str(e)}", "model": "deepseek", "error": True}
```

### **Frontend RAG Code:**
```typescript
// src/App.tsx - Lines 159-175
const documentsContext = documents.length > 0 
  ? documents.map(d => d.name).join(', ')
  : 'No documents uploaded';

const response = await fetch(`${API_BASE_URL}/chat/`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ 
    message: question, 
    model: 'deepseek',
    temperature: 0.7,
    rag_context: documentsContext,
    documents: documents
  }),
});
```

### **What Gets Sent to LLM:**
```
"You have access to the following documents: AI-Powered-Customer-Feedback-Intelligence.pdf, test_document.txt

Please answer the user's question based on the content of these documents...

User Question: What is my coverage?"
```

⚠️ **Problem:** LLM sees ONLY names, not file contents!

---

## 4️⃣ DASHBOARD STATS: Dynamic Data Retrieval

### **Code Location:**
- File: `src/components/dashboard/Dashboard.tsx` (Lines 40-82)
- Updates: Every 30 seconds
- Sources: localStorage + backend API

### **Data Fetching Code:**
```typescript
// src/components/dashboard/Dashboard.tsx - Lines 40-82
const fetchDashboardStats = async () => {
  try {
    // Fetch health status from backend
    const healthResponse = await fetch(`${API_BASE_URL}/health/`);
    const healthData = await healthResponse.json();
    
    // Get total documents from props
    const totalDocuments = documents.length || 0;
    
    // Get query count from localStorage
    const savedMessages = localStorage.getItem('chatMessages');
    const messages = savedMessages ? JSON.parse(savedMessages) : [];
    const userMessages = messages.filter((m: any) => m.role === 'user').length;
    
    // Determine system health
    const isHealthy = healthData.status === 'ok' && 
                     healthData.external_llm === 'healthy' &&
                     healthData.embeddings === 'healthy';
    const healthScore = isHealthy ? '99.9%' : '85%';
    
    // Generate recent activity
    const recentActivity = generateRecentActivity(totalDocuments, userMessages);
    
    setStats({
      totalDocuments,
      totalQueries: userMessages,
      systemHealth: healthScore,
      recentActivity
    });
    setLoading(false);
  } catch (error) {
    console.error('Failed to fetch dashboard stats:', error);
    // Fallback...
  }
};
```

### **Stats Card Rendering Code:**
```typescript
// src/components/dashboard/Dashboard.tsx - Lines 126-140
<div className="grid grid-cols-1 md:grid-cols-3 gap-6">
  <StatsCard 
    label="Total Documents" 
    value={stats.totalDocuments}  {/* Read from state */}
    trend={stats.totalDocuments > 0 ? `+${stats.totalDocuments}` : 'None yet'} 
    trendUp={stats.totalDocuments > 0}
    icon={<FileText className="w-6 h-6" />} 
  />
  <StatsCard 
    label="AI Queries" 
    value={stats.totalQueries}    {/* Count from localStorage */}
    trend={stats.totalQueries > 0 ? `+${Math.floor(stats.totalQueries * 0.1)}%` : 'No queries'} 
    trendUp={stats.totalQueries > 0}
    icon={<MessageSquare className="w-6 h-6" />} 
  />
  <StatsCard 
    label="System Health" 
    value={stats.systemHealth}    {/* From /health/ endpoint */}
    icon={<ShieldCheck className="w-6 h-6" />} 
  />
</div>
```

### **Data Sources:**
```
Total Documents:
  Source: documents prop from App.tsx
  Update Trigger: useEffect([documents])
  Storage: In-memory state

AI Queries:
  Source: localStorage.getItem('chatMessages')
  Update Trigger: Every 30s interval
  Filter: messages where role === 'user'

System Health:
  Source: fetch('/health/') endpoint
  Update Trigger: Every 30s interval
  Response Example:
    {
      "status": "ok",
      "external_llm": "healthy",
      "ollama_service": "healthy",
      "embeddings": "healthy"
    }

Recent Activity:
  Source: generateRecentActivity() function
  Parameters: totalDocuments + totalQueries
  Update Trigger: Every 30s with stats
```

---

## 5️⃣ HEALTH CHECK ENDPOINT

### **Code Location:**
- File: `backend/main.py` (Lines 129-137)
- Endpoint: GET `/health/`
- Response: JSON with system status

### **Implementation:**
```python
# backend/main.py - Lines 129-137
@app.get("/health/")
def health_check():
    """Health check endpoint"""
    ollama_status = "healthy" if (ollama_service and ollama_service.available) else "unavailable"
    return {
        "status": "ok",
        "external_llm": "healthy" if llm else "unavailable",
        "ollama_service": ollama_status,
        "embeddings": "healthy" if embedding_model else "unavailable"
    }
```

### **Sample Response:**
```json
{
  "status": "ok",
  "external_llm": "healthy",
  "ollama_service": "healthy",
  "embeddings": "healthy"
}
```

---

## 🗂️ File Organization

### **No Dedicated Database Files:**
```
backend/
├── main.py                    ← All endpoints
├── models.py                  ← LLM wrappers
├── ollama_service.py          ← Ollama integration
├── requirements.txt           ← Dependencies
├── .env                       ← API keys
│
├── uploads/                   ← 📁 FILE STORAGE
│   ├── AI-Powered-Customer-Feedback-Intelligence.pdf
│   └── test_document.txt
│
└── __pycache__/              ← Compiled Python (not data)

src/
├── App.tsx                    ← Uses localStorage
├── index.css
└── components/
    ├── chat/
    │   └── ChatInterface.tsx  ← Manages chatMessages
    └── dashboard/
        └── Dashboard.tsx      ← Reads localStorage & health
```

**Key Point:** ❌ **No `.db`, `.json`, `.sqlite`, or any database file present**

---

## 📊 Data Flow Diagrams

### **Upload Flow:**
```
User selects file
    ↓
Frontend: handleRealUpload()
    ↓
POST /upload → FormData with file
    ↓
Backend: /upload endpoint
    ↓
Save to: ./uploads/{filename}
    ↓
Response: {success: true, path: "./uploads/..."}
    ↓
Frontend: Add to documents state
    ↓
localStorage.setItem('documents', ...)
```

### **Chat with RAG Flow:**
```
User types question
    ↓
Frontend: handleRealAsk()
    ↓
POST /validate_input/ → {query: "..."}
    ↓
Backend: fallback_validate()
    ↓
Return: {valid: true, category: "CIVIC_RELEVANT"}
    ↓
POST /chat/ → {message, rag_context: "doc names", ...}
    ↓
Backend: chat_with_deepseek()
    ↓
Create prompt with document names
    ↓
Send to DeepSeek API
    ↓
Return: {response: "...", used_rag: true}
    ↓
Frontend: Display response
    ↓
Frontend: Add to chatMessages state
    ↓
localStorage.setItem('chatMessages', ...)
```

### **Dashboard Stats Flow:**
```
Component Mount
    ↓
useEffect([documents])
    ↓
fetchDashboardStats()
    ↓
Parallel:
├─ fetch('/health/')
├─ Read documents.length
├─ Read localStorage['chatMessages']
└─ generateRecentActivity()
    ↓
setStats(...)
    ↓
Render with dynamic values
```

---

## 🎯 Summary Table

| Component | Type | Location | Persistence | Indexed? |
|-----------|------|----------|-------------|----------|
| **Chat Messages** | localStorage | Browser | Yes (until cleared) | No |
| **Document List** | localStorage | Browser | Yes (until cleared) | No |
| **Uploaded Files** | Filesystem | `./uploads/` | Yes (permanent) | ❌ NO |
| **Embeddings** | RAM | Memory | No (request only) | N/A |
| **Sessions** | RAM | Memory | No (request only) | N/A |
| **Health Status** | API | Computed on-demand | No | N/A |
| **Database** | ❌ NONE | — | — | — |

---

## ✅ What Works

- ✅ Upload documents to filesystem
- ✅ Persist chat history in localStorage
- ✅ Persist document list in localStorage
- ✅ Dynamic dashboard stats
- ✅ RAG context (document names only)
- ✅ Multi-model support (DeepSeek, Ollama)

## ❌ What's Missing

- ❌ Actual RAG (file content not indexed)
- ❌ Vector embeddings storage
- ❌ Semantic search
- ❌ Persistent backend database
- ❌ Multi-user support
- ❌ Cross-device sync
- ❌ PDF text extraction

---

## 🚀 Next Steps to Add Real RAG

```bash
# 1. Install vector database
pip install chromadb langchain-community

# 2. Extract text from PDFs
pip install pypdf

# 3. Add to backend/main.py:
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma

# 4. On file upload:
# - Extract text from PDF
# - Split into chunks
# - Generate embeddings
# - Store in Chroma

# 5. On chat query:
# - Search Chroma for relevant chunks
# - Send top-k results to LLM
# - Get answer from actual document content
```

This would give you **true RAG with semantic search** instead of just document names.
