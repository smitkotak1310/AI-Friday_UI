# Quick Configuration Reference

## 🎯 TL;DR - UI_FF1 Backend LLM Setup

### Current Configuration ✅

Your backend is configured with:

#### 1️⃣ **Cloud LLM: DeepSeek V3**
```python
# File: backend/main.py (lines 43-49)
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="YOUR_KEY",  # From .env
    temperature=0.7,
    max_tokens=512
)
```

#### 2️⃣ **Cloud Embedding: Text Embedding 3 Large**
```python
# File: backend/main.py (lines 52-58)
embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key="YOUR_KEY",  # From .env
)
```

#### 3️⃣ **Local SLM: Ollama Service**
```python
# File: backend/ollama_service.py (follows validation_service.py pattern)
class OllamaService:
    def __init__(self, host: str = "http://localhost:11434"):
        self.client = Client(host=host)
        # Supports: llama2, neural-chat, mistral, etc.
```

---

## 🔧 Setup in 5 Minutes

### Step 1: Environment Variables
Create `backend/.env`:
```env
OPENAI_API_KEY=your_deepseek_api_key_here
OPENAI_BASE_URL=https://genailab.tcs.in
```

### Step 2: Install Dependencies
```bash
cd backend
pip install -r requirements.txt
```

### Step 3: Start Backend
```bash
uvicorn main:app --reload
```

### Step 4: Verify Setup
```bash
curl http://localhost:8000/health/
```

### Step 5: Test API
```bash
curl -X POST http://localhost:8000/chat/ \
  -H "Content-Type: application/json" \
  -d '{"message":"Hello","model":"deepseek"}'
```

---

## 📊 Model Comparison

| Feature | DeepSeek (Cloud) | Ollama (Local) |
|---------|------------------|----------------|
| Speed | Medium | Fast |
| Quality | Excellent | Good |
| Cost | Per API call | Free |
| Privacy | Cloud | Local |
| Setup | Easy (just API key) | Requires Ollama |

---

## 🎛️ API Endpoints

### Chat
```
POST /chat/
Body: {"message": "...", "model": "deepseek"}
```

### Embeddings
```
POST /embed/
Body: {"text": "...", "model": "openai"}
```

### Reasoning
```
POST /reason/
Body: {"task": "...", "model": "deepseek"}
```

### Status
```
GET /health/
GET /models/
```

---

## 🚨 Troubleshooting

| Problem | Solution |
|---------|----------|
| `ChatOpenAI initialization failed` | Check API key in `.env` |
| `Connection refused (Ollama)` | Start Ollama: `ollama serve` |
| `Port 8000 already in use` | Use different port: `--port 8001` |
| `CORS error in browser` | CORS already configured for local dev |

---

## 📚 File Locations

| File | Purpose |
|------|---------|
| `backend/main.py` | FastAPI app with LLM/Embedding setup |
| `backend/ollama_service.py` | Local SLM service |
| `backend/models.py` | Direct transformer models |
| `backend/.env` | API keys (create this!) |
| `backend/requirements.txt` | Python dependencies |

---

## ✨ Status: READY TO USE ✨

All configurations are in place:
- ✅ LLM configured
- ✅ Embedding model configured
- ✅ Local SLM support ready
- ✅ API endpoints implemented
- ✅ Error handling in place

Just add API key to `.env` and run!

---

*UI_FF1 Backend - April 2026*
