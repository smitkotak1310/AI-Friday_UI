# UI_FF1 Comprehensive Architecture Analysis

## Project Overview
**UI_FF1** is a full-stack AI-powered application combining a modern React TypeScript frontend with a Python FastAPI backend featuring hybrid LLM/SLM architecture.

---

## 📁 Folder Structure Analysis

### Root Level
```
UI_FF1/
├── .venv/                          # Python virtual environment
├── backend/                        # FastAPI backend (Python)
├── src/                           # React frontend (TypeScript)
├── package.json                   # Node.js dependencies
├── tsconfig.json                  # TypeScript configuration
├── vite.config.ts                # Vite build configuration
├── index.html                    # Entry HTML
├── SETUP_GUIDE.txt              # Setup instructions
└── START.ps1                    # PowerShell startup script
```

### Backend Structure (`backend/`)
```
backend/
├── main.py                       # FastAPI application (CORE)
├── models.py                     # Local SLM models (Llama, Gemma, Qwen, Deepseek, GTE)
├── ollama_service.py            # Ollama service integration (local SLM)
├── main_ollama.py               # Alternative Ollama-focused entry point
├── test_api.py                  # API testing utilities
├── requirements.txt             # Python dependencies
├── .env                         # Environment variables (API keys)
├── README.md                    # Backend documentation
└── ARCHITECTURE.md              # Backend architecture details
```

### Frontend Structure (`src/`)
```
src/
├── App.tsx                      # Main React component
├── main.tsx                     # Vite entry point
├── index.css                    # Global styles
├── api/
│   └── backend.ts              # API client integration
├── components/
│   ├── chat/
│   │   ├── ChatInterface.tsx    # Chat UI
│   │   └── ChatMessage.tsx      # Message component
│   ├── dashboard/
│   │   ├── Dashboard.tsx        # Dashboard view
│   │   ├── StatsCard.tsx        # Stats display
│   │   └── UploadZone.tsx       # File upload
│   └── layout/
│       ├── Header.tsx           # App header
│       └── Sidebar.tsx          # Navigation sidebar
├── lib/
│   └── utils.ts                # Utility functions
├── types/
│   └── index.ts                # TypeScript type definitions
└── utils/
    └── cn.ts                   # CSS class utilities
```

---

## 🧠 AI/ML Architecture

### Three-Tier LLM Setup

#### 1. **External LLM (Primary - Cloud-based)**
- **Provider**: Azure AI Lab (genailab.tcs.in)
- **Model**: DeepSeek-V3 (`azure_ai/genailab-maas-DeepSeek-V3-0324`)
- **Purpose**: Primary reasoning and chat capabilities
- **Integration**: LangChain `ChatOpenAI`
- **Configuration**:
  ```python
  llm = ChatOpenAI(
      base_url="https://genailab.tcs.in",
      model="azure_ai/genailab-maas-DeepSeek-V3-0324",
      api_key="YOUR_KEY",
      temperature=0.7,
      max_tokens=512
  )
  ```

#### 2. **Embedding Model (Cloud-based)**
- **Provider**: Azure AI Lab
- **Model**: Text Embedding 3 Large (`azure/genailab-maas-text-embedding-3-large`)
- **Purpose**: Vector embeddings for semantic search and RAG
- **Integration**: LangChain `OpenAIEmbeddings`
- **Configuration**:
  ```python
  embedding_model = OpenAIEmbeddings(
      base_url="https://genailab.tcs.in",
      model="azure/genailab-maas-text-embedding-3-large",
      api_key="YOUR_KEY"
  )
  ```

#### 3. **Local SLMs (Secondary - Via Ollama)**
Pattern follows `validation_service.py` design

- **Service**: Ollama (local containerized inference)
- **Default Models**:
  - `llama2` - General chat
  - `neural-chat` - Conversational
  - `mistral` - Fast reasoning
  
- **Direct Local Models** (via `models.py`):
  - Llama-3.2-3b-it (via llama-cpp-python)
  - Gemma-3-4b-it (via transformers)
  - Qwen-2.5.1-coder-it (via transformers)
  - Deepseek-r1 (via transformers)
  - GTE-large (embedding via sentence-transformers)

---

## 🔌 Backend API Endpoints

### Health & Status
- `GET /health/` - System status check
- `GET /models/` - List available models
- `GET /ollama/models/` - Ollama-specific models

### Chat Operations
- `POST /chat/` - Chat with LLM or SLM
  - Models: `deepseek`, `ollama_llama2`, `ollama_neural_chat`, etc.

### Reasoning
- `POST /reason/` - Complex reasoning tasks
  - Models: `deepseek`, `ollama_neural_chat`

### Embeddings
- `POST /embed/` - Generate vector embeddings
  - Models: `openai`, `gte`

### Validation
- `POST /validate/` - Input validation (Ollama-based)
  - Pattern: Similar to `validation_service.py`

---

## 📦 Dependencies

### Python (Backend)
| Package | Version | Purpose |
|---------|---------|---------|
| fastapi | 0.109.0 | Web framework |
| uvicorn | 0.27.0 | ASGI server |
| langchain | 0.1.7 | LLM orchestration |
| langchain-openai | 0.0.8 | Azure integration |
| ollama | 0.1.48 | Local SLM engine |
| llama-cpp-python | 0.2.53 | Llama inference |
| transformers | 4.35.2 | Model loading |
| sentence-transformers | 2.2.2 | Embeddings |
| pydantic | 2.5.0 | Data validation |
| python-dotenv | 1.0.0 | Environment config |

### JavaScript/TypeScript (Frontend)
- React 18+ (modern UI)
- TypeScript (type safety)
- Vite (build tool)
- Axios (API client)
- Tailwind CSS (styling)

---

## 🔐 Environment Configuration

**`.env` file format:**
```env
# Azure AI Lab Credentials
OPENAI_API_KEY=YOUR_DEEPSEEK_API_KEY
OPENAI_BASE_URL=https://genailab.tcs.in

# Optional: Local SLM Configuration
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL_PATH=../models
```

---

## 🚀 Workflow

### Request Flow
1. **Frontend** (React) → Makes request via Axios
2. **Backend** (FastAPI) → Routes to appropriate handler
3. **Model Selection**:
   - **DeepSeek** → External LLM (Azure)
   - **Ollama Models** → Local SLM (Ollama service)
   - **Direct Models** → Local SLM (transformers/llama-cpp)
4. **Response** → Returned to frontend with metadata

### Model Selection Logic
```
If model == "deepseek" → Use ChatOpenAI (LangChain)
Else if model.startswith("ollama_") → Use Ollama service
Else if model in ["llama", "gemma", "qwen"] → Use transformers/llama-cpp
Else if model in ["openai", "gte"] → Use embeddings
```

---

## 📊 Validation Service Pattern

**Pattern**: Local SLM validation (follows `validation_service.py`)

**Key Components**:
- Ollama Client initialization
- Prompt-based validation rules
- JSON schema format responses
- Fallback handling

**Validation Categories**:
- `CIVIC_RELEVANT` - Domain-specific
- `FOLLOW_UP` - Context references
- `FLAVOUR_TEXT` - Greetings
- `IRRELEVANT` - Out of scope

---

## 🔄 Hybrid Architecture Benefits

| Feature | DeepSeek (Cloud) | Local SLMs (Ollama) |
|---------|------------------|-------------------|
| **Capability** | Advanced reasoning | Fast responses |
| **Cost** | Per-API-call | Free (after setup) |
| **Latency** | Higher (network) | Lower (local) |
| **Privacy** | Data sent to cloud | Fully local |
| **Reliability** | Depends on cloud | Always available |

**Strategy**: Use DeepSeek for complex tasks, fallback to Ollama for simple queries.

---

## 🛠️ Technology Stack Summary

```
┌─────────────────────────────────────┐
│       React + TypeScript (UI)        │
│  (Vite, Tailwind, Modern Components) │
└──────────────┬──────────────────────┘
               │ (Axios/HTTP)
┌──────────────▼──────────────────────┐
│        FastAPI Backend (Python)      │
│  ┌────────────────────────────────┐  │
│  │ ChatOpenAI (DeepSeek V3)       │  │
│  │ OpenAIEmbeddings (Embed-3L)    │  │
│  │ Ollama Service (SLMs)           │  │
│  │ Transformers (Local Models)    │  │
│  └────────────────────────────────┘  │
└──────────────┬──────────────────────┘
               │
       ┌───────┴────────┐
       │                │
   ┌───▼────────┐  ┌───▼──────────┐
   │   Azure    │  │    Ollama    │
   │  AI Lab    │  │   (Local)    │
   │ DeepSeek   │  │ SLMs         │
   │ Embedding  │  │              │
   └────────────┘  └──────────────┘
```

---

## ✅ Verification Checklist

- [x] DeepSeek LLM configured in `main.py`
- [x] OpenAI Embeddings configured in `main.py`
- [x] Ollama service integrated in `ollama_service.py`
- [x] Local SLM models setup in `models.py`
- [x] Environment variables for API keys
- [x] FastAPI endpoints for chat, reasoning, embeddings
- [x] Validation endpoint following `validation_service.py` pattern
- [x] Health check and model listing endpoints
- [x] Frontend integration via `backend.ts`
- [x] CORS middleware configured
- [x] Error handling and fallbacks

---

## 📝 Next Steps

1. **Configure `.env`** - Add your Azure API keys
2. **Start Backend** - `uvicorn main:app --reload`
3. **Start Frontend** - `npm run dev`
4. **Start Ollama** - `ollama serve` (if using local SLMs)
5. **Test API** - Use `/health/` endpoint to verify setup

---

*Generated: April 2026*
*Project: UI_FF1 - Civic Services AI Assistant*
