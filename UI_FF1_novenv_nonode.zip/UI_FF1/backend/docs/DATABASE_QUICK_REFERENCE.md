# Database & RAG Storage - Quick Reference

## ❓ WHERE IS THE DATABASE FILE?

**Answer: There is NO single database file.** The application uses a **three-tier hybrid storage** system:

---

## 📦 Three Storage Tiers

### **Tier 1: Browser localStorage** (Client-Side)
```
What: Key-value store in browser memory
Where: Not a physical file - stored in browser profile
Keys:
  - 'documents' → JSON array of doc metadata
  - 'chatMessages' → JSON array of messages
Capacity: ~5-10MB
Persistence: Until browser cache cleared or in 30 days
Sync: Single device only
```

### **Tier 2: File System** (Server-Side)
```
Path: ./backend/uploads/
Files:
  - AI-Powered-Customer-Feedback-Intelligence.pdf (uploaded by user)
  - test_document.txt (uploaded by user)
Persistence: Permanent (until deleted)
Access: Direct file read, not indexed
Sync: Requires manual re-upload
```

### **Tier 3: In-Memory Processing** (Transient)
```
Process: FastAPI request handling
Data: 
  - RAG context strings
  - Embeddings (generated on-demand)
  - LLM responses
Persistence: Only during request lifetime
Storage: RAM only
```

---

## 🗺️ Data Location Map

```
YOUR BROWSER
    ↓
    localStorage (JSON strings)
    ├─ Key: 'documents'
    │  Value: [
    │    {id, name: "AI-Powered-Customer-Feedback-Intelligence.pdf", size, type, uploadedAt},
    │    {id, name: "test_document.txt", size, type, uploadedAt}
    │  ]
    │
    └─ Key: 'chatMessages'
       Value: [
         {role: "user", content: "What is my coverage?"},
         {role: "assistant", content: "Based on your documents..."}
       ]
    
YOUR SERVER (c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend\)
    ↓
    uploads/ (Physical files)
    ├─ AI-Powered-Customer-Feedback-Intelligence.pdf
    └─ test_document.txt
    
    (No .db, .json, or .sqlite files for data storage)
```

---

## 🔄 RAG Implementation

### **Current RAG Flow:**
```
1. User asks: "What is my coverage?"
   ↓
2. Frontend sends to Backend:
   {
     message: "What is my coverage?",
     rag_context: "AI-Powered-Customer-Feedback-Intelligence.pdf, test_document.txt"
   }
   ↓
3. Backend sends to DeepSeek LLM:
   "You have access to: AI-Powered-Customer-Feedback-Intelligence.pdf, test_document.txt
    User Question: What is my coverage?"
   ↓
4. LLM responds (based on general knowledge, not actual file content!)
   "I can see you have access to these documents..."
```

### ⚠️ **Current Limitation:**
```
❌ LLM receives ONLY document NAMES
❌ LLM does NOT see file contents
❌ LLM uses general insurance knowledge, not your specific docs
❌ No vector search - can't find relevant sections
```

### ✅ **What's Missing:**
```
✗ ChromaDB / Vector DB → Store embeddings of document chunks
✗ PDF text extraction → Read actual content
✗ Semantic search → Find relevant sections
✗ Persistent embeddings → Cache for future queries
```

---

## 📊 Dashboard Stats - Data Source

### **Dynamic Stats (Now Implemented):**
```
Total Documents: 
  Source: Reads from Frontend state → documents.length
  Updates: Real-time as files uploaded
  Storage: localStorage

AI Queries:
  Source: Reads from localStorage → chatMessages
  Counts: Messages with role === 'user'
  Updates: Real-time as user types

System Health:
  Source: Calls backend /health/ endpoint
  Response: {"status": "ok", "external_llm": "healthy", ...}
  Updates: Every 30 seconds
  Storage: None (computed on demand)

Recent Activity:
  Source: Computed from documents + chatMessages
  Logic: generateRecentActivity() function
  Updates: Every 30 seconds
  Storage: None (computed on demand)
```

---

## 🔐 Data Persistence Summary

| Data | Storage | Location | Persistent? | Multi-Device? |
|------|---------|----------|-------------|---------------|
| Chat history | localStorage | Browser | Yes (5-10MB) | No |
| Document list | localStorage | Browser | Yes (5-10MB) | No |
| Uploaded files | File system | ./uploads/ | Yes (permanent) | No |
| Embeddings | RAM | Memory | No (lost on restart) | N/A |
| Session state | RAM | Memory | No (lost on refresh) | N/A |
| Dashboard stats | Computed | On-demand | No (recalculated) | N/A |

---

## 🎯 Files Using Storage

### **Frontend (src/)**
```
App.tsx
├─ localStorage.setItem('documents', JSON.stringify(documents))
├─ localStorage.setItem('chatMessages', JSON.stringify(chatMessages))
└─ localStorage.getItem('documents') / localStorage.getItem('chatMessages')

components/dashboard/Dashboard.tsx
├─ localStorage.getItem('chatMessages')
└─ fetch('/health/') to get system stats

components/chat/ChatInterface.tsx
└─ Uses documents array passed via props
```

### **Backend (backend/)**
```
main.py
├─ @app.post("/upload") → Saves to ./uploads/
├─ @app.post("/chat/") → Uses document names as RAG context
├─ @app.post("/validate_input/") → In-memory validation
└─ @app.get("/health/") → Computes health on demand

models.py
├─ llama_chat() → Local model inference
├─ gemma_chat() → Local model inference
└─ (No persistent storage)

ollama_service.py
└─ Calls Ollama container (ephemeral responses)
```

---

## ⚙️ How To Check Stored Data

### **Check localStorage (Browser):**
```javascript
// Open browser DevTools (F12)
// Go to: Application → Storage → Local Storage → http://localhost:5173
console.log(JSON.parse(localStorage.getItem('documents')))
console.log(JSON.parse(localStorage.getItem('chatMessages')))
```

### **Check Uploaded Files:**
```powershell
# List files in uploads directory
Get-ChildItem "c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend\uploads\"
```

### **Check Backend Endpoints:**
```bash
# Health status
curl http://localhost:8000/health/

# Models available
curl http://localhost:8000/models/
```

---

## 🚀 What You Have vs. What You Need

### ✅ **Currently Implemented:**
- [x] File upload to filesystem (./uploads/)
- [x] Chat history in localStorage
- [x] Document metadata in localStorage
- [x] Dynamic dashboard stats
- [x] RAG context (document names only)
- [x] Input validation (local SLM)
- [x] Multiple LLM support (DeepSeek, Ollama)

### ❌ **NOT Implemented (Future Enhancements):**
- [ ] Vector database (ChromaDB, Pinecone)
- [ ] PDF text extraction
- [ ] Semantic search across documents
- [ ] Persistent embeddings cache
- [ ] PostgreSQL for multi-device sync
- [ ] User authentication
- [ ] Audit logs
- [ ] Long-term analytics

---

## 💡 Recommendation

**For current single-user, single-device use:**
- ✅ Current setup is fine
- Use localStorage for session data
- Store PDFs in ./uploads/

**To add true RAG (semantic search):**
```bash
# Install ChromaDB
pip install chromadb langchain

# Then modify backend to:
# 1. Extract text from uploaded PDFs
# 2. Split into chunks
# 3. Generate embeddings
# 4. Store in Chroma vector DB
# 5. Search semantically on queries
```

**For production (multi-user, persistent):**
```bash
# Install PostgreSQL and connect
pip install sqlalchemy psycopg2

# Then add database layer for:
# - User sessions
# - Persistent chat history
# - Document ownership
# - Audit trails
```

---

## 📝 Final Answer

**Q: Which database file is being used?**

**A:** **NONE.** Your application uses:
1. **localStorage** (browser) - for chat/docs
2. **./uploads/** (filesystem) - for uploaded files  
3. **In-memory** (RAM) - for embeddings/responses

There is no `.db`, `.sqlite`, `.json` database file. Data persists through **browser storage + file system**, not a database engine.
