# Database & Storage Architecture Analysis

## Current Data Storage Setup

### 🗄️ **THREE-TIER STORAGE SYSTEM**

Your application uses **NO centralized database file** currently. Instead, it implements a **hybrid storage pattern**:

---

## 1. **Frontend Storage: Browser localStorage**

**File Location:** Browser's internal storage (not a physical file)
**Data Stored:**
- Chat messages history
- Document metadata
- User session information

**Usage in Code:**
```typescript
// src/App.tsx
localStorage.setItem('documents', JSON.stringify(documents));
localStorage.setItem('chatMessages', JSON.stringify(chatMessages));
```

**Characteristics:**
- ✅ **Persists across page refreshes**
- ✅ **Persists across tab switches**
- ❌ **Limited to ~5-10MB per domain**
- ❌ **Lost when browser cache is cleared**
- ❌ **Not shared between different browsers**

---

## 2. **Backend File Storage: ./uploads/ Directory**

**Location:** `c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend\uploads/`

**Files Currently Stored:**
```
uploads/
├── AI-Powered-Customer-Feedback-Intelligence.pdf
└── test_document.txt
```

**How It Works:**
```python
# backend/main.py - lines 350-380
@app.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    file_path = upload_dir / file.filename
    # Saves file directly to ./uploads/
    with open(file_path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    return {"success": True, "path": str(file_path)}
```

**Characteristics:**
- ✅ **Persists across application restarts**
- ✅ **Unlimited file size (up to 50MB limit in code)**
- ✅ **Direct file access for RAG context**
- ❌ **No structured indexing**
- ❌ **No search capability**
- ❌ **No metadata tracking beyond filename**

---

## 3. **RAG Context: In-Memory Processing**

**Location:** FastAPI backend (memory only, not persistent)

**How RAG Works (Current Implementation):**
```python
# backend/main.py - lines 375-395
def chat_with_deepseek(message: str, rag_context: Optional[str] = None, documents: Optional[List[dict]] = None):
    enhanced_message = f"""You have access to the following documents: {context_str}
    
User Question: {message}"""
    # Sends document names to LLM, not actual content
```

**RAG Context Provided:**
- ❌ **NOT reading file contents** - Only document names sent to LLM
- ✅ **Document names available** - "AI-Powered-Customer-Feedback-Intelligence.pdf, test_document.txt"
- ❌ **No vector embeddings stored**
- ❌ **No semantic search**

---

## 📊 Data Flow Diagram

```
USER INTERFACE (React)
    ↓
    ├─→ localStorage (chat, documents list)
    │   └─→ Persists across sessions
    │
    └─→ API Calls to Backend
           ↓
    FASTAPI BACKEND
         ↓
         ├─→ /validate_input/ → Validates question (in-memory)
         │
         ├─→ /upload → Saves to ./uploads/
         │
         ├─→ /chat/ → DeepSeek with RAG context
         │   └─→ Document names sent to LLM
         │
         └─→ /embed/ → Embeddings (not stored)
```

---

## 🎯 Missing Database Components for Full RAG

| Component | Status | Current | Needed |
|-----------|--------|---------|--------|
| **Document Storage** | ✅ | ./uploads/ files | ✅ As-is |
| **Document Indexing** | ❌ | None | ChromaDB/Pinecone/Weaviate |
| **Vector Embeddings** | ❌ | Generated on-demand | Persistent vector DB |
| **Chat History** | ✅ | localStorage | PostgreSQL for multi-device |
| **Document Metadata** | ❌ | Filename only | Full metadata index |
| **Semantic Search** | ❌ | None | Vector similarity search |
| **Dashboard Stats** | ✅ | Dynamic (from state) | Real DB queries |

---

## 📁 File Structure Summary

```
UI_FF1/
├── src/
│   ├── App.tsx              → Uses localStorage
│   ├── components/
│   │   ├── chat/
│   │   │   └── ChatInterface.tsx → localStorage management
│   │   └── dashboard/
│   │       └── Dashboard.tsx → Reads from localStorage & /health/
│   └── types/
│       └── index.ts
│
└── backend/
    ├── main.py              → FastAPI routes (no DB)
    ├── models.py            → Local SLM wrappers
    ├── ollama_service.py    → Ollama integration
    ├── .env                 → API keys (not a database)
    ├── requirements.txt     → Dependencies
    └── uploads/             ← **FILE STORAGE** (NOT indexed)
        ├── AI-Powered-Customer-Feedback-Intelligence.pdf
        └── test_document.txt
```

---

## 🔍 Current Data Persistence

### ✅ What IS Persisted:
1. **Chat Messages** → localStorage (browser)
2. **Document List** → localStorage (browser)
3. **Uploaded Files** → ./uploads/ (filesystem)
4. **System Health** → Computed on-demand (/health/ endpoint)

### ❌ What's NOT Persisted:
1. **Vector Embeddings** → Generated each request, not stored
2. **Document Content Index** → Files exist but not indexed
3. **User Sessions** → Lost when browser cleared
4. **Cross-Device Data** → Not synced
5. **Structured Metadata** → Filename only stored

---

## 💡 Recommendations

### **Phase 1 (Current - Acceptable):**
- ✅ Use localStorage for chat/documents (works for single-device)
- ✅ Store PDFs in ./uploads/
- ⚠️ Document names sent to LLM (limited context)

### **Phase 2 (Recommended - Add Vector DB):**
```
Install: pip install chromadb
Use: Persistent vector store for embeddings
Benefit: True semantic search across documents
```

### **Phase 3 (Production - Add Backend DB):**
```
Install: pip install sqlalchemy psycopg2
Use: PostgreSQL for persistent storage
Benefit: Multi-user support, analytics, audit logs
```

---

## 📝 Summary

**The application currently uses a HYBRID approach:**
- **Frontend:** Browser localStorage (no physical database file)
- **Documents:** Filesystem storage in `./uploads/` (not indexed)
- **RAG Context:** Document names only (limited scope)
- **Session Data:** In-memory + localStorage (not cloud-synced)

**No dedicated database file exists** - it's a file-based + browser storage architecture. For production, you should implement ChromaDB or PostgreSQL for proper RAG and multi-user support.
