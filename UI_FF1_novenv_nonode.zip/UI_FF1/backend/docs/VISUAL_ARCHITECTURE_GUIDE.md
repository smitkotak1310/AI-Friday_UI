
# 🎨 Visual Architecture Guide - ChromaDB RAG System

## System Overview Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                     POLICY ASSISTANT AI APPLICATION                        │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────────────────┐        ┌───────────────────────────────────┐ │
│  │   REACT FRONTEND         │        │   FASTAPI BACKEND                │ │
│  │   (Port 5173)            │        │   (Port 8000)                    │ │
│  │                          │        │                                  │ │
│  │  ┌────────────────────┐  │        │  ┌──────────────────────────────┤ │
│  │  │   Dashboard Tab    │  │        │  │  /health/                    │ │
│  │  │  • Live Stats      │◄─┼────────┼─►│  /documents/stats/           │ │
│  │  │  • Document Count  │  │  API   │  │  /upload                     │ │
│  │  │  • System Health   │  │ Calls  │  │  /chat/                      │ │
│  │  └────────────────────┘  │        │  │  /search/                    │ │
│  │                          │        │  └──────────────────────────────┤ │
│  │  ┌────────────────────┐  │        │                                  │ │
│  │  │    Chat Tab        │  │        │  ┌──────────────────────────────┐ │
│  │  │ • Q&A Interface    │◄─┼────────┼─►│ Input Validation (SLM)       │ │
│  │  │ • RAG Badge        │  │        │  │ Policy-relevance check       │ │
│  │  │ • History          │  │        │  └──────────────────────────────┘ │
│  │  └────────────────────┘  │        │                                  │ │
│  │                          │        │  ┌──────────────────────────────┐ │
│  │  ┌────────────────────┐  │        │  │ Document Processing          │ │
│  │  │  Documents Tab     │  │        │  │ • Text Extraction (PyPDF)    │ │
│  │  │ • File List        │◄─┼────────┼─►│ • Metadata Capture           │ │
│  │  │ • Upload Btn       │  │        │  └──────────────────────────────┘ │
│  │  └────────────────────┘  │        │                                  │ │
│  │                          │        │  ┌──────────────────────────────┐ │
│  │  localStorage:           │        │  │ Embeddings Generation        │ │
│  │  • Chat history          │        │  │ • OpenAI API                 │ │
│  │  • Document list         │        │  │ • 3072-D vectors             │ │
│  │  • Preferences           │        │  └──────────────────────────────┘ │
│  │                          │        │                                  │ │
│  └──────────────────────────┘        │  ┌──────────────────────────────┐ │
│                                      │  │      ChromaDB Service         │ │
│                                      │  │  ┌──────────────────────────┐ │ │
│                                      │  │  │ Collection: policy_docs  │ │ │
│                                      │  │  │ • Add document           │ │ │
│                                      │  │  │ • Search (similarity)    │ │ │
│                                      │  │  │ • Get count              │ │ │
│                                      │  │  │ • Health check           │ │ │
│                                      │  │  └──────────────────────────┘ │ │
│                                      │  └──────────────────────────────┘ │
│                                      │                                  │ │
│                                      │  ┌──────────────────────────────┐ │
│                                      │  │  Semantic Search Module       │ │
│                                      │  │ • Cosine similarity           │ │
│                                      │  │ • Top-K ranking               │ │
│                                      │  │ • Relevance scoring           │ │
│                                      │  └──────────────────────────────┘ │
│                                      │                                  │ │
│                                      │  ┌──────────────────────────────┐ │
│                                      │  │   DeepSeek V3 LLM             │ │
│                                      │  │ • Receive question            │ │
│                                      │  │ • Get RAG context             │ │
│                                      │  │ • Generate answer             │ │
│                                      │  │ • Return with metadata        │ │
│                                      │  └──────────────────────────────┘ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                          DATA PERSISTENCE LAYER                            │
│                                                                             │
│  ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐   │
│  │  ./chroma_db/    │    │  ./uploads/      │    │  localStorage    │   │
│  │                  │    │                  │    │                  │   │
│  │ • chroma.sqlite3 │    │ • policy.pdf     │    │ • chatMessages   │   │
│  │ • embeddings.*   │    │ • coverage.txt   │    │ • documents      │   │
│  │ • documents.*    │    │ • claims.pdf     │    │ • preferences    │   │
│  │ • metadatas.*    │    │ • terms.txt      │    │                  │   │
│  │ • ids.*          │    │                  │    │ Persistence:     │   │
│  │                  │    │ Persistence:     │    │ Session-local    │   │
│  │ Persistence:     │    │ Permanent        │    │                  │   │
│  │ Permanent        │    │                  │    │ Updates:         │   │
│  │                  │    │ Updates:         │    │ Real-time        │   │
│  │ Updates:         │    │ On upload        │    │                  │   │
│  │ On index         │    │                  │    │                  │   │
│  │                  │    │                  │    │                  │   │
│  └──────────────────┘    └──────────────────┘    └──────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Data Flow Diagrams

### 1. DOCUMENT UPLOAD FLOW

```
                            ┌─────────────────┐
                            │  User Browser   │
                            │  clicks Upload  │
                            └────────┬────────┘
                                     │
                                     ▼
                        ┌────────────────────────┐
                        │  Select PDF/TXT File   │
                        └────────────┬───────────┘
                                     │
                                     ▼
                    ┌────────────────────────────────┐
                    │  POST /upload (multipart)      │
                    │  file: <binary data>           │
                    └────────────┬───────────────────┘
                                 │
                    ┌────────────▼──────────────────────┐
                    │   FastAPI Backend Receives File   │
                    └────────────┬──────────────────────┘
                                 │
                ┌────────────────┴────────────────┐
                │                                 │
         ┌──────▼──────┐             ┌───────────▼────────┐
         │ Save to     │             │ Validate File      │
         │ ./uploads/  │             │ • Type: PDF/TXT    │
         │             │             │ • Size: <50MB      │
         └──────┬──────┘             └──────────┬─────────┘
                │                              │
                └──────────────┬───────────────┘
                               │
                   ┌───────────▼─────────────┐
                   │ Extract Text Content    │
                   │ • PDF: PyPDF library    │
                   │ • TXT: Read file        │
                   │ • UTF-8 encoding        │
                   └───────────┬─────────────┘
                               │
                   ┌───────────▼──────────────────┐
                   │ Generate Embeddings          │
                   │ • Call OpenAI API            │
                   │ • Create 3072-D vector       │
                   │ • Add metadata               │
                   └───────────┬──────────────────┘
                               │
          ┌────────────────────▼────────────────────┐
          │  Store in ChromaDB Collection           │
          │  • Document text                        │
          │  • Vector embedding                     │
          │  • Metadata (filename, type, size)      │
          │  • Unique ID                            │
          └────────────┬─────────────────────────────┘
                       │
                ┌──────▼─────────────┐
                │ Response to Client │
                │ {                  │
                │   success: true    │
                │   indexed: true    │
                │   total_indexed: 3 │
                │ }                  │
                └──────┬─────────────┘
                       │
           ┌───────────▼──────────────┐
           │ Frontend Updates State    │
           │ • localStorage updated   │
           │ • Document list changed  │
           │ • Dashboard refreshes    │
           └──────────────────────────┘
```

### 2. CHAT WITH RAG FLOW

```
                        ┌──────────────────┐
                        │  User Types Q&A  │
                        │  "What's my      │
                        │  deductible?"    │
                        └────────┬─────────┘
                                 │
                    ┌────────────▼────────────┐
                    │ Frontend: Validate      │
                    │ Input (Ollama SLM)      │
                    │ • Policy-related? YES   │
                    │ • Irrelevant? NO        │
                    └────────────┬────────────┘
                                 │
                    ┌────────────▼──────────────┐
                    │ POST /chat/ request       │
                    │ message: "What's my..."   │
                    │ model: "deepseek"         │
                    └────────────┬──────────────┘
                                 │
                    ┌────────────▼──────────────┐
                    │  Backend: Process Q&A     │
                    └────────────┬──────────────┘
                                 │
         ┌───────────────────────┴───────────────────────┐
         │                                               │
    ┌────▼───────────┐                    ┌──────────────▼────┐
    │ Generate        │                    │ ChromaDB Search:  │
    │ Embedding for   │                    │ • Query embedding │
    │ Question        │                    │ • Find similar    │
    │ (OpenAI)        │                    │ • Get top 3       │
    └────┬────────────┘                    └──────────┬────────┘
         │                                           │
         │    ┌──────────────────────────────────────┘
         │    │
         └────▼────────────────────────────────┐
              │                                │
              ▼                                ▼
    ┌─────────────────────┐      ┌───────────────────────┐
    │  Question: "What's  │      │  Result 1 (85%):      │
    │  my deductible?"    │      │  "Deductible: $500"   │
    │                     │      │                       │
    │  Embedding:         │      │  Result 2 (72%):      │
    │  [0.45, 0.12, ...]  │      │  "For all claims"     │
    │  (3072 values)      │      │                       │
    │                     │      │  Result 3 (68%):      │
    │                     │      │  "Accident coverage"   │
    └─────────────────────┘      └───────────────────────┘
              │                                │
              └────────────────┬───────────────┘
                               │
                   ┌───────────▼──────────────┐
                   │ Build RAG Prompt:        │
                   │                          │
                   │ "You have access to:     │
                   │                          │
                   │  [Score: 85%]            │
                   │  Deductible: $500 for    │
                   │  all claims              │
                   │                          │
                   │  [Score: 72%]            │
                   │  Accident coverage       │
                   │  applies to all claims   │
                   │                          │
                   │  User: What's my         │
                   │  deductible?"            │
                   └───────────┬──────────────┘
                               │
                    ┌──────────▼──────────────┐
                    │ Send to DeepSeek LLM    │
                    │ (with RAG context)      │
                    └──────────┬───────────────┘
                               │
                    ┌──────────▼──────────────────┐
                    │ LLM Generates Response      │
                    │                            │
                    │ "Based on your policy      │
                    │  documents, your          │
                    │  deductible is $500 for   │
                    │  all claims."             │
                    └──────────┬─────────────────┘
                               │
                   ┌───────────▼──────────────┐
                   │ Response with Metadata:  │
                   │ {                        │
                   │   response: "Based...",  │
                   │   used_rag: true,        │
                   │   rag_source: "chromadb",
                   │   documents_ref: 3      │
                   │ }                        │
                   └───────────┬──────────────┘
                               │
                   ┌───────────▼──────────────┐
                   │ Frontend Displays Chat   │
                   │ Message + RAG Badge      │
                   │ "💡 RAG-powered answer" │
                   └──────────────────────────┘
```

---

## Component Interaction Matrix

```
                   Frontend          Backend         ChromaDB
                   ────────          ───────         ────────

Dashboard ────────────┼──────────────────┼──────────────────┼
  •Stats             │ Fetch /stats/    │ Query count      │ Get indexed
  •Health            │                  │ Check health     │ Check status
  •Activity          │                  │                  │

Chat ─────────────────┼──────────────────┼──────────────────┼
  •Message          │ POST /chat/      │ Validate input   │
  •History          │ Get response     │ Search documents │ Find similar
  •RAG Badge        │                  │ Send to LLM      │ docs
  •Validation       │                  │ Return answer    │

Upload ───────────────┼──────────────────┼──────────────────┼
  •File Select      │ POST /upload/    │ Extract text     │
  •Progress         │ Get status       │ Generate embed   │ Store doc
  •Count Update     │                  │ Store in DB      │

Documents ────────────┼──────────────────┼──────────────────┼
  •File List        │ Fetch /models    │ List files       │
  •Upload Zone      │                  │ Manage docs      │ Access files
  •View File        │                  │                  │
```

---

## Search & Similarity Visualization

```
Question: "What is the deductible?"

Query Embedding:
┌─────────────────────────────────────┐
│ [0.245, 0.189, -0.045, ...]         │
│ 3,072 dimensional vector            │
│ Represents: "deductible" meaning    │
└─────────────────────────────────────┘
                  │
                  │ Search in ChromaDB
                  ▼
┌────────────────────────────────────────────────────┐
│            Document Embeddings                    │
├────────────────────────────────────────────────────┤
│                                                    │
│ Doc 1: "The deductible is $500"                  │
│ Embedding: [0.248, 0.192, -0.041, ...]          │
│ Similarity: 0.95 ████████████████████ 95%        │
│                                                    │
│ Doc 2: "Covers accidents and claims"            │
│ Embedding: [0.198, 0.145, -0.020, ...]          │
│ Similarity: 0.72 ██████████████ 72%              │
│                                                    │
│ Doc 3: "Premium is $50/month"                    │
│ Embedding: [0.102, 0.065, 0.031, ...]           │
│ Similarity: 0.38 ████████ 38%                    │
│                                                    │
│ Doc 4: "Hours of operation 9am-5pm"             │
│ Embedding: [0.015, 0.009, 0.102, ...]           │
│ Similarity: 0.12 ██ 12% (FILTERED OUT)           │
│                                                    │
└────────────────────────────────────────────────────┘
         │
         │ Return top_k=3
         ▼
    ┌──────────────────┐
    │ Results (sorted) │
    │ 1. Doc 1 (95%)   │ ◄─ Best match
    │ 2. Doc 2 (72%)   │
    │ 3. Doc 3 (38%)   │
    └──────────────────┘
```

---

## Status & Health Indicators

```
Dashboard Display:

┌────────────────────────────────────────────┐
│           System Status                    │
├────────────────────────────────────────────┤
│                                            │
│  External LLM: ✓ healthy (DeepSeek V3)    │
│                                            │
│  Embeddings: ✓ healthy (OpenAI)            │
│                                            │
│  Ollama Service: ✓ healthy (Local SLM)     │
│                                            │
│  ChromaDB: ✓ healthy (2 documents)         │
│            └─ Vector DB: Running           │
│            └─ Collection: policy_documents │
│            └─ Indexed: 2 documents         │
│                                            │
│  File Storage: ✓ OK (./uploads/)           │
│                                            │
│  Overall Health: 99.9% 🟢 (GREEN)          │
│                                            │
└────────────────────────────────────────────┘
```

---

## Request/Response Examples

### Upload Request
```
POST http://localhost:8000/upload
Content-Type: multipart/form-data

────────────────────────────────────────────
multipart/form-data; boundary=----FormBoundary
────────────────────────────────────────────
------FormBoundary
Content-Disposition: form-data; name="file"; filename="policy.pdf"
Content-Type: application/pdf

[Binary PDF data...]
------FormBoundary--
```

### Chat Request
```
POST http://localhost:8000/chat/
Content-Type: application/json

{
  "message": "What is my deductible?",
  "model": "deepseek",
  "temperature": 0.7
}
```

### Search Request
```
POST http://localhost:8000/search/?query=deductible&top_k=3
```

### Response Example
```json
{
  "response": "Based on your policy documents, your deductible 
   is $500 for all covered claims. This means you will need to 
   pay the first $500 of any covered claim before the insurance 
   coverage applies.",
  "model": "deepseek",
  "success": true,
  "used_rag": true,
  "rag_source": "chroma_db",
  "documents_referenced": 3
}
```

---

## Technology Stack Visualization

```
┌─────────────────────────────────────────────────────────────┐
│                   APPLICATION LAYER                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Dashboard  │  │     Chat     │  │  Documents   │      │
│  │   (React)    │  │   (React)    │  │   (React)    │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
                          ▲
                          │ HTTP/REST API
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                   API LAYER (FastAPI)                       │
│  ├─ /upload          ├─ /chat/          ├─ /search/        │
│  ├─ /documents/stats ├─ /validate/      ├─ /health/        │
│  └─ /reason/         ├─ /embed/         └─ /models/        │
└─────────────────────────────────────────────────────────────┘
                          ▲
        ┌─────────────────┼─────────────────┐
        │                 │                 │
        ▼                 ▼                 ▼
┌──────────────┐   ┌──────────────┐   ┌────────────────┐
│  ChromaDB    │   │  DeepSeek    │   │  OpenAI        │
│  Vector DB   │   │  LLM (V3)    │   │  Embeddings    │
│              │   │              │   │                │
│ • Storage    │   │ • Q&A        │   │ • Embed query  │
│ • Search     │   │ • Reasoning  │   │ • Embed docs   │
│ • Index      │   │ • Chat       │   │ • 3072-D       │
└──────────────┘   └──────────────┘   └────────────────┘
        │
        ▼
┌──────────────┐
│ Persistent   │
│ Storage      │
│              │
│ • chroma_db/ │
│ • uploads/   │
└──────────────┘
```

---

**Visual Guide Complete!** 🎨

The diagrams above show:
- System architecture and components
- Data flow for uploads and chat
- Component interactions
- Embedding similarity visualization
- Status indicators
- Technology stack

All integrated into one powerful RAG system! 🚀
