# LLM and Embedding Configuration Guide

## Overview
This document details the LLM and Embedding Model setup for the UI_FF1 application.

## Configuration Details

### 1. External LLM - DeepSeek V3

**Location**: `backend/main.py` (lines 43-49)

```python
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key=OPENAI_API_KEY,  # From .env
    temperature=0.7,
    max_tokens=512
)
```

**Configuration Details**:
- **Provider**: Azure AI Lab (genailab.tcs.in)
- **Model Name**: `azure_ai/genailab-maas-DeepSeek-V3-0324`
- **Type**: Large Language Model (LLM)
- **Purpose**: 
  - Primary chat and reasoning
  - Complex question answering
  - Advanced analysis and problem-solving
- **Temperature**: 0.7 (balanced creativity)
- **Max Tokens**: 512 (reasonable response length)
- **Framework**: LangChain `ChatOpenAI`

**Required Environment Variable**:
```env
OPENAI_API_KEY=YOUR_DEEPSEEK_API_KEY
OPENAI_BASE_URL=https://genailab.tcs.in
```

---

### 2. Embedding Model - Text Embedding 3 Large

**Location**: `backend/main.py` (lines 52-58)

```python
embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key=OPENAI_API_KEY,  # From .env
    http_client=client  # Optional: custom HTTP client
)
```

**Configuration Details**:
- **Provider**: Azure AI Lab (genailab.tcs.in)
- **Model Name**: `azure/genailab-maas-text-embedding-3-large`
- **Type**: Embedding Model (Vector Generation)
- **Purpose**:
  - Convert text to 3072-dimensional vectors
  - Semantic search and similarity matching
  - RAG (Retrieval Augmented Generation)
  - Document indexing and retrieval
- **Embedding Dimension**: 3072
- **Framework**: LangChain `OpenAIEmbeddings`

**Required Environment Variable**:
```env
OPENAI_API_KEY=YOUR_EMBEDDING_API_KEY
OPENAI_BASE_URL=https://genailab.tcs.in
```

**Note**: Can use the same API key as the LLM if both are from the same Azure account.

---

### 3. Local SLM - Ollama Service

**Location**: `backend/ollama_service.py` (lines 40-60)

**Pattern**: Follows `validation_service.py` design from reference project

```python
class OllamaService:
    def __init__(self, host: str = "http://localhost:11434"):
        self.host = host
        self.available = OLLAMA_AVAILABLE
        if self.available:
            self.client = Client(host=host)
```

**Configuration Details**:
- **Service**: Ollama (local containerized inference engine)
- **Default Host**: `http://localhost:11434`
- **Type**: Small Language Models (SLMs)
- **Available Models**:
  - `llama2` - General-purpose chat
  - `neural-chat` - Conversational AI
  - `mistral` - Fast inference
  - And any other models installed in Ollama
- **Purpose**:
  - Fallback when cloud service is unavailable
  - Privacy-focused local inference
  - Fast responses for simple queries
  - Validation and filtering

**Environment Variable** (Optional):
```env
OLLAMA_HOST=http://localhost:11434
```

**Starting Ollama**:
```bash
# Install Ollama first from https://ollama.ai
ollama serve
```

---

### 4. Direct Local SLMs - Transformers & Llama-CPP

**Location**: `backend/models.py`

**Available Models**:

#### Llama-3.2-3b-it (llama-cpp-python)
- **Path**: `../models/llama-3.2-3b-it/llama-3.2-3b-it.Q4_K_M.gguf`
- **Function**: `llama_chat(message, history)`

#### Gemma-3-4b-it (transformers)
- **Path**: `../models/gemma-3-4b-it`
- **Function**: `gemma_chat(message, history)`

#### Qwen-2.5.1-coder-it (transformers)
- **Path**: `../models/qwen-2.5.1-coder-it`
- **Function**: `qwen_chat(message, history)`

#### Deepseek-r1 (transformers)
- **Path**: `../models/deepseek-r1`
- **Function**: `deepseek_reason(task, context)`

#### GTE-Large (sentence-transformers - embedding)
- **Path**: `../models/gte-large`
- **Function**: `gte_embed(text)`
- **Purpose**: Local alternative to cloud embeddings

---

## Integration Points

### 1. Chat Endpoint (`POST /chat/`)
```python
# Routing logic:
if req.model == "deepseek":
    return chat_with_deepseek(req.message, req.history, req.temperature)
elif req.model.startswith("ollama_"):
    return chat_with_ollama(...)
elif req.model in ["llama", "gemma", "qwen"]:
    return legacy_local_slm_chat(...)
```

### 2. Reasoning Endpoint (`POST /reason/`)
```python
# Routing logic:
if req.model == "deepseek":
    return reason_with_deepseek(req.task, req.context, req.temperature)
elif req.model.startswith("ollama_"):
    return reason_with_ollama(...)
```

### 3. Embedding Endpoint (`POST /embed/`)
```python
# Routing logic:
if req.model == "openai":
    return embed_with_openai(req.text)
elif req.model == "gte":
    return gte_embed(req.text)
```

---

## Setup Instructions

### 1. Environment Configuration

Create `.env` file in `backend/` directory:

```env
# Azure AI Lab Credentials
OPENAI_API_KEY=your_actual_api_key_here
OPENAI_BASE_URL=https://genailab.tcs.in

# Optional: Local SLM Configuration
OLLAMA_HOST=http://localhost:11434

# Optional: Local Model Path
OLLAMA_MODEL_PATH=../models
```

### 2. Install Python Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 3. Start Backend Server

```bash
# From backend directory
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### 4. Start Ollama (Optional, for local SLMs)

```bash
# In a separate terminal
ollama serve
```

### 5. Verify Setup

```bash
# Check health endpoint
curl http://localhost:8000/health/

# Expected response:
{
    "status": "ok",
    "external_llm": "healthy",
    "ollama_service": "healthy" or "unavailable",
    "embeddings": "healthy"
}
```

---

## API Request Examples

### Chat with DeepSeek
```bash
curl -X POST http://localhost:8000/chat/ \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What is the capital of France?",
    "model": "deepseek",
    "temperature": 0.7
  }'
```

### Chat with Ollama Local SLM
```bash
curl -X POST http://localhost:8000/chat/ \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Hello, how are you?",
    "model": "ollama_llama2",
    "temperature": 0.7
  }'
```

### Generate Embeddings (OpenAI)
```bash
curl -X POST http://localhost:8000/embed/ \
  -H "Content-Type: application/json" \
  -d '{
    "text": "This is a sample document for embedding",
    "model": "openai"
  }'
```

### Generate Embeddings (Local GTE)
```bash
curl -X POST http://localhost:8000/embed/ \
  -H "Content-Type: application/json" \
  -d '{
    "text": "This is a sample document for embedding",
    "model": "gte"
  }'
```

### Reasoning Task
```bash
curl -X POST http://localhost:8000/reason/ \
  -H "Content-Type: application/json" \
  -d '{
    "task": "Solve this logic puzzle: If A > B and B > C, what is the relationship between A and C?",
    "model": "deepseek",
    "context": "Use logical deduction"
  }'
```

---

## Troubleshooting

### DeepSeek LLM Not Initializing
**Error**: `✗ Failed to initialize ChatOpenAI`
- **Solution**: 
  - Verify `OPENAI_API_KEY` in `.env`
  - Check internet connection to `https://genailab.tcs.in`
  - Verify API key is valid and not expired

### Embedding Model Not Initializing
**Error**: `✗ Failed to initialize OpenAIEmbeddings`
- **Solution**:
  - Same as LLM troubleshooting
  - Ensure model name is correct: `azure/genailab-maas-text-embedding-3-large`

### Ollama Service Not Available
**Warning**: `⚠ Ollama service not available`
- **Solution**:
  - Start Ollama: `ollama serve`
  - Check Ollama is running on `http://localhost:11434`
  - Optional - not required for DeepSeek-based application

### Local SLM Models Not Found
**Error**: `Model not found at ../models/llama-3.2-3b-it`
- **Solution**:
  - Download models to the correct directory
  - Update paths in `models.py` if needed
  - Use Ollama as alternative (automatically handles model downloads)

---

## Performance Comparison

| Model | Type | Latency | Quality | Cost | Privacy |
|-------|------|---------|---------|------|---------|
| DeepSeek V3 | LLM | Medium (Network) | Excellent | Per-call | Cloud |
| Text Embedding 3L | Embedding | Medium (Network) | Excellent | Per-call | Cloud |
| Ollama Llama2 | SLM | Low (Local) | Good | Free | Local |
| GTE-Large | Embedding | Low (Local) | Good | Free | Local |
| Deepseek-r1 | SLM (Transformers) | Medium (Local GPU) | Excellent | Free | Local |

---

## Architecture Diagram

```
┌─────────────────────────────────────┐
│     React Frontend (TypeScript)      │
└─────────────┬───────────────────────┘
              │ HTTP (JSON)
┌─────────────▼───────────────────────┐
│      FastAPI Backend (Python)        │
├─────────────────────────────────────┤
│ Main.py                              │
│ ├─ ChatOpenAI (DeepSeek V3) ◄────┐  │
│ ├─ OpenAIEmbeddings ◄─────────┐  │  │
│ ├─ OllamaService (SLMs) ◄──┐  │  │  │
│ └─ Models (Transformers) ◄─┤──┤──┼──┤
└─────────────────────────────┤──┤──┼──┘
                              │  │  │
            ┌─────────────────┘  │  │
            │                    │  │
        ┌───▼──────────┐     ┌───▼──▼────────┐
        │    Ollama    │     │  Azure AI Lab │
        │   (Local)    │     │  (Cloud)      │
        │              │     │               │
        │ - Llama2     │     │ - DeepSeek    │
        │ - Neural-Chat│     │ - Embedding   │
        │ - Mistral    │     │   Models      │
        └──────────────┘     └───────────────┘
```

---

## Summary

✅ **LLM**: DeepSeek V3 via Azure AI Lab (Cloud-based, high-quality)
✅ **Embedding Model**: Text Embedding 3 Large via Azure AI Lab (Cloud-based, high-quality)
✅ **Local SLM Fallback**: Ollama service following `validation_service.py` pattern
✅ **Hybrid Architecture**: Flexible model selection based on use case

This setup provides:
- **Primary** high-quality responses via cloud LLM
- **Secondary** fast local inference via Ollama
- **Resilience** with multiple fallback options
- **Privacy** option with fully local alternatives
- **Flexibility** to switch models as needed

---

*Configuration Last Updated: April 2026*
*UI_FF1 Project - Civic Services AI Assistant*
