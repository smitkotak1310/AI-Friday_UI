# filepath: c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend\main.py
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict
import os
from dotenv import load_dotenv
import shutil
from pathlib import Path
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
import logging
from duckduckgo_search import DDGS

# Import local SLM functions
from models import (
    llama_chat, gemma_chat, qwen_chat, deepseek_reason, gte_embed
)

# Import Ollama service (follows validation_service.py pattern)
from ollama_service import ollama_service

# Import ChromaDB service
# [ORIGINAL — Windows/lab env with local SLMs & GTE embedding model]
# from chroma_service import initialize_chroma_service, get_chroma_service

# [MAC] Uses Azure OpenAI embeddings directly — no ONNX/all-MiniLM download needed
from chroma_service_mac import initialize_chroma_service_mac, get_chroma_service_mac

# Import document extraction
from document_extractor import extract_text_from_document, get_file_info

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

app = FastAPI()

# Allow CORS for local frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize LangChain models with Azure endpoint
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://genailab.tcs.in")

try:
    # Initialize ChatOpenAI with DeepSeek V3
    llm = ChatOpenAI(
        base_url=OPENAI_BASE_URL,
        model="azure_ai/genailab-maas-DeepSeek-V3-0324",
        api_key=OPENAI_API_KEY,
        temperature=0.7,
        max_tokens=512
    )
    logger.info("✓ ChatOpenAI (DeepSeek V3) initialized successfully")
except Exception as e:
    logger.error(f"✗ Failed to initialize ChatOpenAI: {e}")
    llm = None

try:
    # Initialize OpenAI Embeddings
    embedding_model = OpenAIEmbeddings(
        base_url=OPENAI_BASE_URL,
        model="azure/genailab-maas-text-embedding-3-large",
        api_key=OPENAI_API_KEY
    )
    logger.info("✓ OpenAIEmbeddings initialized successfully")
except Exception as e:
    logger.error(f"✗ Failed to initialize OpenAIEmbeddings: {e}")
    embedding_model = None

# Initialize ChromaDB service with embeddings
# [ORIGINAL — Windows/lab env: uses chroma_service.initialize_chroma_service
#  which relies on ChromaDB's default embedding (all-MiniLM-L6-v2 via ONNX)]
# try:
#     chroma_db = initialize_chroma_service(embedding_model=embedding_model)
#     if chroma_db and chroma_db.is_healthy():
#         logger.info("✓ ChromaDB service initialized successfully")
#         logger.info(f"  Current documents in vector DB: {chroma_db.get_document_count()}")
#     else:
#         logger.warning("⚠ ChromaDB service not healthy")
#         chroma_db = None
# except Exception as e:
#     logger.error(f"✗ Failed to initialize ChromaDB: {e}")
#     chroma_db = None

# [MAC] Initialize ChromaDB using chroma_service_mac — explicit Azure OpenAI
# embeddings passed in, so ChromaDB never downloads a local ONNX model.
try:
    chroma_db = initialize_chroma_service_mac(embedding_model=embedding_model)
    if chroma_db and chroma_db.is_healthy():
        logger.info("✓ [MAC] ChromaDB service initialized successfully")
        logger.info(f"  Current documents in vector DB: {chroma_db.get_document_count()}")
    else:
        logger.warning("⚠ [MAC] ChromaDB service not healthy")
        chroma_db = None
except Exception as e:
    logger.error(f"✗ [MAC] Failed to initialize ChromaDB: {e}")
    chroma_db = None

# Log Ollama service status
if ollama_service and ollama_service.available:
    health = ollama_service.health_check()
    logger.info(f"✓ Ollama service status: {health['status']}")
    if health.get("available_models"):
        logger.info(f"  Available models: {', '.join(health['available_models'][:3])}...")
else:
    logger.warning("⚠ Ollama service not available (optional for local SLMs)")

# ==================== Request Models ====================

class ChatRequest(BaseModel):
    """Chat request with model selection"""
    message: str
    model: str  # 'deepseek', 'ollama_llama2', 'ollama_neural_chat', etc.
    history: Optional[List[dict]] = None
    temperature: Optional[float] = 0.7
    rag_context: Optional[str] = None
    documents: Optional[List[dict]] = None
    use_internet: bool = False

class ReasonRequest(BaseModel):
    """Reasoning request"""
    task: str
    model: str  # 'deepseek', 'ollama_neural_chat', etc.
    context: Optional[str] = None
    temperature: Optional[float] = 0.5

class EmbedRequest(BaseModel):
    """Embedding request"""
    text: str
    model: str  # 'openai', 'gte'

class ValidationRequest(BaseModel):
    """Validation request (like validation_service.py)"""
    query: str
    rules: str
    model: Optional[str] = "llama2"
    temperature: Optional[float] = 0.3

class ValidationInputRequest(BaseModel):
    """Input validation request to check if question is policy-related"""
    query: str
    model: Optional[str] = "llama2"
    temperature: Optional[float] = 0.3

class OllamaModelListResponse(BaseModel):
    """Response with list of Ollama models"""
    models: List[str]

class DocumentStatsResponse(BaseModel):
    """Response with document statistics"""
    total_documents: int
    total_queries: int
    system_health: str
    chroma_db_status: str
    indexed_documents: int

# ==================== Health & Status Endpoints ====================

@app.get("/health/")
def health_check():
    """Health check endpoint"""
    ollama_status = "healthy" if (ollama_service and ollama_service.available) else "unavailable"
    chroma_status = "healthy" if (chroma_db and chroma_db.is_healthy()) else "unavailable"
    
    return {
        "status": "ok",
        "external_llm": "healthy" if llm else "unavailable",
        "ollama_service": ollama_status,
        "embeddings": "healthy" if embedding_model else "unavailable",
        "chroma_db": chroma_status,
        "indexed_documents": chroma_db.get_document_count() if chroma_db else 0
    }

@app.get("/models/")
def get_available_models():
    """List all available models"""
    ollama_models = []
    if ollama_service and ollama_service.available:
        ollama_models = ollama_service.list_models()
    
    return {
        "llm_models": ["deepseek"],
        "slm_models": ["ollama_llama2", "ollama_neural_chat", "ollama_mistral"],
        "embedding_models": ["openai", "gte"],
        "ollama_available_models": ollama_models,
        "ollama_status": "healthy" if (ollama_service and ollama_service.available) else "unavailable"
    }

@app.get("/ollama/models/")
def get_ollama_models():
    """Get Ollama models"""
    if not ollama_service or not ollama_service.available:
        raise HTTPException(status_code=503, detail="Ollama service not available")
    
    models = ollama_service.list_models()
    return {"models": models, "count": len(models)}

@app.get("/documents/stats/")
def get_document_stats():
    """Get statistics about indexed documents"""
    try:
        chroma_count = chroma_db.get_document_count() if chroma_db else 0
        return {
            "total_indexed": chroma_count,
            "chroma_db_healthy": chroma_db.is_healthy() if chroma_db else False,
            "storage_location": "./chroma_db",
            "status": "ok"
        }
    except Exception as e:
        logger.error(f"Failed to get document stats: {e}")
        return {
            "total_indexed": 0,
            "chroma_db_healthy": False,
            "error": str(e)
        }

@app.post("/search/")
def search_documents(query: str, top_k: int = 3):
    """Search for relevant documents using semantic similarity"""
    try:
        if not chroma_db:
            raise HTTPException(status_code=503, detail="ChromaDB not available")
        
        results = chroma_db.search_documents(query, top_k=top_k)
        
        return {
            "query": query,
            "results_count": len(results),
            "results": [
                {"content": doc, "similarity": score}
                for doc, score in results
            ]
        }
    except Exception as e:
        logger.error(f"Search error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ==================== Input Validation Endpoint ====================

@app.post("/validate_input/")
def validate_input_query(req: ValidationInputRequest):
    """
    Validate if user query is policy-related using local SLM
    Returns validation status and determines if LLM should respond
    """
    try:
        # Try to use Ollama for validation, but if unavailable, use fallback
        if ollama_service and ollama_service.available:
            logger.info(f"Validating query with Ollama: {req.query}")
            validation_result = fallback_validate(req.query)
        else:
            # Fallback to simple keyword checking
            logger.warning("Ollama unavailable, using fallback validation")
            validation_result = fallback_validate(req.query)
        
        logger.info(f"Validation result: {validation_result}")
        return validation_result
        
    except Exception as e:
        logger.error(f"Validation error: {e}")
        # Fallback to permissive validation on error
        return fallback_validate(req.query)

def fallback_validate(query: str) -> dict:
    """Fallback validation using keyword matching"""
    greeting_keywords = ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening', 'thanks', 'thank you']
    policy_keywords = ['policy', 'coverage', 'deductible', 'premium', 'claim', 'exclusion', 'limit', 'insurance', 'benefit', 'document', 'upload']
    irrelevant_keywords = ['joke', 'funny', 'weather', 'sports', 'movie', 'recipe', 'coding', 'python', 'javascript', 'calculate', 'math']
    
    query_lower = query.lower().strip()
    
    # Check for irrelevant questions
    if any(keyword in query_lower for keyword in irrelevant_keywords):
        return {
            "valid": False,
            "category": "IRRELEVANT",
            "message": "I can only help with policy-related questions. Please ask something about your insurance coverage, deductibles, exclusions, or claims.",
            "confidence": 0.9
        }
    
    # Check for greetings (valid but no context needed)
    if any(keyword in query_lower for keyword in greeting_keywords):
        return {
            "valid": True,
            "category": "FLAVOUR_TEXT",
            "message": "",
            "confidence": 0.95
        }
    
    # Check for policy-related questions
    if any(keyword in query_lower for keyword in policy_keywords):
        return {
            "valid": True,
            "category": "CIVIC_RELEVANT",
            "message": "",
            "confidence": 0.85
        }
    
    # Default: allow but with lower confidence
    return {
        "valid": True,
        "category": "FOLLOW_UP",
        "message": "",
        "confidence": 0.5
    }

# ==================== Helpers ====================

def search_web_tool(query: str, max_results: int = 5) -> str:
    """Perform a web search using DuckDuckGo"""
    try:
        logger.info(f"🔎 Performing web search for: {query}")
        with DDGS() as ddgs:
            results = ddgs.text(query, max_results=max_results)
            if not results:
                return "No relevant information found on the internet."
            
            context = "Latest information from the internet:\n"
            for r in results:
                context += f"- Source: {r.get('title')}\n  Content: {r.get('body')}\n  Link: {r.get('href')}\n\n"
            return context
    except Exception as e:
        logger.error(f"Web search failed: {e}")
        return f"Error performing web search: {str(e)}"

# ==================== API Endpoints ====================

@app.post("/chat/")
def chat(req: ChatRequest):
    """Chat endpoint supporting both external LLM and local SLMs via Ollama"""
    try:
        if req.model == "deepseek":
            return chat_with_deepseek(
                req.message, 
                req.history, 
                req.temperature,
                rag_context=req.rag_context,
                documents=req.documents,
                use_internet=req.use_internet
            )
        
        # Ollama-based models
        elif req.model.startswith("ollama_"):
            model_name = req.model.replace("ollama_", "")
            return chat_with_ollama(req.message, model_name, req.temperature, req.history)
        
        # Legacy local SLM support
        elif req.model == "llama":
            response = llama_chat(req.message, req.history)
            return {"response": response, "model": "llama", "success": True}
        elif req.model == "gemma":
            response = gemma_chat(req.message, req.history)
            return {"response": response, "model": "gemma", "success": True}
        elif req.model == "qwen":
            response = qwen_chat(req.message, req.history)
            return {"response": response, "model": "qwen", "success": True}
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown model: {req.model}")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Chat error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/reason/")
def reason(req: ReasonRequest):
    """Reasoning endpoint"""
    try:
        if req.model == "deepseek":
            return reason_with_deepseek(req.task, req.context, req.temperature)
        
        elif req.model.startswith("ollama_"):
            model_name = req.model.replace("ollama_", "")
            return reason_with_ollama(req.task, model_name, req.context, req.temperature)
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown reasoning model: {req.model}")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Reasoning error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/embed/")
def embed(req: EmbedRequest):
    """Embedding endpoint"""
    try:
        if req.model == "openai":
            return embed_with_openai(req.text)
        elif req.model == "gte":
            embedding = gte_embed(req.text)
            return {"embedding": embedding, "model": "gte", "success": True}
        else:
            raise HTTPException(status_code=400, detail=f"Unknown embedding model: {req.model}")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Embedding error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ==================== Validation Endpoint (Ollama Pattern) ====================

@app.post("/validate/")
def validate_input(req: ValidationRequest):
    """
    Validate input using local SLM via Ollama
    Pattern: Similar to validation_service.py from reference project
    """
    if not ollama_service or not ollama_service.available:
        raise HTTPException(status_code=503, detail="Ollama service not available")
    
    try:
        result = ollama_service.validate(
            query=req.query,
            validation_rules=req.rules,
            model=req.model,
            temperature=req.temperature
        )
        return result
    except Exception as e:
        logger.error(f"Validation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ==================== Document Upload Endpoint ====================

UPLOAD_DIR = Path("./uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

@app.post("/upload")
async def upload_document(
    file: UploadFile = File(...),
    extracted_text: Optional[str] = Form(None)
):
    """Upload policy document for indexing - accepts PDF and TXT files"""
    try:
        if not file.filename:
            raise HTTPException(status_code=400, detail="No filename provided")
        
        allowed_extensions = ['.pdf', '.txt', '.png', '.jpg', '.jpeg']
        file_ext = Path(file.filename).suffix.lower()
        
        if file_ext not in allowed_extensions:
            raise HTTPException(status_code=400, detail=f"File type {file_ext} not allowed")
        
        file_size = 0
        file_path = UPLOAD_DIR / file.filename
        
        with open(file_path, "wb") as buffer:
            while True:
                chunk = await file.read(8192)
                if not chunk:
                    break
                file_size += len(chunk)
                if file_size > 50 * 1024 * 1024:
                    file_path.unlink()
                    raise HTTPException(status_code=413, detail="File too large (max 50MB)")
                buffer.write(chunk)
        
        logger.info(f"Document uploaded: {file.filename} ({file_size} bytes)")
        
        # Use provided extracted text (from frontend OCR) if available, otherwise extract from document
        if extracted_text:
            doc_content = extracted_text
            logger.info(f"Using provided extracted text for {file.filename}")
        else:
            doc_content = extract_text_from_document(str(file_path))
        
        if not doc_content:
            logger.warning(f"No text extracted from {file.filename}")
            return {
                "success": True,
                "message": f"Document '{file.filename}' uploaded but text extraction failed",
                "filename": file.filename,
                "size": file_size,
                "path": str(file_path),
                "indexed": False
            }
        
        # Index in ChromaDB
        indexed = False
        doc_id = Path(file.filename).stem  # Use filename without extension as ID
        if chroma_db:
            metadata = {
                "filename": file.filename,
                "file_type": file_ext.lstrip('.'),
                "size_bytes": file_size,
                "source": "uploaded"
            }
            
            indexed = chroma_db.add_document(doc_id, doc_content, metadata)
            
            if indexed:
                logger.info(f"✓ Document indexed in ChromaDB: {doc_id}")
                indexed_count = chroma_db.get_document_count()
                logger.info(f"  Total indexed documents: {indexed_count}")
        
        return {
            "success": True,
            "message": f"Document '{file.filename}' uploaded and indexed successfully",
            "filename": file.filename,
            "doc_id": doc_id,
            "size": file_size,
            "path": str(file_path),
            "indexed": indexed,
            "content_length": len(doc_content),
            "total_indexed": chroma_db.get_document_count() if chroma_db else 0
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Upload error: {e}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

@app.delete("/documents/{doc_id}")
async def delete_document(doc_id: str):
    """Delete a document from ChromaDB and filesystem"""
    try:
        logger.info(f"Delete request for document: {doc_id}")
        
        # Delete from ChromaDB
        deleted_from_chroma = False
        if chroma_db:
            deleted_from_chroma = chroma_db.delete_document(doc_id)
            if deleted_from_chroma:
                logger.info(f"✓ Document deleted from ChromaDB: {doc_id}")
        
        # Try to delete file from filesystem
        deleted_from_filesystem = False
        try:
            file_path = UPLOAD_DIR / f"{doc_id}.pdf"
            if not file_path.exists():
                file_path = UPLOAD_DIR / f"{doc_id}.txt"
            
            if file_path.exists():
                file_path.unlink()
                deleted_from_filesystem = True
                logger.info(f"✓ Document deleted from filesystem: {file_path}")
        except Exception as fs_error:
            logger.warning(f"Could not delete file from filesystem: {fs_error}")
        
        # Return updated document count
        remaining_count = chroma_db.get_document_count() if chroma_db else 0
        
        return {
            "success": deleted_from_chroma or deleted_from_filesystem,
            "message": f"Document '{doc_id}' deleted successfully",
            "doc_id": doc_id,
            "deleted_from_chroma": deleted_from_chroma,
            "deleted_from_filesystem": deleted_from_filesystem,
            "total_indexed": remaining_count
        }
    
    except Exception as e:
        logger.error(f"Delete error: {e}")
        return {
            "success": False,
            "message": f"Failed to delete document: {str(e)}",
            "doc_id": doc_id,
            "total_indexed": chroma_db.get_document_count() if chroma_db else 0
        }

# ==================== Model Integration Functions ====================

def chat_with_deepseek(
    message: str, 
    history: Optional[List[dict]] = None, 
    temperature: float = 0.7, 
    rag_context: Optional[str] = None, 
    documents: Optional[List[dict]] = None,
    use_internet: bool = False
) -> dict:
    """Chat with Azure DeepSeek model using LangChain with RAG context"""
    try:
        if llm is None:
            return {"response": "LLM not initialized. Please check your API keys and connection.", "model": "deepseek", "error": True}
        
        # 1. Fetch Internet Content if requested
        web_context = ""
        if use_internet:
            web_context = search_web_tool(message)
        
        # 2. Build RAG context from ChromaDB if available
        rag_docs = []
        used_chroma = False
        
        if chroma_db and chroma_db.is_healthy():
            # Search for relevant documents in ChromaDB
            search_results = chroma_db.search_documents(message, top_k=3)
            if search_results:
                rag_docs = [
                    f"[Document: {content[:500]}...]" 
                    for content, score in search_results
                ]
                used_chroma = True
        
        # 3. Construct the enhanced prompt
        # We combine Document Context (RAG) and Web Context for the LLM
        prompt_sections = []
        
        if rag_docs or rag_context or documents:
            docs_txt = "\n".join(rag_docs) if rag_docs else (rag_context or "the provided documents")
            prompt_sections.append(f"### INTERNAL POLICY DOCUMENTS (RAG):\n{docs_txt}")
            
        if web_context:
            prompt_sections.append(f"### LATEST INTERNET SEARCH RESULTS:\n{web_context}")

        if not prompt_sections:
            enhanced_message = message
        else:
            context_payload = "\n\n".join(prompt_sections)
            enhanced_message = f"""You are an Insurance Policy Assistant with access to both private policy documents AND the real-time internet.

{context_payload}

MISSION:
Answer the user's question by synthesizing both internal documents and the latest internet info.
- If information from both sources conflicts, prioritize the INTERNAL POLICY DOCUMENTS for specific policy rules, but mention relevant internet findings if they provide broader context (like new regulations).
- If the question isn't covered in the documents, rely on the INTERNET results.
- If neither has the answer, state that clearly.

User Question: {message}"""

        # 4. Invoke LLM and return result
        response = llm.invoke(enhanced_message)
        
        return {
            "response": response.content,
            "model": "deepseek",
            "success": True,
            "used_rag": bool(rag_docs or rag_context or documents),
            "used_internet": bool(web_context),
            "rag_source": "chroma_db" if used_chroma else ("provided_context" if (rag_context or documents) else "none"),
            "documents_referenced": len(rag_docs) if rag_docs else 0
        }
    except Exception as e:
        logger.error(f"DeepSeek chat error: {e}")
        return {"response": f"Error: {str(e)}", "model": "deepseek", "error": True}

def chat_with_ollama(message: str, model: str, temperature: float = 0.7, history: Optional[List[dict]] = None) -> dict:
    """Chat with Ollama-based local SLM (pattern from validation_service.py)"""
    try:
        if not ollama_service or not ollama_service.available:
            return {"response": "Ollama service not available", "model": model, "error": True}
        
        response = ollama_service.chat(
            prompt=message,
            model=model,
            temperature=temperature,
            max_tokens=256,
            history=history
        )
        
        return {
            "response": response,
            "model": model,
            "success": True
        }
    except Exception as e:
        logger.error(f"Ollama chat error: {e}")
        return {"response": f"Error: {str(e)}", "model": model, "error": True}

def reason_with_deepseek(task: str, context: Optional[str] = None, temperature: float = 0.5) -> dict:
    """Reasoning with DeepSeek model using LangChain"""
    try:
        if llm is None:
            return {"response": "LLM not initialized", "model": "deepseek", "error": True}
        
        prompt = f"Task: {task}"
        if context:
            prompt += f"\n\nContext: {context}"
        
        response = llm.invoke(prompt)
        
        return {
            "response": response.content,
            "model": "deepseek",
            "success": True
        }
    except Exception as e:
        logger.error(f"DeepSeek reasoning error: {e}")
        return {"response": f"Error: {str(e)}", "model": "deepseek", "error": True}

def reason_with_ollama(task: str, model: str, context: Optional[str] = None, temperature: float = 0.5) -> dict:
    """Reasoning with Ollama-based local SLM"""
    try:
        if not ollama_service or not ollama_service.available:
            return {"response": "Ollama service not available", "model": model, "error": True}
        
        response = ollama_service.reason(
            task=task,
            context=context,
            model=model,
            temperature=temperature,
            max_tokens=512
        )
        
        return {
            "response": response,
            "model": model,
            "success": True
        }
    except Exception as e:
        logger.error(f"Ollama reasoning error: {e}")
        return {"response": f"Error: {str(e)}", "model": model, "error": True}

def embed_with_openai(text: str) -> dict:
    """Embedding with Azure OpenAI using LangChain"""
    try:
        if embedding_model is None:
            return {"embedding": [], "model": "openai", "error": True, "message": "Embedding model not initialized"}
        
        embedding = embedding_model.embed_query(text)
        
        return {
            "embedding": embedding,
            "model": "openai",
            "success": True
        }
    except Exception as e:
        logger.error(f"OpenAI embedding error: {e}")
        return {"embedding": [], "model": "openai", "error": True, "message": str(e)}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
