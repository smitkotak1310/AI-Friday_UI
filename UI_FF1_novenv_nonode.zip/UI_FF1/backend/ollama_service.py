# filepath: c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend\ollama_service.py
"""
Ollama Service - Local SLM Integration using Ollama
Pattern: Similar to validation_service.py from the reference project
Uses Ollama Client to interact with locally running SLMs
"""

import logging
from typing import Optional, List, Dict
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# Try to import Ollama client
try:
    from ollama import Client
    OLLAMA_AVAILABLE = True
    logger.info("✓ Ollama client imported successfully")
except ImportError:
    OLLAMA_AVAILABLE = False
    logger.warning("⚠ Ollama not installed. Install with: pip install ollama")


class OllamaResponse(BaseModel):
    """Response model from Ollama"""
    response: str
    model: str
    created_at: Optional[str] = None
    done: bool = True


class OllamaService:
    """
    Service for interacting with locally running SLMs via Ollama
    
    Usage:
        service = OllamaService()
        response = service.chat("Hello", model="llama2")
    """
    
    def __init__(self, host: str = "http://localhost:11434"):
        """
        Initialize Ollama service
        
        Args:
            host: Ollama server URL (default: localhost:11434)
        """
        self.host = host
        self.available = OLLAMA_AVAILABLE
        
        if self.available:
            try:
                self.client = Client(host=host)
                logger.info(f"✓ Ollama service initialized at {host}")
            except Exception as e:
                logger.error(f"✗ Failed to connect to Ollama: {e}")
                self.available = False
                self.client = None
        else:
            self.client = None
    
    def chat(
        self, 
        prompt: str, 
        model: str = "llama2",
        temperature: float = 0.7,
        max_tokens: int = 256,
        history: Optional[List[Dict]] = None,
        stream: bool = False
    ) -> str:
        """
        Generate chat response using Ollama
        
        Args:
            prompt: User message
            model: Model name (llama2, neural-chat, mistral, etc.)
            temperature: Response creativity (0.0-1.0)
            max_tokens: Maximum response length
            history: Chat history for context
            stream: Enable streaming response
            
        Returns:
            Generated response text
        """
        if not self.available or self.client is None:
            return "[Ollama service not available]"
        
        try:
            # Build full prompt with history if provided
            full_prompt = self._build_prompt(prompt, history)
            
            logger.info(f"Generating response with {model}...")
            
            response = self.client.generate(
                model=model,
                prompt=full_prompt,
                stream=stream,
                options={
                    "temperature": temperature,
                    "num_predict": max_tokens,
                    "top_k": 40,
                    "top_p": 0.9,
                }
            )
            
            # Extract response text
            if isinstance(response, dict):
                result = response.get("response", "")
            else:
                result = response
            
            logger.info(f"✓ Response generated successfully ({len(result)} chars)")
            return result.strip()
            
        except Exception as e:
            logger.error(f"✗ Chat error: {e}")
            return f"[Error: {str(e)}]"
    
    def validate(
        self,
        query: str,
        validation_rules: str,
        model: str = "llama2",
        temperature: float = 0.3,
        max_tokens: int = 120
    ) -> Dict:
        """
        Validate input using Ollama (similar to validation_service.py pattern)
        
        Args:
            query: User input to validate
            validation_rules: Rules to apply for validation
            model: Model to use
            temperature: Lower temperature for validation (more deterministic)
            max_tokens: Max response length
            
        Returns:
            Validation result dictionary
        """
        if not self.available or self.client is None:
            return {
                "valid": False,
                "category": "ERROR",
                "message": "Ollama service not available"
            }
        
        try:
            prompt = f"""
{validation_rules}

User input: {query}

Respond with a JSON object containing:
- valid: boolean
- category: string
- message: string (if invalid)
"""
            
            response = self.client.generate(
                model=model,
                prompt=prompt,
                stream=False,
                options={
                    "temperature": temperature,
                    "num_predict": max_tokens
                }
            )
            
            response_text = response.get("response", "") if isinstance(response, dict) else response
            
            # Parse JSON response
            import json
            try:
                result = json.loads(response_text)
            except json.JSONDecodeError:
                # Attempt recovery by extracting JSON
                import re
                json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
                if json_match:
                    result = json.loads(json_match.group())
                else:
                    result = {
                        "valid": False,
                        "category": "PARSE_ERROR",
                        "message": "Could not parse validation response"
                    }
            
            return result
            
        except Exception as e:
            logger.error(f"✗ Validation error: {e}")
            return {
                "valid": False,
                "category": "ERROR",
                "message": str(e)
            }
    
    def reason(
        self,
        task: str,
        context: Optional[str] = None,
        model: str = "neural-chat",
        temperature: float = 0.5,
        max_tokens: int = 512
    ) -> str:
        """
        Complex reasoning using Ollama
        
        Args:
            task: Reasoning task
            context: Additional context
            model: Model to use (prefer neural-chat or mistral for reasoning)
            temperature: Creativity level
            max_tokens: Max response length
            
        Returns:
            Reasoning result
        """
        if not self.available or self.client is None:
            return "[Ollama service not available]"
        
        try:
            prompt = f"Task: {task}"
            if context:
                prompt += f"\n\nContext: {context}"
            
            response = self.client.generate(
                model=model,
                prompt=prompt,
                stream=False,
                options={
                    "temperature": temperature,
                    "num_predict": max_tokens,
                }
            )
            
            result = response.get("response", "") if isinstance(response, dict) else response
            logger.info(f"✓ Reasoning completed")
            return result.strip()
            
        except Exception as e:
            logger.error(f"✗ Reasoning error: {e}")
            return f"[Error: {str(e)}]"
    
    def list_models(self) -> List[str]:
        """
        List available models in Ollama
        
        Returns:
            List of available model names
        """
        if not self.available or self.client is None:
            return []
        
        try:
            models = self.client.list()
            return [m.get("name", "") for m in models.get("models", [])]
        except Exception as e:
            logger.error(f"✗ Failed to list models: {e}")
            return []
    
    def pull_model(self, model_name: str) -> bool:
        """
        Download a model from Ollama registry
        
        Args:
            model_name: Model to download (e.g., "llama2", "mistral")
            
        Returns:
            True if successful
        """
        if not self.available or self.client is None:
            logger.error("Ollama not available")
            return False
        
        try:
            logger.info(f"Pulling model: {model_name}...")
            self.client.pull(model_name)
            logger.info(f"✓ Model {model_name} pulled successfully")
            return True
        except Exception as e:
            logger.error(f"✗ Failed to pull model {model_name}: {e}")
            return False
    
    def stream_response(
        self,
        prompt: str,
        model: str = "llama2",
        temperature: float = 0.7
    ):
        """
        Stream response token by token (for real-time UI updates)
        
        Args:
            prompt: User message
            model: Model to use
            temperature: Creativity level
            
        Yields:
            Token strings as they're generated
        """
        if not self.available or self.client is None:
            yield "[Ollama service not available]"
            return
        
        try:
            response = self.client.generate(
                model=model,
                prompt=prompt,
                stream=True,
                options={
                    "temperature": temperature,
                }
            )
            
            for chunk in response:
                if isinstance(chunk, dict) and "response" in chunk:
                    yield chunk["response"]
                    
        except Exception as e:
            logger.error(f"✗ Streaming error: {e}")
            yield f"[Error: {str(e)}]"
    
    def _build_prompt(self, prompt: str, history: Optional[List[Dict]] = None) -> str:
        """
        Build full prompt with conversation history
        
        Args:
            prompt: Current user message
            history: Previous messages
            
        Returns:
            Full prompt string
        """
        if not history:
            return prompt
        
        full_prompt = ""
        for msg in history:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            full_prompt += f"{role}: {content}\n"
        
        full_prompt += f"user: {prompt}"
        return full_prompt
    
    def health_check(self) -> Dict:
        """
        Check if Ollama service is healthy
        
        Returns:
            Health status dictionary
        """
        if not self.available:
            return {"status": "unavailable", "message": "Ollama not installed"}
        
        if self.client is None:
            return {"status": "disconnected", "message": "Cannot connect to Ollama"}
        
        try:
            models = self.list_models()
            return {
                "status": "healthy",
                "available_models": models,
                "model_count": len(models)
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}


# Initialize global Ollama service
ollama_service = OllamaService() if OLLAMA_AVAILABLE else None
