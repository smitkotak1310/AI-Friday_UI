"""
Document Text Extraction Module
Handles extracting text from PDF and TXT files
"""

import logging
from pathlib import Path
from typing import Optional, Tuple
from pypdf import PdfReader

logger = logging.getLogger(__name__)

def extract_text_from_pdf(file_path: str) -> Optional[str]:
    """
    Extract text content from PDF file
    
    Args:
        file_path: Path to PDF file
    
    Returns:
        Extracted text or None on error
    """
    try:
        file_path = Path(file_path)
        
        if not file_path.exists():
            logger.error(f"PDF file not found: {file_path}")
            return None
        
        reader = PdfReader(file_path)
        text = ""
        
        for page_num, page in enumerate(reader.pages):
            try:
                text += page.extract_text()
            except Exception as e:
                logger.warning(f"Failed to extract text from page {page_num + 1}: {e}")
                continue
        
        if not text.strip():
            logger.warning(f"No text extracted from PDF: {file_path}")
            return None
        
        logger.info(f"✓ PDF text extracted: {file_path}")
        logger.info(f"  Pages: {len(reader.pages)}, Text length: {len(text)} characters")
        
        return text
        
    except Exception as e:
        logger.error(f"Failed to extract text from PDF {file_path}: {e}")
        return None

def extract_text_from_txt(file_path: str) -> Optional[str]:
    """
    Extract text content from TXT file
    
    Args:
        file_path: Path to TXT file
    
    Returns:
        File content or None on error
    """
    try:
        file_path = Path(file_path)
        
        if not file_path.exists():
            logger.error(f"TXT file not found: {file_path}")
            return None
        
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            text = f.read()
        
        if not text.strip():
            logger.warning(f"Empty TXT file: {file_path}")
            return None
        
        logger.info(f"✓ TXT text extracted: {file_path}")
        logger.info(f"  Text length: {len(text)} characters")
        
        return text
        
    except Exception as e:
        logger.error(f"Failed to read TXT file {file_path}: {e}")
        return None

def extract_text_from_document(file_path: str) -> Optional[str]:
    """
    Extract text from any supported document type
    
    Args:
        file_path: Path to document file
    
    Returns:
        Extracted text or None on error
    """
    file_path = Path(file_path)
    file_ext = file_path.suffix.lower()
    
    if file_ext == '.pdf':
        return extract_text_from_pdf(file_path)
    elif file_ext == '.txt':
        return extract_text_from_txt(file_path)
    elif file_ext in ['.png', '.jpg', '.jpeg']:
        logger.info(f"Image file detected: {file_ext}. OCR should be provided by frontend.")
        return None
    else:
        logger.error(f"Unsupported file type: {file_ext}")
        return None

def get_file_info(file_path: str) -> Tuple[str, int, str]:
    """
    Get file information
    
    Args:
        file_path: Path to file
    
    Returns:
        Tuple of (filename, file_size_bytes, file_type)
    """
    try:
        file_path = Path(file_path)
        file_size = file_path.stat().st_size
        file_type = file_path.suffix.lower().lstrip('.')
        filename = file_path.name
        
        return filename, file_size, file_type
    except Exception as e:
        logger.error(f"Failed to get file info: {e}")
        return "", 0, ""
