import requests

# Test the upload endpoint
file_path = r"c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend\test_document.txt"

with open(file_path, 'rb') as f:
    files = {'file': f}
    response = requests.post('http://localhost:8000/upload', files=files)
    
print("Status:", response.status_code)
print("Response:", response.json())
