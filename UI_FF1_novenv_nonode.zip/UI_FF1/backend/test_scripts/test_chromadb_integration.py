"""
Test ChromaDB Integration End-to-End
Tests: Upload → Index → Search → RAG Chat → Dashboard Stats
"""

import requests
import json
import time
from pathlib import Path

BASE_URL = "http://localhost:8000"

def test_health_check():
    """Test health endpoint includes ChromaDB status"""
    print("\n=== TEST 1: Health Check ===")
    response = requests.get(f"{BASE_URL}/health/")
    health = response.json()
    print(json.dumps(health, indent=2))
    
    assert health.get("status") == "ok", "Health status not ok"
    assert "chroma_db" in health, "ChromaDB not in health response"
    print("✅ Health check passed - ChromaDB status included")
    return health

def test_document_stats():
    """Test document statistics endpoint"""
    print("\n=== TEST 2: Document Statistics ===")
    response = requests.get(f"{BASE_URL}/documents/stats/")
    stats = response.json()
    print(json.dumps(stats, indent=2))
    
    assert stats.get("status") == "ok", "Stats status not ok"
    assert "total_indexed" in stats, "total_indexed not in response"
    print(f"✅ Current indexed documents: {stats['total_indexed']}")
    return stats

def test_upload_document():
    """Test document upload and indexing"""
    print("\n=== TEST 3: Upload Document ===")
    
    # Create a test document if it doesn't exist
    test_file = Path("test_policy.txt")
    if not test_file.exists():
        test_content = """
        INSURANCE POLICY DOCUMENT
        
        Coverage Details:
        - Deductible: $500 for all claims
        - Coverage Limit: $100,000 per incident
        - Premium: $50/month
        
        Covered Events:
        1. Accidental damage
        2. Theft
        3. Fire and smoke
        4. Water damage (sudden)
        
        Exclusions:
        - Gradual wear and tear
        - Intentional damage
        - War and civil unrest
        
        Claims Process:
        1. Report within 30 days
        2. Provide documentation
        3. Adjuster inspection
        4. Claim approval/denial
        5. Payment processing
        """
        test_file.write_text(test_content)
        print(f"Created test file: {test_file}")
    
    # Upload the file
    with open(test_file, "rb") as f:
        files = {"file": f}
        response = requests.post(f"{BASE_URL}/upload", files=files)
    
    upload_result = response.json()
    print(json.dumps(upload_result, indent=2))
    
    assert upload_result.get("success"), "Upload failed"
    assert upload_result.get("indexed"), "Document not indexed"
    print(f"✅ Document uploaded and indexed successfully")
    print(f"   Content length: {upload_result.get('content_length')} characters")
    print(f"   Total indexed: {upload_result.get('total_indexed')} documents")
    
    return upload_result

def test_search_documents():
    """Test semantic search"""
    print("\n=== TEST 4: Semantic Search ===")
    
    query = "deductible"
    response = requests.post(
        f"{BASE_URL}/search/?query={query}&top_k=3"
    )
    
    search_result = response.json()
    print(f"Query: {query}")
    print(f"Results found: {search_result.get('results_count')}")
    
    if search_result.get('results'):
        for i, result in enumerate(search_result['results'], 1):
            print(f"\nResult {i} (Similarity: {result['similarity']:.2%}):")
            print(result['content'][:200] + "...")
    
    assert search_result.get("results_count", 0) > 0, "No search results"
    print(f"✅ Semantic search working - found relevant documents")
    return search_result

def test_chat_with_rag():
    """Test chat endpoint with RAG context"""
    print("\n=== TEST 5: Chat with RAG Context ===")
    
    question = "What is my deductible?"
    response = requests.post(
        f"{BASE_URL}/chat/",
        json={
            "message": question,
            "model": "deepseek"
        }
    )
    
    chat_result = response.json()
    print(f"Question: {question}")
    print(f"\nUsed RAG: {chat_result.get('used_rag')}")
    print(f"RAG Source: {chat_result.get('rag_source')}")
    print(f"Documents Referenced: {chat_result.get('documents_referenced')}")
    print(f"\nResponse:")
    print(chat_result.get('response', 'No response')[:500])
    
    assert chat_result.get("success"), "Chat failed"
    assert chat_result.get("used_rag"), "RAG context not used"
    print(f"\n✅ Chat with RAG context working")
    return chat_result

def test_dashboard_stats_update():
    """Test that dashboard stats update from ChromaDB"""
    print("\n=== TEST 6: Dashboard Stats Update ===")
    
    # Get stats before
    response_before = requests.get(f"{BASE_URL}/documents/stats/")
    stats_before = response_before.json()
    count_before = stats_before.get('total_indexed', 0)
    print(f"Documents indexed BEFORE: {count_before}")
    
    # Upload another document
    test_file2 = Path("test_policy_2.txt")
    test_file2.write_text("ADDITIONAL POLICY: Covers medical expenses up to $50,000")
    
    with open(test_file2, "rb") as f:
        files = {"file": f}
        requests.post(f"{BASE_URL}/upload", files=files)
    
    time.sleep(1)
    
    # Get stats after
    response_after = requests.get(f"{BASE_URL}/documents/stats/")
    stats_after = response_after.json()
    count_after = stats_after.get('total_indexed', 0)
    print(f"Documents indexed AFTER: {count_after}")
    
    assert count_after > count_before, "Document count did not increase"
    print(f"✅ Dashboard stats updated from ChromaDB (+{count_after - count_before} documents)")
    return stats_after

def run_all_tests():
    """Run all tests in sequence"""
    print("\n" + "="*60)
    print("CHROMADB INTEGRATION - COMPREHENSIVE TEST SUITE")
    print("="*60)
    
    try:
        # Run all tests
        health = test_health_check()
        test_document_stats()
        upload = test_upload_document()
        search = test_search_documents()
        chat = test_chat_with_rag()
        final_stats = test_dashboard_stats_update()
        
        # Summary
        print("\n" + "="*60)
        print("✅ ALL TESTS PASSED!")
        print("="*60)
        print("\nSummary:")
        print(f"  • Health Check: PASSED (ChromaDB: {health.get('chroma_db')})")
        print(f"  • Upload & Index: PASSED ({upload.get('total_indexed')} docs indexed)")
        print(f"  • Semantic Search: PASSED")
        print(f"  • RAG Chat: PASSED (documents_referenced: {chat.get('documents_referenced')})")
        print(f"  • Dashboard Stats: PASSED (live count: {final_stats.get('total_indexed')})")
        print("\n🎉 ChromaDB integration fully functional!")
        print("\nNext: Open browser → http://localhost:5173")
        print("      Go to Dashboard tab to see live stats")
        
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        return False
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        return False
    
    return True

if __name__ == "__main__":
    run_all_tests()
