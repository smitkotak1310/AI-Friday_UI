"""
Test document upload and deletion synchronization
Verifies that:
1. Uploaded documents are properly indexed in ChromaDB
2. Document count reflects actual indexed documents
3. Deleting documents removes them from ChromaDB
4. Dashboard stats are always in sync with ChromaDB
"""

import requests
import json
import time
from pathlib import Path

API_BASE_URL = "http://localhost:8000"

def test_document_count_sync():
    """Test that document count is always in sync with ChromaDB"""
    print("\n" + "="*60)
    print("TEST 1: Document Count Synchronization")
    print("="*60)
    
    try:
        # Get initial count
        response = requests.get(f"{API_BASE_URL}/documents/stats/")
        initial_count = response.json()['total_indexed']
        print(f"✓ Initial document count from ChromaDB: {initial_count}")
        
        # Check health
        response = requests.get(f"{API_BASE_URL}/health/")
        health = response.json()
        chroma_healthy = health['chroma_db'] == 'healthy'
        print(f"✓ ChromaDB health: {health['chroma_db']}")
        
        return chroma_healthy
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_upload_and_verify():
    """Test uploading a document and verifying it appears in count"""
    print("\n" + "="*60)
    print("TEST 2: Upload Document and Verify Count Update")
    print("="*60)
    
    try:
        # Create a test document
        test_file = Path("./test_sync_doc.txt")
        test_content = "This is a test document for synchronization testing. It contains policy information about deductibles and coverage."
        test_file.write_text(test_content)
        
        # Get count before upload
        response = requests.get(f"{API_BASE_URL}/documents/stats/")
        before_count = response.json()['total_indexed']
        print(f"✓ Count before upload: {before_count}")
        
        # Upload file
        with open(test_file, 'rb') as f:
            files = {'file': f}
            response = requests.post(f"{API_BASE_URL}/upload", files=files)
        
        if response.status_code != 200:
            print(f"✗ Upload failed: {response.status_code}")
            print(response.json())
            return False
        
        upload_result = response.json()
        print(f"✓ Upload successful")
        print(f"  - Filename: {upload_result['filename']}")
        print(f"  - Doc ID: {upload_result.get('doc_id', 'N/A')}")
        print(f"  - Indexed: {upload_result['indexed']}")
        print(f"  - Total after upload (from response): {upload_result['total_indexed']}")
        
        # Wait a moment for indexing
        time.sleep(1)
        
        # Get count after upload
        response = requests.get(f"{API_BASE_URL}/documents/stats/")
        after_count = response.json()['total_indexed']
        print(f"✓ Count after upload: {after_count}")
        
        # Verify count increased
        if after_count > before_count:
            print(f"✅ PASS: Document count increased from {before_count} to {after_count}")
            test_file.unlink()
            return upload_result.get('doc_id', 'test_sync_doc')
        else:
            print(f"❌ FAIL: Document count did not increase")
            test_file.unlink()
            return False
    
    except Exception as e:
        print(f"✗ Error: {e}")
        if test_file.exists():
            test_file.unlink()
        return False


def test_delete_and_verify(doc_id):
    """Test deleting a document and verifying count decreases"""
    print("\n" + "="*60)
    print("TEST 3: Delete Document and Verify Count Update")
    print("="*60)
    
    if not doc_id or doc_id is False:
        print("✗ Skipping - no valid doc_id from upload test")
        return False
    
    try:
        # Get count before delete
        response = requests.get(f"{API_BASE_URL}/documents/stats/")
        before_count = response.json()['total_indexed']
        print(f"✓ Count before delete: {before_count}")
        
        # Delete document
        response = requests.delete(f"{API_BASE_URL}/documents/{doc_id}")
        
        if response.status_code != 200:
            print(f"✗ Delete request failed: {response.status_code}")
            return False
        
        delete_result = response.json()
        print(f"✓ Delete request successful")
        print(f"  - Doc ID: {delete_result['doc_id']}")
        print(f"  - Deleted from ChromaDB: {delete_result['deleted_from_chroma']}")
        print(f"  - Deleted from filesystem: {delete_result['deleted_from_filesystem']}")
        print(f"  - Total after delete (from response): {delete_result['total_indexed']}")
        
        # Wait a moment
        time.sleep(1)
        
        # Get count after delete
        response = requests.get(f"{API_BASE_URL}/documents/stats/")
        after_count = response.json()['total_indexed']
        print(f"✓ Count after delete: {after_count}")
        
        # Verify count decreased
        if after_count < before_count:
            print(f"✅ PASS: Document count decreased from {before_count} to {after_count}")
            return True
        else:
            print(f"❌ FAIL: Document count did not decrease")
            return False
    
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_dashboard_sync():
    """Test that dashboard stats endpoint returns correct values"""
    print("\n" + "="*60)
    print("TEST 4: Dashboard Stats Synchronization")
    print("="*60)
    
    try:
        # Get stats
        response = requests.get(f"{API_BASE_URL}/documents/stats/")
        stats = response.json()
        
        print(f"✓ Dashboard stats fetched")
        print(f"  - Total indexed: {stats['total_indexed']}")
        print(f"  - ChromaDB healthy: {stats['chroma_db_healthy']}")
        print(f"  - Storage location: {stats['storage_location']}")
        
        # Get health
        response = requests.get(f"{API_BASE_URL}/health/")
        health = response.json()
        
        # Compare counts
        health_indexed = health.get('indexed_documents', -1)
        stats_indexed = stats.get('total_indexed', -1)
        
        print(f"\n✓ Health endpoint indexed documents: {health_indexed}")
        print(f"✓ Stats endpoint indexed documents: {stats_indexed}")
        
        if health_indexed == stats_indexed:
            print(f"✅ PASS: Both endpoints report same count ({stats_indexed})")
            return True
        else:
            print(f"⚠️  WARNING: Endpoints report different counts")
            print(f"   Health: {health_indexed}, Stats: {stats_indexed}")
            return stats_indexed >= 0  # Pass if stats endpoint works
    
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def main():
    """Run all tests"""
    print("\n" + "#"*60)
    print("# DOCUMENT SYNCHRONIZATION TEST SUITE")
    print("#"*60)
    
    results = []
    
    # Test 1: Initial sync check
    results.append(("Initial Sync Check", test_document_count_sync()))
    
    # Test 2: Upload and verify
    doc_id = test_upload_and_verify()
    results.append(("Upload & Count Update", doc_id is not False))
    
    # Test 3: Delete and verify
    if doc_id and doc_id is not False:
        results.append(("Delete & Count Update", test_delete_and_verify(doc_id)))
    else:
        results.append(("Delete & Count Update", False))
    
    # Test 4: Dashboard sync
    results.append(("Dashboard Sync", test_dashboard_sync()))
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED!")
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
    
    return passed == total


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
