"""
Comprehensive Integration Test Suite
Tests: UI <-> Backend Integration with LLM (DeepSeek), Embeddings, and Ollama SLM
"""

import requests
import json
import sys
import time
from typing import Dict, Any, List
import subprocess
import os

# Test Configuration
API_BASE_URL = "http://localhost:8000"
HEALTH_ENDPOINT = f"{API_BASE_URL}/health/"
MODELS_ENDPOINT = f"{API_BASE_URL}/models/"
CHAT_ENDPOINT = f"{API_BASE_URL}/chat/"
REASON_ENDPOINT = f"{API_BASE_URL}/reason/"
EMBED_ENDPOINT = f"{API_BASE_URL}/embed/"
VALIDATE_ENDPOINT = f"{API_BASE_URL}/validate/"

# Color codes for terminal output
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_header(text: str):
    """Print colored header"""
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{text}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.RESET}\n")

def print_success(text: str):
    """Print success message"""
    print(f"{Colors.GREEN}✓ {text}{Colors.RESET}")

def print_error(text: str):
    """Print error message"""
    print(f"{Colors.RED}✗ {text}{Colors.RESET}")

def print_warning(text: str):
    """Print warning message"""
    print(f"{Colors.YELLOW}⚠ {text}{Colors.RESET}")

def print_info(text: str):
    """Print info message"""
    print(f"{Colors.BLUE}ℹ {text}{Colors.RESET}")

class IntegrationTester:
    def __init__(self):
        self.results: Dict[str, Dict[str, Any]] = {}
        self.total_tests = 0
        self.passed_tests = 0
        self.failed_tests = 0

    def log_result(self, test_name: str, status: bool, details: str = ""):
        """Log test result"""
        self.total_tests += 1
        if status:
            self.passed_tests += 1
            self.results[test_name] = {"status": "PASS", "details": details}
            print_success(f"{test_name}: {details}")
        else:
            self.failed_tests += 1
            self.results[test_name] = {"status": "FAIL", "details": details}
            print_error(f"{test_name}: {details}")

    def test_backend_connectivity(self) -> bool:
        """Test 1: Backend Server Connectivity"""
        print_header("TEST 1: Backend Server Connectivity")
        try:
            response = requests.get(API_BASE_URL, timeout=5)
            self.log_result(
                "Backend Available",
                response.status_code < 500,
                f"Server is running (any status < 500)"
            )
            return True
        except requests.exceptions.ConnectionError:
            self.log_result(
                "Backend Available",
                False,
                f"Failed to connect to {API_BASE_URL}. Is FastAPI running?"
            )
            return False
        except Exception as e:
            self.log_result("Backend Available", False, str(e))
            return False

    def test_health_endpoint(self) -> bool:
        """Test 2: Health Check Endpoint"""
        print_header("TEST 2: Health Check Endpoint")
        try:
            response = requests.get(HEALTH_ENDPOINT, timeout=10)
            if response.status_code != 200:
                self.log_result("Health Endpoint", False, f"Status: {response.status_code}")
                return False
            
            data = response.json()
            self.log_result("Health Endpoint Status", True, json.dumps(data, indent=2))
            
            # Check individual components
            print_info(f"External LLM (DeepSeek): {data.get('external_llm', 'unknown')}")
            print_info(f"Ollama Service: {data.get('ollama_service', 'unknown')}")
            print_info(f"Embeddings: {data.get('embeddings', 'unknown')}")
            
            return data.get('status') == 'ok'
        except Exception as e:
            self.log_result("Health Endpoint", False, str(e))
            return False

    def test_models_endpoint(self) -> bool:
        """Test 3: Models Listing Endpoint"""
        print_header("TEST 3: Models Listing Endpoint")
        try:
            response = requests.get(MODELS_ENDPOINT, timeout=10)
            if response.status_code != 200:
                self.log_result("Models Endpoint", False, f"Status: {response.status_code}")
                return False
            
            data = response.json()
            self.log_result("Models Endpoint Status", True, "Endpoint accessible")
            
            print_info(f"Available LLM Models: {data.get('llm_models', [])}")
            print_info(f"Available SLM Models: {data.get('slm_models', [])}")
            print_info(f"Available Embedding Models: {data.get('embedding_models', [])}")
            print_info(f"Ollama Status: {data.get('ollama_status', 'unknown')}")
            
            return True
        except Exception as e:
            self.log_result("Models Endpoint", False, str(e))
            return False

    def test_deepseek_llm(self) -> bool:
        """Test 4: DeepSeek LLM Chat"""
        print_header("TEST 4: DeepSeek LLM Chat")
        try:
            payload = {
                "message": "Hello! What is your name?",
                "model": "deepseek",
                "temperature": 0.7
            }
            
            response = requests.post(CHAT_ENDPOINT, json=payload, timeout=30)
            
            if response.status_code != 200:
                self.log_result(
                    "DeepSeek Chat",
                    False,
                    f"Status: {response.status_code}, Response: {response.text[:200]}"
                )
                return False
            
            data = response.json()
            
            if data.get('error'):
                print_warning(f"DeepSeek returned error: {data.get('response')}")
                self.log_result("DeepSeek Chat", False, "API returned error response")
                return False
            
            response_text = data.get('response', '')
            self.log_result(
                "DeepSeek Chat",
                True,
                f"Response received ({len(response_text)} chars)"
            )
            print_info(f"Response: {response_text[:150]}...")
            
            return True
        except requests.exceptions.Timeout:
            self.log_result("DeepSeek Chat", False, "Request timeout (30s)")
            return False
        except Exception as e:
            self.log_result("DeepSeek Chat", False, str(e))
            return False

    def test_deepseek_reasoning(self) -> bool:
        """Test 5: DeepSeek Reasoning"""
        print_header("TEST 5: DeepSeek Reasoning")
        try:
            payload = {
                "task": "What is the capital of France?",
                "model": "deepseek",
                "temperature": 0.5
            }
            
            response = requests.post(REASON_ENDPOINT, json=payload, timeout=30)
            
            if response.status_code != 200:
                self.log_result(
                    "DeepSeek Reasoning",
                    False,
                    f"Status: {response.status_code}"
                )
                return False
            
            data = response.json()
            
            if data.get('error'):
                print_warning(f"DeepSeek reasoning returned error: {data.get('response')}")
                self.log_result("DeepSeek Reasoning", False, "API returned error response")
                return False
            
            response_text = data.get('response', '')
            self.log_result(
                "DeepSeek Reasoning",
                True,
                f"Response received ({len(response_text)} chars)"
            )
            print_info(f"Response: {response_text[:150]}...")
            
            return True
        except requests.exceptions.Timeout:
            self.log_result("DeepSeek Reasoning", False, "Request timeout (30s)")
            return False
        except Exception as e:
            self.log_result("DeepSeek Reasoning", False, str(e))
            return False

    def test_embedding_openai(self) -> bool:
        """Test 6: OpenAI Embedding Model"""
        print_header("TEST 6: OpenAI Embedding Model")
        try:
            payload = {
                "text": "This is a test sentence for embedding",
                "model": "openai"
            }
            
            response = requests.post(EMBED_ENDPOINT, json=payload, timeout=30)
            
            if response.status_code != 200:
                self.log_result(
                    "OpenAI Embedding",
                    False,
                    f"Status: {response.status_code}"
                )
                return False
            
            data = response.json()
            
            if data.get('error'):
                print_warning(f"Embedding returned error: {data.get('response')}")
                self.log_result("OpenAI Embedding", False, "API returned error response")
                return False
            
            embedding = data.get('embedding', [])
            self.log_result(
                "OpenAI Embedding",
                True,
                f"Embedding generated ({len(embedding)} dimensions)"
            )
            
            return True
        except requests.exceptions.Timeout:
            self.log_result("OpenAI Embedding", False, "Request timeout (30s)")
            return False
        except Exception as e:
            self.log_result("OpenAI Embedding", False, str(e))
            return False

    def test_ollama_service(self) -> bool:
        """Test 7: Ollama Local SLM Service"""
        print_header("TEST 7: Ollama Local SLM Service")
        try:
            response = requests.get(f"{API_BASE_URL}/ollama/models/", timeout=10)
            
            if response.status_code == 503:
                print_warning("Ollama service not available (optional)")
                self.log_result("Ollama Service", True, "Not required - Ollama is optional")
                return True
            
            if response.status_code != 200:
                self.log_result(
                    "Ollama Service",
                    False,
                    f"Status: {response.status_code}"
                )
                return False
            
            data = response.json()
            models = data.get('models', [])
            count = data.get('count', 0)
            
            self.log_result(
                "Ollama Service",
                True,
                f"Service healthy, {count} models available"
            )
            print_info(f"Available models: {', '.join(models[:3])}..." if models else "No models currently loaded")
            
            return True
        except requests.exceptions.Timeout:
            print_warning("Ollama service timeout (optional)")
            self.log_result("Ollama Service", True, "Timeout - optional component")
            return True
        except Exception as e:
            print_warning(f"Ollama service check failed: {e} (optional)")
            self.log_result("Ollama Service", True, "Check failed - optional component")
            return True

    def test_frontend_api_client(self) -> bool:
        """Test 8: Frontend API Client Types"""
        print_header("TEST 8: Frontend API Client Types")
        try:
            # Check if backend.ts file exists and has proper types
            backend_ts_path = r"c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\src\api\backend.ts"
            
            if not os.path.exists(backend_ts_path):
                self.log_result("Frontend API Client", False, f"File not found: {backend_ts_path}")
                return False
            
            with open(backend_ts_path, 'r') as f:
                content = f.read()
            
            # Check for required interfaces
            required_interfaces = [
                'ChatRequest',
                'ReasonRequest',
                'EmbedRequest',
                'sendChatMessage',
                'sendReasoningTask',
            ]
            
            all_found = all(interface in content for interface in required_interfaces)
            
            if all_found:
                self.log_result(
                    "Frontend API Client",
                    True,
                    "All required interfaces and functions found"
                )
                print_info(f"Found interfaces: {', '.join(required_interfaces)}")
                return True
            else:
                missing = [i for i in required_interfaces if i not in content]
                self.log_result(
                    "Frontend API Client",
                    False,
                    f"Missing: {', '.join(missing)}"
                )
                return False
        except Exception as e:
            self.log_result("Frontend API Client", False, str(e))
            return False

    def test_environment_configuration(self) -> bool:
        """Test 9: Environment Configuration"""
        print_header("TEST 9: Environment Configuration")
        try:
            env_path = r"c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend\.env"
            
            if not os.path.exists(env_path):
                self.log_result("Environment File", False, f"File not found: {env_path}")
                return False
            
            with open(env_path, 'r') as f:
                env_content = f.read()
            
            required_vars = ['OPENAI_API_KEY', 'OPENAI_BASE_URL']
            found_vars = all(var in env_content for var in required_vars)
            
            if found_vars:
                # Check if API key is set
                has_key = 'sk-' in env_content or 'YOUR KEY' not in env_content
                self.log_result(
                    "Environment Configuration",
                    has_key,
                    "All required environment variables configured" if has_key else "API key not set"
                )
                return has_key
            else:
                self.log_result(
                    "Environment Configuration",
                    False,
                    f"Missing variables: {[v for v in required_vars if v not in env_content]}"
                )
                return False
        except Exception as e:
            self.log_result("Environment Configuration", False, str(e))
            return False

    def test_cors_configuration(self) -> bool:
        """Test 10: CORS Configuration"""
        print_header("TEST 10: CORS Configuration")
        try:
            # Make a request with Origin header
            headers = {'Origin': 'http://localhost:5173'}
            response = requests.options(HEALTH_ENDPOINT, headers=headers, timeout=10)
            
            cors_headers = response.headers
            
            has_cors = 'access-control-allow-origin' in cors_headers
            
            self.log_result(
                "CORS Configuration",
                has_cors,
                "CORS headers present" if has_cors else "No CORS headers"
            )
            
            if has_cors:
                print_info(f"Allowed Origin: {cors_headers.get('access-control-allow-origin')}")
            
            return has_cors
        except Exception as e:
            self.log_result("CORS Configuration", False, str(e))
            return False

    def generate_report(self):
        """Generate test report"""
        print_header("TEST SUMMARY REPORT")
        
        print(f"Total Tests: {self.total_tests}")
        print(f"{Colors.GREEN}Passed: {self.passed_tests}{Colors.RESET}")
        print(f"{Colors.RED}Failed: {self.failed_tests}{Colors.RESET}")
        print(f"Success Rate: {(self.passed_tests/self.total_tests*100):.1f}%\n")
        
        print_header("DETAILED RESULTS")
        for test_name, result in self.results.items():
            status_color = Colors.GREEN if result['status'] == 'PASS' else Colors.RED
            print(f"{status_color}[{result['status']}]{Colors.RESET} {test_name}")
            if result['details']:
                print(f"    → {result['details']}\n")
        
        # Final status
        print_header("FINAL STATUS")
        if self.failed_tests == 0:
            print_success("All tests passed! Integration is working correctly.")
        else:
            print_warning(f"{self.failed_tests} test(s) failed. Check the details above.")

def main():
    """Run all integration tests"""
    print(f"\n{Colors.BOLD}{Colors.BLUE}")
    print("╔════════════════════════════════════════════════════════════╗")
    print("║          UI-FF1 BACKEND INTEGRATION TEST SUITE              ║")
    print("║    Testing: DeepSeek LLM, Embeddings, Ollama SLM, UI       ║")
    print("╚════════════════════════════════════════════════════════════╝")
    print(f"{Colors.RESET}\n")
    
    tester = IntegrationTester()
    
    # Run all tests
    if not tester.test_backend_connectivity():
        print_error("\nBackend server is not running!")
        print_info("Start the backend with: uvicorn main:app --reload")
        return
    
    tester.test_health_endpoint()
    tester.test_models_endpoint()
    tester.test_deepseek_llm()
    tester.test_deepseek_reasoning()
    tester.test_embedding_openai()
    tester.test_ollama_service()
    tester.test_frontend_api_client()
    tester.test_environment_configuration()
    tester.test_cors_configuration()
    
    # Generate report
    tester.generate_report()
    
    # Return exit code
    sys.exit(0 if tester.failed_tests == 0 else 1)

if __name__ == "__main__":
    main()
