"""
Simple Integration Test - No Unicode
"""
import requests
import json

API_BASE_URL = "http://localhost:8000"

print("\n" + "="*60)
print("SIMPLE INTEGRATION TEST")
print("="*60 + "\n")

# Test 1: Health Check
print("[1] Testing Health Endpoint...")
try:
    response = requests.get(f"{API_BASE_URL}/health/", timeout=10)
    health = response.json()
    print(f"    Status: {health.get('status')}")
    print(f"    External LLM: {health.get('external_llm')}")
    print(f"    Ollama: {health.get('ollama_service')}")
    print(f"    Embeddings: {health.get('embeddings')}")
    print("    [PASS]\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

# Test 2: Chat with DeepSeek
print("[2] Testing Chat with DeepSeek...")
try:
    payload = {
        "message": "What is the weather like today?",
        "model": "deepseek",
        "temperature": 0.7
    }
    response = requests.post(f"{API_BASE_URL}/chat/", json=payload, timeout=30)
    data = response.json()
    if data.get('success'):
        print(f"    Response: {data.get('response')[:100]}...")
        print("    [PASS]\n")
    else:
        print(f"    [FAIL] Error: {data.get('error')}\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

# Test 3: Embeddings
print("[3] Testing Embeddings...")
try:
    payload = {
        "text": "Sample text for embedding",
        "model": "openai"
    }
    response = requests.post(f"{API_BASE_URL}/embed/", json=payload, timeout=30)
    data = response.json()
    if not data.get('error'):
        embedding = data.get('embedding', [])
        print(f"    Dimensions: {len(embedding)}")
        print("    [PASS]\n")
    else:
        print(f"    [FAIL] Error: {data.get('message')}\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

# Test 4: Models
print("[4] Testing Available Models...")
try:
    response = requests.get(f"{API_BASE_URL}/models/", timeout=10)
    data = response.json()
    print(f"    LLM Models: {data.get('llm_models', [])}")
    print(f"    SLM Models: {data.get('slm_models', [])}")
    print(f"    Embedding Models: {data.get('embedding_models', [])}")
    print("    [PASS]\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

print("="*60)
print("All Tests Complete!")
print("="*60)
