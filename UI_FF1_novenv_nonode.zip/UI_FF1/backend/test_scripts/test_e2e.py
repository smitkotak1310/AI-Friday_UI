"""
Comprehensive End-to-End Integration Test
Tests: Upload, Chat, Reasoning, Embeddings, and Full Flow
"""
import requests
import json

API_BASE_URL = "http://localhost:8000"

print("\n" + "="*70)
print("END-TO-END INTEGRATION TEST")
print("="*70 + "\n")

# Test 1: Upload
print("[1] Testing Document Upload...")
try:
    file_path = r"c:\Users\GenAIAHMGPUSR31\Desktop\UI_FF1\backend\test_document.txt"
    with open(file_path, 'rb') as f:
        files = {'file': f}
        response = requests.post(f'{API_BASE_URL}/upload', files=files)
    
    if response.status_code == 200:
        data = response.json()
        print(f"    SUCCESS: {data.get('message')}")
        print(f"    File size: {data.get('size')} bytes")
        print(f"    Path: {data.get('path')}")
        print("    [PASS]\n")
    else:
        print(f"    [FAIL] Status: {response.status_code}\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

# Test 2: Health Check
print("[2] Testing Health Endpoint...")
try:
    response = requests.get(f"{API_BASE_URL}/health/", timeout=10)
    health = response.json()
    all_healthy = all([
        health.get('status') == 'ok',
        health.get('external_llm') == 'healthy',
        health.get('embeddings') == 'healthy'
    ])
    if all_healthy:
        print(f"    External LLM: {health.get('external_llm')}")
        print(f"    Embeddings: {health.get('embeddings')}")
        print(f"    Ollama: {health.get('ollama_service')}")
        print("    [PASS]\n")
    else:
        print("    [FAIL] Not all services healthy\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

# Test 3: Chat with DeepSeek
print("[3] Testing Chat (DeepSeek LLM)...")
try:
    payload = {
        "message": "Hello! How can I help you?",
        "model": "deepseek",
        "temperature": 0.7
    }
    response = requests.post(f"{API_BASE_URL}/chat/", json=payload, timeout=30)
    if response.status_code == 200:
        data = response.json()
        if data.get('success'):
            response_text = data.get('response', '')
            print(f"    Response: {response_text[:80]}...")
            print("    [PASS]\n")
        else:
            print(f"    [FAIL] {data.get('error')}\n")
    else:
        print(f"    [FAIL] Status: {response.status_code}\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

# Test 4: Reasoning
print("[4] Testing Reasoning (DeepSeek)...")
try:
    payload = {
        "task": "What is the capital of France?",
        "model": "deepseek",
        "temperature": 0.5
    }
    response = requests.post(f"{API_BASE_URL}/reason/", json=payload, timeout=30)
    if response.status_code == 200:
        data = response.json()
        if data.get('success'):
            response_text = data.get('response', '')
            print(f"    Response: {response_text[:80]}...")
            print("    [PASS]\n")
        else:
            print(f"    [FAIL] {data.get('error')}\n")
    else:
        print(f"    [FAIL] Status: {response.status_code}\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

# Test 5: Embeddings
print("[5] Testing Embeddings (OpenAI)...")
try:
    payload = {
        "text": "Insurance policy document embedding test",
        "model": "openai"
    }
    response = requests.post(f"{API_BASE_URL}/embed/", json=payload, timeout=30)
    if response.status_code == 200:
        data = response.json()
        if not data.get('error'):
            embedding = data.get('embedding', [])
            print(f"    Dimensions: {len(embedding)}")
            print(f"    First 5 values: {embedding[:5]}")
            print("    [PASS]\n")
        else:
            print(f"    [FAIL] {data.get('message')}\n")
    else:
        print(f"    [FAIL] Status: {response.status_code}\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

# Test 6: Models
print("[6] Testing Available Models...")
try:
    response = requests.get(f"{API_BASE_URL}/models/", timeout=10)
    if response.status_code == 200:
        data = response.json()
        print(f"    LLM Models: {data.get('llm_models', [])}")
        print(f"    SLM Models (Ollama): {len(data.get('slm_models', []))} available")
        print(f"    Embedding Models: {data.get('embedding_models', [])}")
        print("    [PASS]\n")
    else:
        print(f"    [FAIL] Status: {response.status_code}\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

# Test 7: Ollama Models
print("[7] Testing Ollama Service...")
try:
    response = requests.get(f"{API_BASE_URL}/ollama/models/", timeout=10)
    if response.status_code == 200:
        data = response.json()
        models = data.get('models', [])
        count = data.get('count', 0)
        print(f"    Models available: {count}")
        if count > 0:
            print(f"    Sample models: {models[:3]}")
        print("    [PASS]\n")
    else:
        print(f"    [FAIL] Status: {response.status_code}\n")
except Exception as e:
    print(f"    [FAIL] {e}\n")

print("="*70)
print("All Tests Complete!")
print("="*70)
print("\nFrontend is ready to use at: http://localhost:5173/")
print("Backend API is ready at: http://localhost:8000/docs\n")
