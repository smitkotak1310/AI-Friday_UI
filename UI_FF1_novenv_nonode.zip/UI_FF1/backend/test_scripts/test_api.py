#!/usr/bin/env python3
"""
Test client for the multimodal FastAPI backend
Tests both external LLM (DeepSeek) and local SLMs
"""

import requests
import json
import time

BASE_URL = "http://localhost:8000"

def print_header(title):
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)

def test_health():
    """Test health check endpoint"""
    print_header("Testing Health Check")
    try:
        response = requests.get(f"{BASE_URL}/health/")
        print(f"✓ Status: {response.status_code}")
        print(f"✓ Response: {response.json()}")
    except Exception as e:
        print(f"✗ Error: {e}")

def test_available_models():
    """List available models"""
    print_header("Testing Available Models Endpoint")
    try:
        response = requests.get(f"{BASE_URL}/models/")
        print(f"✓ Status: {response.status_code}")
        models = response.json()
        print(f"\n📊 Available Models:")
        print(f"   LLM Models: {models['llm_models']}")
        print(f"   SLM Models: {models['slm_models']}")
        print(f"   Embedding Models: {models['embedding_models']}")
    except Exception as e:
        print(f"✗ Error: {e}")

def test_chat_deepseek():
    """Test DeepSeek chat (External LLM)"""
    print_header("Testing DeepSeek Chat (External LLM)")
    try:
        payload = {
            "message": "What is the capital of France?",
            "model": "deepseek"
        }
        response = requests.post(f"{BASE_URL}/chat/", json=payload)
        print(f"✓ Status: {response.status_code}")
        result = response.json()
        print(f"✓ Model: {result.get('model')}")
        print(f"✓ Response: {result.get('response')}")
        if result.get('error'):
            print(f"⚠ Error: {result.get('error')}")
    except Exception as e:
        print(f"✗ Error: {e}")

def test_chat_llama():
    """Test Llama chat (Local SLM)"""
    print_header("Testing Llama Chat (Local SLM)")
    try:
        payload = {
            "message": "Hello! How are you?",
            "model": "llama"
        }
        response = requests.post(f"{BASE_URL}/chat/", json=payload)
        print(f"✓ Status: {response.status_code}")
        result = response.json()
        print(f"✓ Model: {result.get('model')}")
        print(f"✓ Response: {result.get('response')}")
    except Exception as e:
        print(f"✗ Error: {e}")

def test_chat_gemma():
    """Test Gemma chat (Local SLM)"""
    print_header("Testing Gemma Chat (Local SLM)")
    try:
        payload = {
            "message": "Explain quantum computing in simple terms.",
            "model": "gemma"
        }
        response = requests.post(f"{BASE_URL}/chat/", json=payload)
        print(f"✓ Status: {response.status_code}")
        result = response.json()
        print(f"✓ Model: {result.get('model')}")
        print(f"✓ Response: {result.get('response')}")
    except Exception as e:
        print(f"✗ Error: {e}")

def test_reasoning():
    """Test reasoning endpoint with DeepSeek"""
    print_header("Testing Reasoning with DeepSeek")
    try:
        payload = {
            "task": "Solve the equation: 2x + 5 = 13",
            "model": "deepseek",
            "context": "This is a linear algebra problem"
        }
        response = requests.post(f"{BASE_URL}/reason/", json=payload)
        print(f"✓ Status: {response.status_code}")
        result = response.json()
        print(f"✓ Model: {result.get('model')}")
        print(f"✓ Response: {result.get('response')}")
    except Exception as e:
        print(f"✗ Error: {e}")

def test_embedding_openai():
    """Test OpenAI embedding"""
    print_header("Testing OpenAI Embedding (External)")
    try:
        payload = {
            "text": "The quick brown fox jumps over the lazy dog",
            "model": "openai"
        }
        response = requests.post(f"{BASE_URL}/embed/", json=payload)
        print(f"✓ Status: {response.status_code}")
        result = response.json()
        print(f"✓ Model: {result.get('model')}")
        embedding = result.get('embedding', [])
        if embedding:
            print(f"✓ Embedding dimension: {len(embedding)}")
            print(f"✓ First 5 values: {embedding[:5]}")
        else:
            print(f"⚠ No embedding returned")
    except Exception as e:
        print(f"✗ Error: {e}")

def test_embedding_gte():
    """Test GTE embedding (Local)"""
    print_header("Testing GTE Embedding (Local SLM)")
    try:
        payload = {
            "text": "Machine learning is a subset of artificial intelligence",
            "model": "gte"
        }
        response = requests.post(f"{BASE_URL}/embed/", json=payload)
        print(f"✓ Status: {response.status_code}")
        result = response.json()
        print(f"✓ Model: {result.get('model')}")
        embedding = result.get('embedding', [])
        if embedding:
            print(f"✓ Embedding dimension: {len(embedding)}")
            print(f"✓ First 5 values: {embedding[:5]}")
        else:
            print(f"⚠ No embedding returned")
    except Exception as e:
        print(f"✗ Error: {e}")

def run_all_tests():
    """Run all tests"""
    print("\n")
    print("╔" + "="*58 + "╗")
    print("║" + " "*58 + "║")
    print("║" + "  MULTIMODAL AI BACKEND - COMPREHENSIVE TEST SUITE  ".center(58) + "║")
    print("║" + " "*58 + "║")
    print("╚" + "="*58 + "╝")
    
    try:
        test_health()
        time.sleep(1)
        
        test_available_models()
        time.sleep(1)
        
        test_chat_deepseek()
        time.sleep(2)
        
        test_chat_llama()
        time.sleep(2)
        
        test_chat_gemma()
        time.sleep(2)
        
        test_reasoning()
        time.sleep(2)
        
        test_embedding_openai()
        time.sleep(2)
        
        test_embedding_gte()
        
        print_header("All Tests Completed!")
        print("\n✓ Test suite finished successfully!\n")
        
    except KeyboardInterrupt:
        print("\n\n⚠ Tests interrupted by user")
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")

if __name__ == "__main__":
    print("\n⏳ Waiting for server to be ready...")
    time.sleep(2)
    run_all_tests()
