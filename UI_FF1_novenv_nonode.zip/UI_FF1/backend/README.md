# FastAPI backend for Multimodal Architecture

This backend provides endpoints to interact with:
- An external LLM (OpenAI) for main reasoning and big tasks (via ChatOpenAI and EmbeddingOpenAI)
- Local SLMs for chat, reasoning, and embedding tasks:
  - Llama-3.2-3b-it (Chat)
  - Gemma-3-4b-it (Chat)
  - Qwen-2.5.1-coder-it (Chat)
  - Deepseek-r1 (Reasoning)
  - Gte-large (Embedding)

## Setup

1. Create a Python virtual environment:
   ```powershell
   python -m venv .venv
   .venv\Scripts\Activate.ps1
   ```
2. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
3. Run the server:
   ```powershell
   uvicorn main:app --reload
   ```

## Configuration
- Set your OpenAI API key and base URL in the `.env` file.

## Endpoints
- `/chat/` - Chat with selected model (LLM or SLM)
- `/reason/` - Reasoning tasks
- `/embed/` - Embedding tasks
