"""
Local SLM (Small Language Model) integration module
Supports: Llama-3.2-3b-it, Gemma-3-4b-it, Qwen-2.5.1-coder-it, Deepseek-r1, Gte-large
"""

import os
from typing import List, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Llama-3.2-3b-it (llama-cpp-python)
try:
    from llama_cpp import Llama
    logger.info("llama-cpp-python loaded successfully")
except ImportError as e:
    logger.warning(f"llama-cpp-python not installed: {e}")
    Llama = None

# Gemma, Qwen, Deepseek (transformers)
try:
    from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
    logger.info("transformers loaded successfully")
except ImportError as e:
    logger.warning(f"transformers not installed: {e}")
    AutoModelForCausalLM = None
    AutoTokenizer = None
    pipeline = None

# Gte-large (sentence-transformers)
try:
    from sentence_transformers import SentenceTransformer
    logger.info("sentence-transformers loaded successfully")
except ImportError as e:
    logger.warning(f"sentence-transformers not installed: {e}")
    SentenceTransformer = None

# ===== MODEL PATH CONFIGURATION =====
def get_model_path(model_key: str) -> str:
    """
    Get the local path for a model.
    Update these paths to match your actual local model locations.
    """
    base = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'models'))
    
    paths = {
        'llama': os.path.join(base, 'llama-3.2-3b-it', 'llama-3.2-3b-it.Q4_K_M.gguf'),
        'gemma': os.path.join(base, 'gemma-3-4b-it'),
        'qwen': os.path.join(base, 'qwen-2.5.1-coder-it'),
        'deepseek': os.path.join(base, 'deepseek-r1'),
        'gte': os.path.join(base, 'gte-large'),
    }
    
    path = paths.get(model_key, '')
    logger.info(f"Model path for {model_key}: {path}")
    return path

# ===== LLAMA-3.2-3B-IT =====
llama_model = None

def load_llama():
    """Load Llama-3.2-3b-it model"""
    global llama_model
    if Llama is None:
        logger.error("llama-cpp-python not available")
        return None
    if llama_model is None:
        try:
            model_path = get_model_path('llama')
            if not os.path.exists(model_path):
                logger.error(f"Llama model not found at {model_path}")
                return None
            logger.info(f"Loading Llama model from {model_path}")
            llama_model = Llama(model_path=model_path, n_gpu_layers=-1)
            logger.info("Llama model loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load Llama model: {e}")
            return None
    return llama_model

def llama_chat(message: str, history: Optional[List[dict]] = None) -> str:
    """Chat using Llama-3.2-3b-it"""
    try:
        model = load_llama()
        if model is None:
            return "[Llama-3.2-3b-it not available]"
        
        prompt = message
        output = model(prompt, max_tokens=256)
        return output['choices'][0]['text'].strip()
    except Exception as e:
        logger.error(f"Llama chat error: {e}")
        return f"[Error in Llama: {str(e)}]"

# ===== GEMMA, QWEN, DEEPSEEK (TRANSFORMERS) =====
model_cache = {}

def load_transformer_model(model_key: str):
    """Load a transformer-based model (Gemma, Qwen, Deepseek)"""
    if pipeline is None:
        logger.error("transformers not available")
        return None
    
    if model_key not in model_cache:
        try:
            model_path = get_model_path(model_key)
            if not os.path.exists(model_path):
                logger.error(f"Model not found at {model_path}")
                return None
            
            logger.info(f"Loading {model_key} model from {model_path}")
            tokenizer = AutoTokenizer.from_pretrained(model_path)
            model = AutoModelForCausalLM.from_pretrained(
                model_path, 
                device_map="auto",
                torch_dtype="auto"
            )
            model_cache[model_key] = pipeline('text-generation', model=model, tokenizer=tokenizer)
            logger.info(f"{model_key} model loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load {model_key} model: {e}")
            return None
    
    return model_cache[model_key]

def gemma_chat(message: str, history: Optional[List[dict]] = None) -> str:
    """Chat using Gemma-3-4b-it"""
    try:
        pipe = load_transformer_model('gemma')
        if pipe is None:
            return "[Gemma-3-4b-it not available]"
        
        result = pipe(message, max_length=256, do_sample=True, top_p=0.95)
        return result[0]['generated_text'].strip()
    except Exception as e:
        logger.error(f"Gemma chat error: {e}")
        return f"[Error in Gemma: {str(e)}]"

def qwen_chat(message: str, history: Optional[List[dict]] = None) -> str:
    """Chat using Qwen-2.5.1-coder-it"""
    try:
        pipe = load_transformer_model('qwen')
        if pipe is None:
            return "[Qwen-2.5.1-coder-it not available]"
        
        result = pipe(message, max_length=256, do_sample=True, top_p=0.95)
        return result[0]['generated_text'].strip()
    except Exception as e:
        logger.error(f"Qwen chat error: {e}")
        return f"[Error in Qwen: {str(e)}]"

def deepseek_reason(task: str, context: Optional[str] = None) -> str:
    """Reasoning using Deepseek-r1"""
    try:
        prompt = f"Task: {task}"
        if context:
            prompt += f"\n\nContext: {context}"
        
        pipe = load_transformer_model('deepseek')
        if pipe is None:
            return "[Deepseek-r1 not available]"
        
        result = pipe(prompt, max_length=512, do_sample=True, top_p=0.95)
        return result[0]['generated_text'].strip()
    except Exception as e:
        logger.error(f"Deepseek reasoning error: {e}")
        return f"[Error in Deepseek: {str(e)}]"

# ===== GTE-LARGE (EMBEDDING) =====
gte_model = None

def load_gte():
    """Load Gte-large embedding model"""
    global gte_model
    if SentenceTransformer is None:
        logger.error("sentence-transformers not available")
        return None
    
    if gte_model is None:
        try:
            model_path = get_model_path('gte')
            if not os.path.exists(model_path):
                logger.error(f"GTE model not found at {model_path}")
                return None
            
            logger.info(f"Loading GTE model from {model_path}")
            gte_model = SentenceTransformer(model_path)
            logger.info("GTE model loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load GTE model: {e}")
            return None
    
    return gte_model

def gte_embed(text: str) -> list:
    """Generate embeddings using Gte-large"""
    try:
        model = load_gte()
        if model is None:
            return []
        
        embedding = model.encode([text])[0].tolist()
        return embedding
    except Exception as e:
        logger.error(f"GTE embedding error: {e}")
        return []
