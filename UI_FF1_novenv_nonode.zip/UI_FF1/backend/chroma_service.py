"""
ChromaDB Vector Database Service
Handles document indexing, storage, and semantic search for RAG
"""

import chromadb
from chromadb.config import Settings
from pathlib import Path
import logging
from typing import List, Dict, Optional, Tuple
from langchain_openai import OpenAIEmbeddings
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

class ChromaDBService:
    def __init__(self, persist_dir: str = "./chroma_db", embedding_model=None):
        """
        Initialize ChromaDB service with persistent storage
        
        Args:
            persist_dir: Directory to store ChromaDB data
            embedding_model: OpenAI embeddings model instance
        """
        self.persist_dir = Path(persist_dir)
        self.persist_dir.mkdir(exist_ok=True)
        
        self.embedding_model = embedding_model
        self.client = None
        self.collection = None
        
        try:
            # Initialize ChromaDB with persistent storage (new API)
            self.client = chromadb.PersistentClient(
                path=str(self.persist_dir)
            )
            
            # Get or create collection
            self.collection = self.client.get_or_create_collection(
                name="policy_documents",
                metadata={"hnsw:space": "cosine"}  # Use cosine similarity
            )
            
            logger.info(f"✓ ChromaDB initialized with collection 'policy_documents'")
            logger.info(f"  Persist directory: {self.persist_dir}")
            
        except Exception as e:
            logger.error(f"✗ Failed to initialize ChromaDB: {e}")
            self.client = None
            self.collection = None
    
    def add_document(self, doc_id: str, content: str, metadata: Dict = None) -> bool:
        """
        Add document to ChromaDB collection
        
        Args:
            doc_id: Unique document identifier
            content: Document text content
            metadata: Document metadata (filename, upload date, etc.)
        
        Returns:
            bool: Success status
        """
        try:
            if not self.collection:
                logger.error("ChromaDB collection not initialized")
                return False
            
            if not content or len(content.strip()) == 0:
                logger.warning(f"Empty content for document {doc_id}")
                return False
            
            # Prepare metadata
            if metadata is None:
                metadata = {}
            
            # Add to collection with auto-embedding via OpenAI API
            self.collection.add(
                ids=[doc_id],
                documents=[content],
                metadatas=[metadata]
            )
            
            logger.info(f"✓ Document added to ChromaDB: {doc_id}")
            logger.info(f"  Content length: {len(content)} characters")
            
            return True
            
        except Exception as e:
            logger.error(f"✗ Failed to add document {doc_id}: {e}")
            return False
    
    def search_documents(self, query: str, top_k: int = 3) -> List[Tuple[str, float]]:
        """
        Search documents using semantic similarity
        
        Args:
            query: Search query text
            top_k: Number of top results to return
        
        Returns:
            List of tuples (document_content, similarity_score)
        """
        try:
            if not self.collection:
                logger.error("ChromaDB collection not initialized")
                return []
            
            results = self.collection.query(
                query_texts=[query],
                n_results=top_k
            )
            
            if not results or not results.get('documents') or not results['documents'][0]:
                logger.warning(f"No results found for query: {query}")
                return []
            
            # Extract documents and distances
            documents = results['documents'][0]
            distances = results['distances'][0] if results.get('distances') else []
            
            # Convert distances to similarity scores (cosine: lower distance = higher similarity)
            results_list = []
            for doc, distance in zip(documents, distances):
                similarity = 1 - distance  # Convert distance to similarity (0-1)
                results_list.append((doc, similarity))
            
            logger.info(f"✓ Found {len(results_list)} documents for query")
            return results_list
            
        except Exception as e:
            logger.error(f"✗ Search failed: {e}")
            return []
    
    def get_document_count(self) -> int:
        """Get total number of documents in collection"""
        try:
            if not self.collection:
                return 0
            count = self.collection.count()
            return count
        except Exception as e:
            logger.error(f"Failed to get document count: {e}")
            return 0
    
    def get_all_documents(self) -> List[Dict]:
        """Get all documents from collection"""
        try:
            if not self.collection:
                return []
            
            # Get all documents
            results = self.collection.get()
            
            documents = []
            if results and results.get('documents'):
                for doc_id, content, metadata in zip(
                    results['ids'],
                    results['documents'],
                    results.get('metadatas', [])
                ):
                    documents.append({
                        'id': doc_id,
                        'content': content,
                        'metadata': metadata or {}
                    })
            
            return documents
            
        except Exception as e:
            logger.error(f"Failed to get documents: {e}")
            return []
    
    def delete_document(self, doc_id: str) -> bool:
        """Delete document from collection"""
        try:
            if not self.collection:
                return False
            
            self.collection.delete(ids=[doc_id])
            logger.info(f"✓ Document deleted: {doc_id}")
            return True
            
        except Exception as e:
            logger.error(f"✗ Failed to delete document {doc_id}: {e}")
            return False
    
    def clear_all(self) -> bool:
        """Clear all documents from collection"""
        try:
            if not self.collection:
                return False
            
            # Get all IDs and delete
            results = self.collection.get()
            if results and results.get('ids'):
                self.collection.delete(ids=results['ids'])
            
            logger.info("✓ All documents cleared from ChromaDB")
            return True
            
        except Exception as e:
            logger.error(f"✗ Failed to clear documents: {e}")
            return False
    
    def is_healthy(self) -> bool:
        """Check if ChromaDB is healthy and accessible"""
        try:
            if self.collection is None:
                return False
            
            # Try a simple operation
            count = self.collection.count()
            return True
            
        except Exception as e:
            logger.error(f"ChromaDB health check failed: {e}")
            return False


# Global service instance
chroma_service = None

def initialize_chroma_service(embedding_model=None) -> ChromaDBService:
    """Initialize global ChromaDB service instance"""
    global chroma_service
    
    try:
        chroma_service = ChromaDBService(
            persist_dir="./chroma_db",
            embedding_model=embedding_model
        )
        logger.info("✓ Global ChromaDB service initialized")
        return chroma_service
    except Exception as e:
        logger.error(f"✗ Failed to initialize ChromaDB service: {e}")
        chroma_service = None
        return None

def get_chroma_service() -> Optional[ChromaDBService]:
    """Get global ChromaDB service instance"""
    return chroma_service
