#!/usr/bin/env powershell
# Quick Start Script for Multimodal AI Application
# Run this to get started quickly

Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   🚀 MULTIMODAL AI APPLICATION - QUICK START SCRIPT 🚀     ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan

Write-Host ""
Write-Host "📋 WHAT THIS SCRIPT DOES:" -ForegroundColor Green
Write-Host "  1. Shows the current status of the application"
Write-Host "  2. Provides quick commands to start everything"
Write-Host "  3. Tests backend connectivity"
Write-Host "  4. Gives you options to continue"
Write-Host ""

# Check backend status
Write-Host "🔍 Checking Backend Status..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8000/health/" -ErrorAction Stop
    Write-Host "✅ Backend is RUNNING (http://localhost:8000)" -ForegroundColor Green
    Write-Host "   Status: $($response.Content)" -ForegroundColor Green
} catch {
    Write-Host "⚠️  Backend is NOT RUNNING" -ForegroundColor Yellow
    Write-Host "   Need to start it with: cd backend; uvicorn main:app --reload" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "📊 PROJECT STATUS:" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "Backend Files:" -ForegroundColor Green
Write-Host "  [OK] main.py             - FastAPI app with LangChain"
Write-Host "  [OK] models.py           - Local SLM management"
Write-Host "  [OK] test_api.py         - Test suite"
Write-Host "  [OK] requirements.txt    - Dependencies"
Write-Host "  [OK] .env                - Configuration"
Write-Host ""
Write-Host "Frontend Files:" -ForegroundColor Green
Write-Host "  [OK] App.tsx             - Main React app"
Write-Host "  [OK] src/api/backend.ts  - API client"
Write-Host "  [OK] src/components/     - React components"
Write-Host ""
Write-Host "Documentation:" -ForegroundColor Green
Write-Host "  [OK] ARCHITECTURE.md          - Complete architecture"
Write-Host "  [OK] EXECUTION_SUMMARY.md     - Execution summary"
Write-Host "  [OK] VISUAL_GUIDE.md          - Visual diagrams"
Write-Host "  [OK] WORKSPACE_SUMMARY.txt    - Project overview"
Write-Host ""

Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "🚀 QUICK START COMMANDS:" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "1️⃣  Start Backend (Terminal 1):" -ForegroundColor Yellow
Write-Host "   cd backend" -ForegroundColor White
Write-Host "   .\..\venv\Scripts\Activate.ps1" -ForegroundColor White
Write-Host "   uvicorn main:app --reload" -ForegroundColor White
Write-Host ""
Write-Host "2️⃣  Test Backend (Terminal 2):" -ForegroundColor Yellow
Write-Host "   cd backend" -ForegroundColor White
Write-Host "   .\..\venv\Scripts\python.exe test_api.py" -ForegroundColor White
Write-Host ""
Write-Host "3️⃣  Start Frontend (Terminal 3):" -ForegroundColor Yellow
Write-Host "   npm run dev" -ForegroundColor White
Write-Host ""
Write-Host "4️⃣  Open in Browser:" -ForegroundColor Yellow
Write-Host "   http://localhost:5173  (Frontend)" -ForegroundColor White
Write-Host "   http://localhost:8000/docs  (API Docs)" -ForegroundColor White
Write-Host ""

Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "🎯 API ENDPOINTS:" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "GET  /health/              - Health check" -ForegroundColor Cyan
Write-Host "GET  /models/              - List available models" -ForegroundColor Cyan
Write-Host "POST /chat/                - Chat with LLM/SLM" -ForegroundColor Cyan
Write-Host "POST /reason/              - Reasoning tasks" -ForegroundColor Cyan
Write-Host "POST /embed/               - Generate embeddings" -ForegroundColor Cyan
Write-Host ""

Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "🤖 AVAILABLE MODELS:" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "External LLM (Azure):" -ForegroundColor Green
Write-Host "  • DeepSeek V3 (via ChatOpenAI) [OK] ACTIVE" -ForegroundColor Green
Write-Host ""
Write-Host "Local SLMs (Optional):" -ForegroundColor Yellow
Write-Host "  • Llama-3.2-3b-it" -ForegroundColor Yellow
Write-Host "  • Gemma-3-4b-it" -ForegroundColor Yellow
Write-Host "  • Qwen-2.5.1-coder-it" -ForegroundColor Yellow
Write-Host "  • Deepseek-r1" -ForegroundColor Yellow
Write-Host ""
Write-Host "Embeddings:" -ForegroundColor Green
Write-Host "  • OpenAI Ada-002 (Azure) [OK] ACTIVE" -ForegroundColor Green
Write-Host "  • Gte-large (Local, optional)" -ForegroundColor Yellow
Write-Host ""

Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "📝 EXAMPLE API CALLS:" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "PowerShell - Test Chat:" -ForegroundColor Yellow
Write-Host '$body = @{' -ForegroundColor White
Write-Host '  message = "What is AI?"' -ForegroundColor White
Write-Host '  model = "deepseek"' -ForegroundColor White
Write-Host '} | ConvertTo-Json' -ForegroundColor White
Write-Host '$response = Invoke-WebRequest -Uri "http://localhost:8000/chat/" -Method POST -Body $body -ContentType "application/json"' -ForegroundColor White
Write-Host '$response.Content | ConvertFrom-Json' -ForegroundColor White
Write-Host ""

Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "✨ FEATURES:" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "[OK] FastAPI Backend with LangChain Integration" -ForegroundColor Green
Write-Host "[OK] External LLM (DeepSeek V3 via Azure)" -ForegroundColor Green
Write-Host "[OK] Support for Local SLMs (Llama, Gemma, Qwen, Deepseek)" -ForegroundColor Green
Write-Host "[OK] Embedding Models (OpenAI + Gte-large)" -ForegroundColor Green
Write-Host "[OK] CORS Enabled for Frontend" -ForegroundColor Green
Write-Host "[OK] Comprehensive Error Handling" -ForegroundColor Green
Write-Host "[OK] Complete Test Suite" -ForegroundColor Green
Write-Host "[OK] React Frontend with Beautiful UI" -ForegroundColor Green
Write-Host "[OK] Full Documentation" -ForegroundColor Green
Write-Host ""

Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "🔧 TROUBLESHOOTING:" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "❌ Backend won't start:" -ForegroundColor Red
Write-Host "   -> Check if virtual environment is activated" -ForegroundColor Yellow
Write-Host "   -> Run: pip install -r requirements.txt" -ForegroundColor Yellow
Write-Host "   -> Check .env file has API key" -ForegroundColor Yellow
Write-Host ""
Write-Host "❌ DeepSeek connection error:" -ForegroundColor Red
Write-Host "   -> Verify API key in .env" -ForegroundColor Yellow
Write-Host "   -> Check base URL is correct" -ForegroundColor Yellow
Write-Host "   -> Test network connectivity" -ForegroundColor Yellow
Write-Host ""
Write-Host "❌ Frontend can't reach backend:" -ForegroundColor Red
Write-Host "   -> Ensure backend is running on port 8000" -ForegroundColor Yellow
Write-Host "   -> Check CORS is enabled (it is by default)" -ForegroundColor Yellow
Write-Host "   -> Try: curl http://localhost:8000/health/" -ForegroundColor Yellow
Write-Host ""

Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "📚 DOCUMENTATION:" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "📖 Read these files for more information:" -ForegroundColor Green
Write-Host "   1. ARCHITECTURE.md       - Complete system design" -ForegroundColor Cyan
Write-Host "   2. EXECUTION_SUMMARY.md  - What was built" -ForegroundColor Cyan
Write-Host "   3. VISUAL_GUIDE.md       - Flow diagrams" -ForegroundColor Cyan
Write-Host "   4. WORKSPACE_SUMMARY.txt - Project overview" -ForegroundColor Cyan
Write-Host ""

Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "🎉 YOU'RE ALL SET! Your multimodal AI app is ready to use!" -ForegroundColor Green
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "Next Step: Start the backend and frontend as shown above!" -ForegroundColor Yellow
Write-Host ""
