import React, { useState, useEffect } from 'react';
import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';
import Dashboard from './components/dashboard/Dashboard';
import ChatInterface from './components/chat/ChatInterface';
import LoginPage, { SESSION_KEY } from './components/auth/LoginPage';
import SettingsModal from './components/settings/SettingsModal';
import { View, QueryResponse, DocumentInfo } from './types';
import { AlertCircle, FileText, ImageIcon } from 'lucide-react';
import { cn } from './lib/utils';

// SET THIS TO FALSE TO CONNECT TO YOUR ACTUAL FASTAPI BACKEND
const USE_MOCK = false;
const API_BASE_URL = 'http://localhost:8000';

// --- PROFESSIONAL MOCK DATA ---
const MOCK_RESPONSES: Record<string, QueryResponse> = {
  "hello": {
    "answer": "Hello! I am your dedicated Insurance Policy Assistant. I can help you understand your coverage, find specific clauses, or summarize your policy details. How can I assist you today?",
    "safe": true,
    "source": "System"
  },
  "what is my coverage": {
    "answer": "Based on the uploaded documents, your current policy provides comprehensive coverage for accidental damage, theft, and fire. Specifically, it covers up to $50,000 for personal property damage per occurrence.",
    "safe": true,
    "source": "Home_Insurance_Policy_2025.pdf"
  },
  "is there a deductible": {
    "answer": "Yes, your policy includes a standard deductible of $500 for all property damage claims. This amount must be paid out-of-pocket before the insurance provider covers the remaining costs.",
    "safe": true,
    "source": "Policy_Summary_v2.pdf"
  },
  "can i claim for water damage": {
    "answer": "Water damage is covered under Section 4.2 of your policy, provided the damage was caused by sudden and accidental pipe bursts. However, damage resulting from gradual seepage or maintenance issues is typically excluded.",
    "safe": true,
    "source": "Home_Insurance_Policy_2025.pdf"
  },
  "do you cover extreme weather": {
    "answer": "I can see some information related to your query, but I want to be 100% sure. Could you please be more specific or check the document manually?",
    "safe": false,
    "source": "N/A"
  },
  "default": {
    "answer": "I'm sorry, I couldn't find a specific answer to that in your current policy documents. Please try rephrasing your question or upload a more detailed document.",
    "safe": false,
    "source": "N/A"
  }
};

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [isUploading, setIsUploading] = useState(false);
  // Auth state — null means not logged in
  const [currentUser, setCurrentUser] = useState<{ username: string; name: string } | null>(() => {
    try {
      const saved = localStorage.getItem(SESSION_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Settings modal state
  const [showSettings, setShowSettings] = useState(false);

  // Helper to get storage keys
  const getKeys = () => {
    const username = currentUser?.username || 'default';
    return {
      docs: `docs_${username}`,
      chats: `chats_${username}`
    };
  };

  const [documents, setDocuments] = useState<DocumentInfo[]>(() => {
    try {
      const { docs } = getKeys();
      const saved = localStorage.getItem(docs);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [chatMessages, setChatMessages] = useState<any[]>(() => {
    try {
      const { chats } = getKeys();
      const saved = localStorage.getItem(chats);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Persist documents when they change
  useEffect(() => {
    if (currentUser) {
      const { docs } = getKeys();
      localStorage.setItem(docs, JSON.stringify(documents));
    }
  }, [documents, currentUser]);

  // Persist chat messages when they change
  useEffect(() => {
    if (currentUser) {
      const { chats } = getKeys();
      localStorage.setItem(chats, JSON.stringify(chatMessages));
    }
  }, [chatMessages, currentUser]);

  // --- MOCK HANDLERS ---
  const handleMockUpload = async (file: File) => {
    console.log('Mock Uploading:', file.name);
    setIsUploading(true);
    await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate network delay
    setIsUploading(false);
    
    const newDoc: DocumentInfo = {
      id: Math.random().toString(),
      name: file.name,
      size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
      type: file.name.endsWith('.pdf') ? 'PDF' : 'TXT',
      uploadedAt: new Date().toISOString().split('T')[0],
    };
    setDocuments(prev => [newDoc, ...prev]);
  };

  const handleMockAsk = async (question: string, useInternet: boolean = false): Promise<QueryResponse> => {
    console.log('Mock Asking:', question, 'Use Internet:', useInternet);
    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate AI thinking
    
    const lowerQuestion = question.toLowerCase();
    
    // Check for exact matches or keyword matches
    if (MOCK_RESPONSES[lowerQuestion]) return MOCK_RESPONSES[lowerQuestion];
    if (lowerQuestion.includes("coverage") || lowerQuestion.includes("covered")) return MOCK_RESPONSES["what is my coverage"];
    if (lowerQuestion.includes("deductible")) return MOCK_RESPONSES["is there a deductible"];
    if (lowerQuestion.includes("water")) return MOCK_RESPONSES["can i claim for water damage"];
    if (lowerQuestion.includes("weather") || lowerQuestion.includes("storm")) return MOCK_RESPONSES["do you cover extreme weather"];

    return MOCK_RESPONSES["default"];
  };

  // --- REAL BACKEND HANDLERS ---
  const handleRealUpload = async (file: File, extractedText?: string) => {
    setIsUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    if (extractedText) {
      formData.append('extracted_text', extractedText);
    }

    try {
      const response = await fetch(`${API_BASE_URL}/upload`, {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) throw new Error('Upload failed');
      
      const uploadResult = await response.json();
      
      // Use doc_id from backend response for consistent deletion
      const newDoc: DocumentInfo = {
        id: uploadResult.doc_id || Date.now().toString(),
        name: file.name,
        size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
        type: file.name.endsWith('.pdf') ? 'PDF' : file.name.endsWith('.txt') ? 'TXT' : 'IMAGE',
        uploadedAt: new Date().toISOString().split('T')[0],
      };
      setDocuments(prev => [newDoc, ...prev]);
    } catch (error) {
      console.error('Real Upload Error:', error);
      alert('Failed to upload document to the server.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteDocument = async (docId: string) => {
    try {
      const response = await fetch(`${API_BASE_URL}/documents/${docId}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Delete failed');
      
      const result = await response.json();
      
      // Remove from frontend documents state
      setDocuments(prev => prev.filter(doc => doc.id !== docId));
      
      console.log('Document deleted:', result);
    } catch (error) {
      console.error('Delete Error:', error);
      alert(`Failed to delete document: ${error}`);
    }
  };

  const handleRealAsk = async (question: string, useInternet: boolean = false): Promise<QueryResponse> => {
    try {
      // Step 1: Validate input using local SLM
      const validationResponse = await fetch(`${API_BASE_URL}/validate_input/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          query: question,
        }),
      });

      if (!validationResponse.ok) {
        throw new Error('Validation failed');
      }

      const validationData = await validationResponse.json();
      
      // If validation fails (out of context), return rejection message
      if (validationData.category === 'IRRELEVANT' || !validationData.valid) {
        return {
          answer: validationData.message || "I can only help with policy-related questions. Please ask something about your insurance coverage, deductibles, exclusions, or claims.",
          safe: false,
          source: 'Input Validator'
        };
      }

      // Step 2: Get RAG context from uploaded documents
      const documentsContext = documents.length > 0 
        ? documents.map(d => d.name).join(', ')
        : 'No documents uploaded';

      // Step 3: Send validated question to LLM with RAG context
      const response = await fetch(`${API_BASE_URL}/chat/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: question, 
          model: 'deepseek',
          temperature: 0.7,
          rag_context: documentsContext,
          documents: documents,
          use_internet: useInternet
        }),
      });

      if (!response.ok) throw new Error('Query failed');
      const data = await response.json();
      
      return {
        answer: data.response || data.answer || 'No response received',
        safe: !data.error,
        source: 'DeepSeek AI with RAG'
      };
    } catch (error) {
      console.error('Real Query Error:', error);
      return {
        answer: "I'm having trouble connecting to the AI service. Please check if your backend is running.",
        safe: false,
        source: 'Error'
      };
    }
  };

  const handleLogin = (user: { username: string; name: string }) => {
    setCurrentUser(user);
    // Persist session
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    
    // Load this specific user's data immediately
    const docs = localStorage.getItem(`docs_${user.username}`);
    const chats = localStorage.getItem(`chats_${user.username}`);
    setDocuments(docs ? JSON.parse(docs) : []);
    setChatMessages(chats ? JSON.parse(chats) : []);
  };

  const handleLogout = () => {
    localStorage.removeItem(SESSION_KEY);
    setCurrentUser(null);
    setDocuments([]);
    setChatMessages([]);
  };

  // Select appropriate handler
  const uploadHandler = USE_MOCK ? handleMockUpload : handleRealUpload;
  const askHandler = USE_MOCK ? handleMockAsk : handleRealAsk;

  // If not logged in, show login page
  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans text-slate-900">
      {/* Settings modal */}
      {showSettings && currentUser && (
        <SettingsModal
          currentUsername={currentUser.username}
          onClose={() => setShowSettings(false)}
        />
      )}

      <Sidebar
        activeView={activeView}
        setActiveView={setActiveView}
        onSettingsOpen={() => setShowSettings(true)}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        <Header
          view={activeView}
          userName={currentUser.name}
          onLogout={handleLogout}
          documents={documents}
          chatMessages={chatMessages}
          onNavigate={setActiveView}
        />
        
        <main className="flex-1 overflow-y-auto p-8">
          {activeView === 'dashboard' && (
            <Dashboard
              view={activeView}
              isUploading={isUploading}
              onUpload={uploadHandler}
              userName={currentUser.name}
              documentCount={documents.length}
            />
          )}

          {activeView === 'chat' && (
            <ChatInterface 
              onSendMessage={askHandler}
              onMessagesChange={setChatMessages}
              initialMessages={chatMessages}
            />
          )}

          {activeView === 'documents' && (
            <div className="max-w-5xl mx-auto space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-slate-800">Knowledge Base</h2>
                <span className="text-sm text-slate-500">{documents.length} documents indexed</span>
              </div>
              
              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Name</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Type</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Size</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Uploaded</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {documents.map((doc) => (
                      <tr key={doc.id} className="hover:bg-slate-50 transition-colors group">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className={cn(
                              "w-8 h-8 rounded flex items-center justify-center",
                              doc.type === 'IMAGE' ? "bg-purple-50 text-purple-600" : "bg-blue-50 text-blue-600"
                            )}>
                              {doc.type === 'IMAGE' ? <ImageIcon className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
                            </div>
                            <span className="text-sm font-medium text-slate-700">{doc.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-xs font-semibold px-2 py-1 bg-slate-100 text-slate-600 rounded-full">
                            {doc.type}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-500">{doc.size}</td>
                        <td className="px-6 py-4 text-sm text-slate-500">{doc.uploadedAt}</td>
                        <td className="px-6 py-4">
                          <button 
                            onClick={() => handleDeleteDocument(doc.id)}
                            className="text-slate-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100 font-semibold"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                    {documents.length === 0 && (
                      <tr>
                        <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                          <div className="flex flex-col items-center gap-3">
                            <AlertCircle className="w-10 h-10 opacity-20" />
                            <p>No documents found. Start by uploading one.</p>
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default App;
