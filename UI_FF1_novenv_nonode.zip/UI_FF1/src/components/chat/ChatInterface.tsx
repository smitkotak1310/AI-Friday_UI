import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Send, Loader2, ShieldAlert, Mic, MicOff, ImagePlus, X, Image as ImageIcon, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { createWorker } from 'tesseract.js';
import { Message, QueryResponse } from '../../types';
import ChatMessage from './ChatMessage';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
interface ChatInterfaceProps {
  onSendMessage: (question: string, useInternet?: boolean) => Promise<QueryResponse>;
  onMessagesChange?: (messages: Message[]) => void;
  initialMessages?: Message[];
}

// Extend window for SpeechRecognition
interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: (event: any) => void;
  onend: () => void;
  onerror: () => void;
  start: () => void;
  stop: () => void;
}

declare global {
  interface Window {
    SpeechRecognition: {
      new (): SpeechRecognition;
    };
    webkitSpeechRecognition: {
      new (): SpeechRecognition;
    };
  }
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------
const ChatInterface: React.FC<ChatInterfaceProps> = ({
  onSendMessage,
  onMessagesChange,
  initialMessages = [],
}) => {
  const [messages, setMessages] = useState<Message[]>(
    initialMessages.length > 0
      ? initialMessages
      : [{
          id: '1',
          role: 'assistant',
          content: "Hello! I'm your Insurance Policy Assistant. Please upload a policy document to get started, or ask me anything about your existing documents.",
          timestamp: new Date(),
        }]
  );
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [useInternet, setUseInternet] = useState(false);

  // Voice
  const [isListening, setIsListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(false);
  const recognitionRef = useRef<any | null>(null);

  // Image + background OCR
  // ocrText is extracted silently — never injected into inputValue
  const [imageName, setImageName] = useState<string | null>(null);
  const [ocrText, setOcrText] = useState<string | null>(null);
  const [isOcring, setIsOcring] = useState(false);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // ------------------------------------------------------------------
  // Scroll
  // ------------------------------------------------------------------
  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, isTyping]);
  useEffect(() => { if (onMessagesChange) onMessagesChange(messages); }, [messages, onMessagesChange]);

  // ------------------------------------------------------------------
  // Voice
  // ------------------------------------------------------------------
  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    setVoiceSupported(true);
    const rec = new SR();
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = 'en-US';
    rec.onresult = (event: any) => {
      const transcript = Array.from(event.results as any[])
        .map((r: any) => r[0].transcript)
        .join('');
      setInputValue(transcript);
    };
    rec.onend = () => setIsListening(false);
    rec.onerror = () => setIsListening(false);
    recognitionRef.current = rec;
  }, []);

  const toggleVoice = useCallback(() => {
    if (!recognitionRef.current) return;
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setInputValue('');
      recognitionRef.current.start();
      setIsListening(true);
    }
  }, [isListening]);

  // ------------------------------------------------------------------
  // Image select → background OCR (never touches inputValue)
  // ------------------------------------------------------------------
  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImageName(file.name);
    setOcrText(null);
    setIsOcring(true);

    try {
      const worker = await createWorker('eng');
      const { data: { text } } = await worker.recognize(file);
      await worker.terminate();
      const cleaned = text.trim();
      // Store silently — will be merged with usertext at send time
      setOcrText(cleaned || null);
    } catch {
      setOcrText(null);
    } finally {
      setIsOcring(false);
    }

    e.target.value = '';
  };

  const clearImage = () => {
    setImageName(null);
    setOcrText(null);
    setIsOcring(false);
  };

  // ------------------------------------------------------------------
  // Submit: combine typed text + OCR context → send to model
  //         Show ONLY the typed text in the chat bubble
  // ------------------------------------------------------------------
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const userTypedText = inputValue.trim();
    if (!userTypedText || isTyping) return;

    if (isListening) { recognitionRef.current?.stop(); setIsListening(false); }

    const activeUseInternet = useInternet;
    setInputValue('');
    
    // Build the query fed to the model (typed + OCR context if available)
    const queryForModel = ocrText
      ? `${userTypedText}\n\n[Additional context extracted from an attached image]:\n${ocrText}`
      : userTypedText;

    clearImage();

    // Show only what the user typed in the chat
    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: userTypedText,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);

    try {
      const response = await onSendMessage(queryForModel, activeUseInternet);
      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: response.answer,
          timestamp: new Date(),
          isSafe: response.safe,
          source: response.source,
        },
      ]);
    } catch {
      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: 'Sorry, I encountered an error. Please try again.',
          timestamp: new Date(),
          isSafe: false,
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  // ------------------------------------------------------------------
  // Render
  // ------------------------------------------------------------------
  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto bg-white shadow-xl rounded-3xl overflow-hidden border border-slate-200">

      {/* ── Header ─────────────────────────────────────────────────── */}
      <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-lg shadow-blue-200">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-800">Policy Guard Assistant</h3>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 bg-green-500 rounded-full" />
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">System Online</span>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {isListening && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex items-center gap-2 px-3 py-1.5 bg-red-50 border border-red-200 rounded-full"
            >
              <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <span className="text-xs font-semibold text-red-600">Listening…</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Messages ───────────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto p-6 space-y-2">
        {messages.map(msg => <ChatMessage key={msg.id} message={msg} />)}
        {isTyping && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex justify-start mb-6">
            <div className="bg-white border border-slate-200 text-slate-400 px-5 py-3 rounded-2xl rounded-tl-none flex items-center gap-2 shadow-sm">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-sm">Analyzing policy documents…</span>
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* ── Input Area ─────────────────────────────────────────────── */}
      <div className="p-6 border-t border-slate-200 bg-white space-y-2">

        {/* Image attachment pill — shows status but never exposes OCR text */}
        <AnimatePresence>
          {imageName && (
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 6 }}
              className="flex items-center gap-2 self-start px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-full w-fit"
            >
              <ImageIcon className="w-3.5 h-3.5 text-blue-500 shrink-0" />
              <span className="text-xs font-medium text-blue-700 max-w-[200px] truncate">{imageName}</span>

              {isOcring ? (
                <Loader2 className="w-3 h-3 text-blue-400 animate-spin shrink-0" />
              ) : (
                <span className="text-[10px] text-blue-400 font-semibold shrink-0">
                  {ocrText ? '✓ Ready' : '— No text'}
                </span>
              )}

              <button onClick={clearImage} className="ml-1 text-blue-300 hover:text-blue-600 transition-colors">
                <X className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Input row */}
        <form onSubmit={handleSubmit} className="flex items-center gap-2">

          {/* Hidden file input */}
          <input
            ref={imageInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleImageSelect}
          />

          {/* Image button */}
          <button
            type="button"
            onClick={() => imageInputRef.current?.click()}
            disabled={isTyping}
            title="Attach image — text will be read automatically"
            className={`shrink-0 p-3 rounded-xl transition-all border ${
              imageName
                ? 'bg-blue-50 border-blue-200 text-blue-600'
                : 'bg-slate-100 border-transparent text-slate-400 hover:text-blue-500 hover:bg-blue-50'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            <ImagePlus className="w-5 h-5" />
          </button>

          {/* Web search button */}
          <button
            type="button"
            onClick={() => setUseInternet(!useInternet)}
            disabled={isTyping}
            title={useInternet ? 'Internet search active' : 'Enable internet search'}
            className={`shrink-0 p-3 rounded-xl transition-all border ${
              useInternet
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-200 border-blue-600'
                : 'bg-slate-100 border-transparent text-slate-400 hover:text-blue-500 hover:bg-blue-50'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            <Globe className="w-5 h-5" />
          </button>

          {/* Text input */}
          <input
            type="text"
            value={inputValue}
            onChange={e => setInputValue(e.target.value)}
            placeholder={isListening ? 'Listening… speak now' : 'Ask about your coverage, exclusions, or limits…'}
            className={`flex-1 rounded-2xl px-6 py-4 text-sm transition-all focus:outline-none focus:ring-2 ${
              isListening
                ? 'bg-red-50 border border-red-200 text-red-800 focus:ring-red-300'
                : 'bg-slate-100 border-transparent focus:ring-blue-500'
            }`}
            disabled={isTyping}
          />

          {/* Voice button */}
          {voiceSupported && (
            <button
              type="button"
              onClick={toggleVoice}
              disabled={isTyping}
              title={isListening ? 'Stop recording' : 'Voice input'}
              className={`shrink-0 p-3 rounded-xl transition-all ${
                isListening
                  ? 'bg-red-500 text-white shadow-lg shadow-red-200 animate-pulse'
                  : 'bg-slate-100 text-slate-400 hover:bg-blue-50 hover:text-blue-500'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
          )}

          {/* Send */}
          <button
            type="submit"
            disabled={!inputValue.trim() || isTyping || isOcring}
            className="shrink-0 p-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-all shadow-lg shadow-blue-200"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>

        <p className="text-center text-[10px] text-slate-400">
          AI-generated responses should be verified against official policy documents.
        </p>
      </div>
    </div>
  );
};

export default ChatInterface;
