import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FileText, MessageSquare, ShieldCheck, UploadCloud } from 'lucide-react';
import StatsCard from './StatsCard';
import UploadZone from './UploadZone';
import { View } from '../../types';
import { cn } from '../../lib/utils';

interface DashboardProps {
  view: View;
  isUploading: boolean;
  onUpload: (file: File, extractedText?: string) => Promise<void>;
  userName: string;
  documentCount: number;  // passed from App.tsx (localStorage-based), avoids ChromaDB count mismatch
}

interface DashboardStats {
  totalDocuments: number;
  totalQueries: number;
  systemHealth: string;
  recentActivity: any[];
}

const API_BASE_URL = 'http://localhost:8000';

const Dashboard: React.FC<DashboardProps> = ({ isUploading, onUpload, userName, documentCount }) => {
  const [stats, setStats] = useState<DashboardStats>({
    totalDocuments: 0,
    totalQueries: 0,
    systemHealth: '100%',
    recentActivity: []
  });

  useEffect(() => {
    fetchDashboardStats();
    // Refresh stats every 10 seconds to sync with backend
    const interval = setInterval(fetchDashboardStats, 10000);
    return () => clearInterval(interval);
  }, [documentCount]); // re-run when documentCount changes

  const fetchDashboardStats = async () => {
    try {
      // Use documentCount prop as source of truth (from App.tsx localStorage)
      // instead of fetching from ChromaDB (which may be 0 if embeddings are unavailable)
      const totalDocuments = documentCount;

      // Get health status
      const healthResponse = await fetch(`${API_BASE_URL}/health/`);
      const healthData = await healthResponse.json();

      // Get query count from localStorage
      const savedMessages = localStorage.getItem('chatMessages');
      const messages = savedMessages ? JSON.parse(savedMessages) : [];
      const userMessages = messages.filter((m: any) => m.role === 'user').length;

      // Determine system health based on backend response
      const isHealthy = healthData.status === 'ok' &&
                       healthData.external_llm === 'healthy' &&
                       healthData.embeddings === 'healthy' &&
                       healthData.chroma_db === 'healthy';
      const healthScore = isHealthy ? '99.9%' : '85%';

      // Generate recent activity
      const recentActivity = generateRecentActivity(totalDocuments, userMessages);

      setStats({
        totalDocuments,
        totalQueries: userMessages,
        systemHealth: healthScore,
        recentActivity
      });
    } catch (error) {
      console.error('Failed to fetch dashboard stats:', error);
      const savedMessages = localStorage.getItem('chatMessages');
      const messages = savedMessages ? JSON.parse(savedMessages) : [];
      const userMessages = messages.filter((m: any) => m.role === 'user').length;

      setStats({
        totalDocuments: documentCount,
        totalQueries: userMessages,
        systemHealth: '85%',
        recentActivity: generateRecentActivity(documentCount, userMessages)
      });
    }
  };

  const generateRecentActivity = (docCount: number, queryCount: number) => {
    const activities = [];
    
    if (docCount > 0) {
      activities.push({
        type: 'upload',
        text: `${docCount} document${docCount > 1 ? 's' : ''} indexed`,
        time: 'recently',
        icon: FileText,
        color: 'text-blue-600',
        bg: 'bg-blue-50'
      });
    }
    
    if (queryCount > 0) {
      activities.push({
        type: 'query',
        text: `${queryCount} AI quer${queryCount > 1 ? 'ies' : 'y'} processed`,
        time: 'in this session',
        icon: MessageSquare,
        color: 'text-purple-600',
        bg: 'bg-purple-50'
      });
    }
    
    activities.push({
      type: 'system',
      text: 'System Status: Healthy',
      time: 'now',
      icon: ShieldCheck,
      color: 'text-green-600',
      bg: 'bg-green-50'
    });

    return activities;
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Welcome Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Welcome back, {userName}!</h2>
          <p className="text-slate-500 mt-1">Here's what's happening with your insurance knowledge base today.</p>
        </div>

      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatsCard 
          label="Total Documents" 
          value={stats.totalDocuments} 
          trend={stats.totalDocuments > 0 ? `+${stats.totalDocuments}` : 'None yet'} 
          trendUp={stats.totalDocuments > 0}
          icon={<FileText className="w-6 h-6" />} 
        />
        <StatsCard 
          label="AI Queries" 
          value={stats.totalQueries} 
          trend={stats.totalQueries > 0 ? `+${Math.floor(stats.totalQueries * 0.1)}%` : 'No queries'} 
          trendUp={stats.totalQueries > 0}
          icon={<MessageSquare className="w-6 h-6" />} 
        />
        <StatsCard 
          label="System Health" 
          value={stats.systemHealth} 
          icon={<ShieldCheck className="w-6 h-6" />} 
        />
      </div>

      {/* Main Content Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Upload Area */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2 space-y-6"
        >
          <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-blue-50 rounded-lg text-blue-600">
                <UploadCloud className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-slate-800">Index New Policy</h3>
            </div>
            <UploadZone onUpload={onUpload} isUploading={isUploading} />
          </div>


        </motion.div>

        {/* Right: Recent Activity */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-6"
        >
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-slate-800 mb-6">Recent Activity</h3>
            <div className="space-y-6">
              {stats.recentActivity.length > 0 ? (
                stats.recentActivity.map((item, idx) => (
                  <div key={idx} className="flex gap-4">
                    <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", item.bg, item.color)}>
                      <item.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-800">{item.text}</p>
                      <p className="text-xs text-slate-400 mt-1">{item.time}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-sm text-slate-400">No activity yet. Start by uploading a document!</p>
                </div>
              )}
            </div>
            <button className="w-full mt-8 text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors">
              View All Activity
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;
