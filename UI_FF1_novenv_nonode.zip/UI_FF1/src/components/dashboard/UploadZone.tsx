import React, { useCallback, useState } from 'react';
import { Upload, FileText, CheckCircle2, AlertCircle, ImageIcon, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { createWorker } from 'tesseract.js';
import { cn } from '../../lib/utils';

interface UploadZoneProps {
  onUpload: (file: File, extractedText?: string) => Promise<void>;
  isUploading: boolean;
}

const UploadZone: React.FC<UploadZoneProps> = ({ onUpload, isUploading }) => {
  const [dragActive, setDragActive] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error' | 'ocr'>('idle');
  const [message, setMessage] = useState('');

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      await handleFileProcess(file);
    }
  }, []);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      await handleFileProcess(e.target.files[0]);
    }
  };

  const handleFileProcess = async (file: File) => {
    const isImage = file.type.startsWith('image/');
    const isPdf = file.type === 'application/pdf' || file.name.endsWith('.pdf');
    const isTxt = file.type === 'text/plain' || file.name.endsWith('.txt');

    if (!isPdf && !isTxt && !isImage) {
      setStatus('error');
      setMessage('Please upload a PDF, Text file, or Image.');
      return;
    }

    try {
      setStatus('idle');
      let extractedText = undefined;

      if (isImage) {
        setStatus('ocr');
        setMessage('Processing image text (OCR)...');
        try {
          const worker = await createWorker('eng');
          const { data: { text } } = await worker.recognize(file);
          await worker.terminate();
          extractedText = text.trim();
          if (!extractedText) {
            console.warn('No text found in image');
          }
        } catch (ocrErr) {
          console.error('OCR failed:', ocrErr);
          // Still proceed with upload if OCR fails? 
          // Usually better to warn, but we'll try to index what we have.
        }
      }

      setStatus('idle');
      await onUpload(file, extractedText);
      setStatus('success');
      setMessage(`Successfully indexed ${file.name}`);
      setTimeout(() => setStatus('idle'), 5000);
    } catch (err) {
      setStatus('error');
      setMessage('Failed to upload file. Please try again.');
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={cn(
          "relative border-2 border-dashed rounded-3xl p-12 transition-all duration-300 flex flex-col items-center justify-center text-center",
          dragActive 
            ? "border-blue-500 bg-blue-50/50 scale-[1.02]" 
            : "border-slate-200 bg-white hover:border-blue-400 hover:bg-slate-50",
          (isUploading || status === 'ocr') && "opacity-50 cursor-not-allowed"
        )}
      >
        <input
          type="file"
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          onChange={handleFileChange}
          disabled={isUploading || status === 'ocr'}
          accept=".pdf,.txt,.png,.jpg,.jpeg"
        />

        <AnimatePresence mode="wait">
          {status === 'idle' || isUploading || status === 'ocr' ? (
            <motion.div
              key="idle"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col items-center"
            >
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 mb-6 relative">
                {status === 'ocr' || isUploading ? (
                  <Loader2 className="w-8 h-8 animate-spin" />
                ) : (
                  <Upload className="w-8 h-8" />
                )}
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                {status === 'ocr' ? 'Reading image text...' : isUploading ? 'Uploading document...' : 'Upload policy document'}
              </h3>
              <p className="text-slate-500 max-w-sm">
                Drag and drop your PDF, text file, or image here, or click to browse.
              </p>
              <div className="mt-6 flex gap-3 text-xs text-slate-400">
                <span className="flex items-center gap-1"><FileText className="w-3 h-3" /> PDF</span>
                <span className="flex items-center gap-1"><FileText className="w-3 h-3" /> TXT</span>
                <span className="flex items-center gap-1"><ImageIcon className="w-3 h-3" /> IMAGE</span>
              </div>
            </motion.div>
          ) : status === 'success' ? (
            <motion.div
              key="success"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex flex-col items-center"
            >
              <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center text-green-600 mb-6">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Success!</h3>
              <p className="text-slate-500">{message}</p>
            </motion.div>
          ) : (
            <motion.div
              key="error"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex flex-col items-center"
            >
              <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center text-red-600 mb-6">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Upload failed</h3>
              <p className="text-slate-500">{message}</p>
              <button 
                onClick={() => setStatus('idle')}
                className="mt-6 text-blue-600 font-medium hover:underline"
              >
                Try again
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default UploadZone;
