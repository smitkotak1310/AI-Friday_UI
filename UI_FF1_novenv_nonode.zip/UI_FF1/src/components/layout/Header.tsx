import React, { useState, useRef, useEffect } from 'react';
import { Search, User, LogOut, FileText, MessageSquare, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { View } from '../../types';
import { SESSION_KEY } from '../auth/LoginPage';

interface SearchResult {
  type: 'document' | 'chat';
  label: string;
  snippet: string;
  view: View;
}

interface HeaderProps {
  view: View;
  userName: string;
  onLogout: () => void;
  documents: { id: string; name: string }[];
  chatMessages: { role: string; content: string }[];
  onNavigate: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ view, userName, onLogout, documents, chatMessages, onNavigate }) => {
  const titles: Record<View, string> = {
    dashboard: 'Overview',
    chat: 'Policy Assistant',
    documents: 'Knowledge Base'
  };

  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [showResults, setShowResults] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (
        dropdownRef.current && !dropdownRef.current.contains(e.target as Node) &&
        inputRef.current && !inputRef.current.contains(e.target as Node)
      ) {
        setShowResults(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSearch = (q: string) => {
    setQuery(q);
    if (!q.trim()) { setResults([]); setShowResults(false); return; }

    const lower = q.toLowerCase();
    const found: SearchResult[] = [];

    // Search documents by name
    documents.forEach(doc => {
      if (doc.name.toLowerCase().includes(lower)) {
        found.push({
          type: 'document',
          label: doc.name,
          snippet: 'Document in Knowledge Base',
          view: 'documents'
        });
      }
    });

    // Search chat messages
    chatMessages.forEach(msg => {
      const content = (msg.content || '').toLowerCase();
      if (content.includes(lower)) {
        const idx = content.indexOf(lower);
        const start = Math.max(0, idx - 30);
        const raw = msg.content || '';
        const snippet = (start > 0 ? '…' : '') + raw.slice(start, start + 80) + (raw.length > start + 80 ? '…' : '');
        found.push({
          type: 'chat',
          label: msg.role === 'user' ? 'Your message' : 'Assistant reply',
          snippet,
          view: 'chat'
        });
      }
    });

    setResults(found.slice(0, 8)); // cap at 8
    setShowResults(true);
  };

  const handleSelect = (result: SearchResult) => {
    onNavigate(result.view);
    setQuery('');
    setResults([]);
    setShowResults(false);
  };

  const handleLogout = () => {
    localStorage.removeItem(SESSION_KEY);
    onLogout();
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-10">
      <h1 className="text-lg font-semibold text-slate-800">{titles[view]}</h1>

      <div className="flex items-center gap-4">
        {/* Search bar with dropdown */}
        <div className="relative hidden md:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => handleSearch(e.target.value)}
            onFocus={() => { if (results.length) setShowResults(true); }}
            placeholder="Search documents & chats…"
            className="pl-10 pr-8 py-2 bg-slate-100 border-none rounded-full text-sm focus:ring-2 focus:ring-blue-500 w-72 transition-all focus:outline-none"
          />
          {query && (
            <button
              onClick={() => { setQuery(''); setResults([]); setShowResults(false); }}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Dropdown results */}
          <AnimatePresence>
            {showResults && (
              <motion.div
                ref={dropdownRef}
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.15 }}
                className="absolute top-full mt-2 left-0 w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-50"
              >
                {results.length === 0 ? (
                  <div className="px-5 py-4 text-sm text-slate-400 text-center">No results for "{query}"</div>
                ) : (
                  <div className="py-2">
                    {/* Group by type */}
                    {(['document', 'chat'] as const).map(type => {
                      const group = results.filter(r => r.type === type);
                      if (!group.length) return null;
                      return (
                        <div key={type}>
                          <div className="px-4 py-1.5 text-xs font-bold text-slate-400 uppercase tracking-wider bg-slate-50">
                            {type === 'document' ? '📄 Documents' : '💬 Chat History'}
                          </div>
                          {group.map((result, i) => (
                            <button
                              key={i}
                              onClick={() => handleSelect(result)}
                              className="w-full flex items-start gap-3 px-4 py-3 hover:bg-blue-50 transition-colors text-left group"
                            >
                              <div className="mt-0.5 w-7 h-7 rounded-lg flex items-center justify-center bg-slate-100 group-hover:bg-blue-100 shrink-0">
                                {result.type === 'document'
                                  ? <FileText className="w-4 h-4 text-blue-500" />
                                  : <MessageSquare className="w-4 h-4 text-purple-500" />
                                }
                              </div>
                              <div className="min-w-0">
                                <p className="text-sm font-semibold text-slate-700 truncate">{result.label}</p>
                                <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">{result.snippet}</p>
                              </div>
                            </button>
                          ))}
                        </div>
                      );
                    })}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>



        <div className="h-8 w-[1px] bg-slate-200 mx-2"></div>

        <div className="flex items-center gap-2 p-1 pr-3 bg-slate-50 rounded-full border border-slate-200">
          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
            <User className="w-5 h-5" />
          </div>
          <span className="text-sm font-medium text-slate-700 hidden sm:block">{userName}</span>
        </div>

        <button
          onClick={handleLogout}
          title="Logout"
          className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
        >
          <LogOut className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};

export default Header;
