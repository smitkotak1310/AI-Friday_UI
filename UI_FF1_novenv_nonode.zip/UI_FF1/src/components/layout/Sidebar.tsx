import React from 'react';
import { LayoutDashboard, MessageSquare, FileText, ShieldCheck, Settings } from 'lucide-react';
import { cn } from '../../lib/utils';
import { View } from '../../types';

interface SidebarProps {
  activeView: View;
  setActiveView: (view: View) => void;
  onSettingsOpen: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, onSettingsOpen }) => {
  const menuItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'chat', icon: MessageSquare, label: 'AI Assistant' },
    { id: 'documents', icon: FileText, label: 'Documents' },
  ] as const;

  return (
    <div className="h-full w-64 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
          <ShieldCheck className="text-white w-5 h-5" />
        </div>
        <span className="text-xl font-bold text-white tracking-tight">InsureAI</span>
      </div>

      <nav className="flex-1 px-4 space-y-2 mt-4">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id as View)}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
              activeView === item.id
                ? "bg-blue-600 text-white shadow-lg shadow-blue-900/20"
                : "hover:bg-slate-800 hover:text-white"
            )}
          >
            <item.icon className={cn(
              "w-5 h-5 transition-colors",
              activeView === item.id ? "text-white" : "text-slate-400 group-hover:text-white"
            )} />
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      {/* Bottom: Settings */}
      <div className="p-4 border-t border-slate-800">
        <button
          onClick={onSettingsOpen}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-slate-800 transition-colors text-slate-400 hover:text-white"
        >
          <Settings className="w-5 h-5" />
          <span className="font-medium">Settings</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
