import React from 'react';
import axios, { AxiosInstance } from 'axios';

/**
 * Frontend Integration Guide for Multimodal AI Backend
 * This file shows how to integrate the React frontend with the FastAPI backend
 */

// API Configuration
const API_BASE_URL = 'http://localhost:8000';

interface ChatRequest {
  message: string;
  model: 'deepseek' | 'llama' | 'gemma' | 'qwen';
  history?: Array<{ role: string; content: string }>;
}

interface ReasonRequest {
  task: string;
  model: 'deepseek';
  context?: string;
}

interface EmbedRequest {
  text: string;
  model: 'openai' | 'gte';
}

interface APIResponse {
  success?: boolean;
  error?: boolean;
  message?: string;
  [key: string]: any;
}

// Initialize Axios client
const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// ============================================
// API Service Functions
// ============================================

/**
 * Check backend health
 */
export const checkHealth = async (): Promise<boolean> => {
  try {
    const response = await apiClient.get('/health/');
    return response.status === 200;
  } catch (error) {
    console.error('Health check failed:', error);
    return false;
  }
};

/**
 * Get available models
 */
export const getAvailableModels = async () => {
  try {
    const response = await apiClient.get('/models/');
    return response.data;
  } catch (error) {
    console.error('Failed to fetch models:', error);
    throw error;
  }
};

/**
 * Chat with selected model
 */
export const sendChatMessage = async (request: ChatRequest): Promise<APIResponse> => {
  try {
    const response = await apiClient.post('/chat/', request);
    return response.data;
  } catch (error) {
    console.error('Chat request failed:', error);
    return {
      error: true,
      message: 'Failed to send message',
    };
  }
};

/**
 * Send reasoning task
 */
export const sendReasoningTask = async (request: ReasonRequest): Promise<APIResponse> => {
  try {
    const response = await apiClient.post('/reason/', request);
    return response.data;
  } catch (error) {
    console.error('Reasoning request failed:', error);
    return {
      error: true,
      message: 'Failed to process reasoning task',
    };
  }
};

/**
 * Generate embeddings
 */
export const generateEmbedding = async (request: EmbedRequest): Promise<APIResponse> => {
  try {
    const response = await apiClient.post('/embed/', request);
    return response.data;
  } catch (error) {
    console.error('Embedding request failed:', error);
    return {
      error: true,
      message: 'Failed to generate embedding',
    };
  }
};

// ============================================
// React Hook Examples
// ============================================

/**
 * Example React Hook for Chat
 * Usage in components:
 * 
 * const { response, loading, error, sendMessage } = useChat();
 * 
 * <input value={message} onChange={e => setMessage(e.target.value)} />
 * <button onClick={() => sendMessage(message, 'deepseek')}>Send</button>
 * {loading && <p>Loading...</p>}
 * {response && <p>{response}</p>}
 */
export const useChat = () => {
  const [response, setResponse] = React.useState<string>('');
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const sendMessage = async (message: string, model: 'deepseek' | 'llama' | 'gemma' | 'qwen') => {
    setLoading(true);
    setError(null);

    try {
      const result = await sendChatMessage({ message, model });
      
      if (result.error) {
        setError(result.message || 'An error occurred');
      } else {
        setResponse(result.response);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to send message');
    } finally {
      setLoading(false);
    }
  };

  return { response, loading, error, sendMessage };
};

/**
 * Example React Hook for Embeddings
 * Usage in components:
 * 
 * const { embedding, loading, generateEmbed } = useEmbedding();
 */
export const useEmbedding = () => {
  const [embedding, setEmbedding] = React.useState<number[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const generateEmbed = async (text: string, model: 'openai' | 'gte' = 'openai') => {
    setLoading(true);
    setError(null);

    try {
      const result = await generateEmbedding({ text, model });
      
      if (result.error) {
        setError(result.message || 'An error occurred');
      } else {
        setEmbedding(result.embedding);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to generate embedding');
    } finally {
      setLoading(false);
    }
  };

  return { embedding, loading, error, generateEmbed };
};

// ============================================
// Integration in App.tsx
// ============================================

/**
 * Example usage in App.tsx:
 * 
 * import { sendChatMessage, checkHealth } from './api/backend';
 * 
 * function App() {
 *   const [backendReady, setBackendReady] = React.useState(false);
 * 
 *   React.useEffect(() => {
 *     checkHealth().then(setBackendReady);
 *   }, []);
 * 
 *   const handleSendMessage = async (question: string) => {
 *     const response = await sendChatMessage({
 *       message: question,
 *       model: 'deepseek'
 *     });
 *     return response;
 *   };
 * 
 *   return (
 *     <div>
 *       {backendReady ? (
 *         <ChatInterface onSendMessage={handleSendMessage} />
 *       ) : (
 *         <p>Connecting to backend...</p>
 *       )}
 *     </div>
 *   );
 * }
 */

// ============================================
// Error Handling Examples
// ============================================

/**
 * Handle API errors gracefully
 */
export const handleAPIError = (error: any, context: string): string => {
  if (axios.isAxiosError(error)) {
    if (error.response?.status === 400) {
      return `Invalid request: ${error.response.data?.detail || 'Unknown error'}`;
    } else if (error.response?.status === 500) {
      return `Server error: ${error.response.data?.detail || 'Internal server error'}`;
    } else if (!error.response) {
      return 'Backend server is not responding. Please check if it is running on port 8000.';
    }
  }
  return `Error in ${context}: ${error.message}`;
};

/**
 * Retry logic for failed requests
 */
export const fetchWithRetry = async (
  fn: () => Promise<any>,
  maxRetries: number = 3,
  delay: number = 1000
): Promise<any> => {
  let lastError;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw lastError;
};

// ============================================
// WebSocket Connection (Optional for Real-time)
// ============================================

/**
 * For real-time streaming responses, consider using WebSockets:
 * 
 * export const connectWebSocket = () => {
 *   const ws = new WebSocket('ws://localhost:8000/ws');
 *   
 *   ws.onopen = () => console.log('WebSocket connected');
 *   ws.onmessage = (event) => console.log('Message:', event.data);
 *   ws.onerror = (error) => console.error('WebSocket error:', error);
 *   ws.onclose = () => console.log('WebSocket closed');
 *   
 *   return ws;
 * };
 */

export default {
  checkHealth,
  getAvailableModels,
  sendChatMessage,
  sendReasoningTask,
  generateEmbedding,
  handleAPIError,
  fetchWithRetry,
  useChat,
  useEmbedding,
};
