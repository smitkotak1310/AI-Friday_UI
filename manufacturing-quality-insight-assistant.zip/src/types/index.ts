export type Severity = 'Critical' | 'Major' | 'Minor' | 'Low';
export type Status = 'Open' | 'Investigating' | 'Resolved' | 'Closed';
export type IncidentType = 
  | 'Defect Spike'
  | 'Process Deviation'
  | 'Equipment Failure'
  | 'Material Anomaly'
  | 'Dimensional Out-of-Tolerance'
  | 'Surface Defect'
  | 'Electrical Failure'
  | 'Contamination'
  | 'Assembly Error'
  | 'Calibration Drift';

export interface PlantInfo {
  id: string;
  name: string;
  location: string;
}

export interface ProductionLine {
  id: string;
  name: string;
  plantId: string;
  productType: string;
}

export interface ProcessParameter {
  name: string;
  value: number;
  unit: string;
  lowerLimit: number;
  upperLimit: number;
  target: number;
}

export interface QualityMetric {
  metric: string;
  value: number;
  unit: string;
  threshold: number;
  breached: boolean;
}

export interface Incident {
  id: string;
  timestamp: string;
  plant: string;
  line: string;
  productType: string;
  incidentType: IncidentType;
  severity: Severity;
  status: Status;
  description: string;
  defectCount: number;
  defectRate: number;
  batchId: string;
  operator: string;
  processParameters: ProcessParameter[];
  qualityMetrics: QualityMetric[];
  suspectedCauses?: string[];
  rootCause?: string;
  correctiveAction?: string;
  resolutionTime?: number;
}

export interface RootCauseAnalysis {
  incidentId: string;
  confidence: number;
  primaryCause: string;
  contributingFactors: string[];
  severityAssessment: string;
  recommendedActions: string[];
  estimatedImpact: string;
  preventionMeasures: string[];
  analysisDetails: string;
  relatedIncidents: string[];
  priority: 'Immediate' | 'High' | 'Medium' | 'Low';
}

export interface DashboardStats {
  totalIncidents: number;
  openIncidents: number;
  avgResolutionTime: number;
  criticalIncidents: number;
  topDefectType: string;
  mostAffectedLine: string;
  defectTrend: number[];
  monthlyCounts: { month: string; count: number }[];
  severityDistribution: { name: Severity; value: number }[];
  linePerformance: { line: string; defectRate: number }[];
  plantDistribution: { plant: string; incidents: number }[];
}

export const PLANTS: PlantInfo[] = [
  { id: 'P001', name: 'Detroit Assembly Plant', location: 'Detroit, MI' },
  { id: 'P002', name: 'Chicago Precision Mfg', location: 'Chicago, IL' },
  { id: 'P003', name: 'Houston Industrial Works', location: 'Houston, TX' },
  { id: 'P004', name: 'Portland Electronics Fab', location: 'Portland, OR' },
];

export const LINES: ProductionLine[] = [
  { id: 'L01', name: 'Line A - Primary Assembly', plantId: 'P001', productType: 'Automotive Parts' },
  { id: 'L02', name: 'Line B - Secondary Assembly', plantId: 'P001', productType: 'Automotive Parts' },
  { id: 'L03', name: 'Line C - CNC Machining', plantId: 'P002', productType: 'Precision Components' },
  { id: 'L04', name: 'Line D - Injection Molding', plantId: 'P002', productType: 'Plastic Components' },
  { id: 'L05', name: 'Line E - Welding Station', plantId: 'P003', productType: 'Structural Steel' },
  { id: 'L06', name: 'Line F - Coating Line', plantId: 'P003', productType: 'Surface Treatment' },
  { id: 'L07', name: 'Line G - PCB Assembly', plantId: 'P004', productType: 'Electronic Boards' },
  { id: 'L08', name: 'Line H - Testing Station', plantId: 'P004', productType: 'Electronic Testing' },
];

export const INCIDENT_TYPES: IncidentType[] = [
  'Defect Spike',
  'Process Deviation',
  'Equipment Failure',
  'Material Anomaly',
  'Dimensional Out-of-Tolerance',
  'Surface Defect',
  'Electrical Failure',
  'Contamination',
  'Assembly Error',
  'Calibration Drift',
];

export const SEVERITY_LEVELS: Severity[] = ['Critical', 'Major', 'Minor', 'Low'];

// ===== Chatbot Types =====
export type LLMModel = 'gpt4' | 'claude3' | 'gemini' | 'llama3' | 'mistral';

export interface LLMInfo {
  id: LLMModel;
  name: string;
  provider: string;
  avatar: string;
  color: string;
  description: string;
  baseAccuracy: number;
  baseConfidence: number;
  tokenSpeed: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  model?: LLMModel;
  accuracyScore?: number;
  confidenceScore?: number;
  tokensUsed?: number;
  responseTime?: number;
  sources?: string[];
  isStreaming?: boolean;
  reasoningSteps?: string[];
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: Date;
  lastActive: Date;
  model: LLMModel;
}

export interface LLMResponse {
  content: string;
  accuracyScore: number;
  confidenceScore: number;
  tokensUsed: number;
  responseTime: number;
  sources: string[];
  reasoningSteps: string[];
}
