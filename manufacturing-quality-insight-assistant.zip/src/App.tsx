import { useState, useMemo, useEffect } from 'react';
import { INCIDENTS } from './data/syntheticData';
import { Incident, RootCauseAnalysis, DashboardStats } from './types';
import { analyzeIncident } from './engine/rootCauseAnalysis';
import { Sidebar } from './components/Sidebar';
import { DashboardHeader } from './components/DashboardHeader';
import { DashboardCharts } from './components/DashboardCharts';
import { IncidentForm } from './components/IncidentForm';
import { AnalysisResult } from './components/AnalysisResult';
import { IncidentHistory } from './components/IncidentHistory';
import { AnalyticsView } from './components/AnalyticsView';
import { DocumentationView } from './components/DocumentationView';
import { ChatbotView } from './components/ChatbotView';
import { Loader2, Sparkles } from 'lucide-react';

type ViewType = 'dashboard' | 'incident' | 'analysis' | 'history' | 'analytics' | 'documentation' | 'chatbot';

// Pre-compute analyses for all incidents
const PRECOMPUTED_ANALYSES: Record<string, RootCauseAnalysis> = {};
INCIDENTS.forEach(inc => {
  PRECOMPUTED_ANALYSES[inc.id] = analyzeIncident(inc);
});

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [incidents] = useState<Incident[]>(INCIDENTS);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [newAnalysis, setNewAnalysis] = useState<{ incident: Incident; analysis: RootCauseAnalysis } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const dashboardStats = useMemo((): DashboardStats => {
    const totalIncidents = incidents.length;
    const openIncidents = incidents.filter(i => i.status === 'Open' || i.status === 'Investigating').length;
    const resolvedIncidents = incidents.filter(i => i.resolutionTime);
    const avgResolutionTime = resolvedIncidents.length > 0 
      ? Math.round(resolvedIncidents.reduce((sum, i) => sum + (i.resolutionTime || 0), 0) / resolvedIncidents.length)
      : 0;
    const criticalIncidents = incidents.filter(i => i.severity === 'Critical').length;

    const typeCounts: Record<string, number> = {};
    const lineCounts: Record<string, number> = {};
    const severityDist: Record<string, number> = { Critical: 0, Major: 0, Minor: 0, Low: 0 };
    const lineDefectRates: Record<string, number[]> = {};
    const plantCounts: Record<string, number> = {};
    const monthlyCounts: Record<string, number> = {};

    incidents.forEach(inc => {
      typeCounts[inc.incidentType] = (typeCounts[inc.incidentType] || 0) + 1;
      lineCounts[inc.line] = (lineCounts[inc.line] || 0) + 1;
      severityDist[inc.severity]++;
      
      if (!lineDefectRates[inc.line]) lineDefectRates[inc.line] = [];
      lineDefectRates[inc.line].push(inc.defectRate);
      
      plantCounts[inc.plant] = (plantCounts[inc.plant] || 0) + 1;
      
      const month = inc.timestamp.substring(0, 7);
      monthlyCounts[month] = (monthlyCounts[month] || 0) + 1;
    });

    const topDefectType = Object.entries(typeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';
    const mostAffectedLine = Object.entries(lineCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    const severityDistribution = [
      { name: 'Critical' as const, value: severityDist.Critical },
      { name: 'Major' as const, value: severityDist.Major },
      { name: 'Minor' as const, value: severityDist.Minor },
      { name: 'Low' as const, value: severityDist.Low },
    ];

    const linePerformance = Object.entries(lineDefectRates).map(([line, rates]) => ({
      line,
      defectRate: +(rates.reduce((a, b) => a + b, 0) / rates.length).toFixed(2),
    }));

    const plantDistribution = Object.entries(plantCounts).map(([plant, incidents]) => ({
      plant: plant.replace(' Plant', '').replace(' Mfg', '').replace(' Works', '').replace(' Fab', ''),
      incidents,
    }));

    const sortedMonths = Object.entries(monthlyCounts).sort(([a], [b]) => a.localeCompare(b));
    const monthlyData = sortedMonths.map(([month, count]) => ({
      month: new Date(month + '-01').toLocaleDateString('en', { month: 'short', year: '2-digit' }),
      count,
    }));

    const defectTrend = sortedMonths.map(([, count]) => count);

    return {
      totalIncidents, openIncidents, avgResolutionTime, criticalIncidents,
      topDefectType, mostAffectedLine, defectTrend,
      monthlyCounts: monthlyData,
      severityDistribution, linePerformance, plantDistribution,
    };
  }, [incidents]);

  const handleIncidentSubmit = (incident: Incident, analysis: RootCauseAnalysis) => {
    setNewAnalysis({ incident, analysis });
    setCurrentView('analysis');
  };

  const handleViewAnalysis = (incident: Incident) => {
    setSelectedIncident(incident);
    setCurrentView('analysis');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Sparkles size={32} className="text-white" />
          </div>
          <div className="flex items-center gap-2 text-slate-600">
            <Loader2 size={20} className="animate-spin" />
            <span className="text-sm font-medium">Loading QualityIQ...</span>
          </div>
        </div>
      </div>
    );
  }

  const openIncidents = incidents.filter(i => i.status === 'Open' || i.status === 'Investigating').length;

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <>
            <DashboardHeader stats={dashboardStats} />
            <DashboardCharts stats={dashboardStats} />
          </>
        );
      case 'incident':
        return <IncidentForm onSubmit={handleIncidentSubmit} />;
      case 'analysis':
        if (newAnalysis) {
          return (
            <AnalysisResult incident={newAnalysis.incident} analysis={newAnalysis.analysis} />
          );
        }
        if (selectedIncident && PRECOMPUTED_ANALYSES[selectedIncident.id]) {
          return (
            <AnalysisResult incident={selectedIncident} analysis={PRECOMPUTED_ANALYSES[selectedIncident.id]} />
          );
        }
        return (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-20 h-20 bg-blue-50 rounded-2xl flex items-center justify-center mb-4">
              <Sparkles size={36} className="text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">No Analysis Selected</h3>
            <p className="text-sm text-slate-500 max-w-md mb-6">
              Report a new incident or select an existing incident from the history to view its root cause analysis.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setCurrentView('incident')}
                className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700"
              >
                Report Incident
              </button>
              <button
                onClick={() => setCurrentView('history')}
                className="px-5 py-2.5 border border-slate-300 text-slate-700 rounded-xl text-sm font-medium hover:bg-slate-50"
              >
                Browse History
              </button>
            </div>
          </div>
        );
      case 'history':
        return <IncidentHistory incidents={incidents} onViewAnalysis={handleViewAnalysis} />;
      case 'analytics':
        return <AnalyticsView incidents={incidents} />;
      case 'chatbot':
        return <ChatbotView />;
      case 'documentation':
        return <DocumentationView />;
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <Sidebar
        currentView={currentView}
        onNavigate={(view) => {
          setCurrentView(view);
        }}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
        openIncidents={openIncidents}
      />
      <main className="flex-1 overflow-y-auto">
        {/* Top Bar */}
        <div className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs text-slate-500">System Online — {new Date().toLocaleDateString('en', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-xs font-medium text-slate-900">Quality Engineer</p>
              <p className="text-[10px] text-slate-500">Manufacturing Ops</p>
            </div>
            <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center text-xs font-bold text-slate-600">
              QE
            </div>
          </div>
        </div>

        <div className="p-6 max-w-[1600px] mx-auto">
          {renderView()}
        </div>
      </main>
    </div>
  );
}
