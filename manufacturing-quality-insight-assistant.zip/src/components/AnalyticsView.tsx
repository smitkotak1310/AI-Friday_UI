import { useMemo } from 'react';
import { Incident } from '../types';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Cell, AreaChart, Area, RadarChart, Radar, PolarGrid, PolarAngleAxis, Legend
} from 'recharts';
import { TrendingUp, AlertTriangle, Clock, Target } from 'lucide-react';

interface AnalyticsViewProps {
  incidents: Incident[];
}

const COLORS = ['#3b82f6', '#8b5cf6', '#ef4444', '#f59e0b', '#22c55e', '#06b6d4', '#ec4899', '#f97316', '#6366f1', '#14b8a6'];

export function AnalyticsView({ incidents }: AnalyticsViewProps) {
  const typeDistribution = useMemo(() => {
    const counts: Record<string, number> = {};
    incidents.forEach(inc => { counts[inc.incidentType] = (counts[inc.incidentType] || 0) + 1; });
    return Object.entries(counts).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [incidents]);

  const severityByType = useMemo(() => {
    const data: Record<string, Record<string, number>> = {};
    incidents.forEach(inc => {
      if (!data[inc.incidentType]) data[inc.incidentType] = { Critical: 0, Major: 0, Minor: 0, Low: 0 };
      data[inc.incidentType][inc.severity]++;
    });
    return Object.entries(data).map(([name, values]) => ({ name, ...values }));
  }, [incidents]);

  const resolutionTime = useMemo(() => {
    return incidents
      .filter(inc => inc.resolutionTime)
      .map(inc => ({ id: inc.id, time: inc.resolutionTime!, severity: inc.severity }))
      .sort((a, b) => b.time - a.time)
      .slice(0, 15);
  }, [incidents]);

  const defectRateTrend = useMemo(() => {
    const sorted = [...incidents].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    const monthly: Record<string, number[]> = {};
    sorted.forEach(inc => {
      const month = inc.timestamp.substring(0, 7);
      if (!monthly[month]) monthly[month] = [];
      monthly[month].push(inc.defectRate);
    });
    return Object.entries(monthly).map(([month, rates]) => ({
      month,
      avgDefectRate: +(rates.reduce((a, b) => a + b, 0) / rates.length).toFixed(2),
      incidents: rates.length,
    }));
  }, [incidents]);

  const topDefects = useMemo(() => {
    const counts: Record<string, number> = {};
    incidents.forEach(inc => { counts[inc.incidentType] = (counts[inc.incidentType] || 0) + 1; });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, value]) => ({ name, incidents: value }));
  }, [incidents]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Quality Analytics</h2>
        <p className="text-sm text-slate-500 mt-1">Deep-dive analysis of quality trends and patterns</p>
      </div>

      {/* Top Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Incident Types"
          value={typeDistribution.length}
          icon={<Target size={20} />}
          subtitle="distinct categories"
        />
        <MetricCard
          title="Total Defects"
          value={incidents.reduce((sum, inc) => sum + inc.defectCount, 0).toLocaleString()}
          icon={<AlertTriangle size={20} />}
          subtitle="across all incidents"
        />
        <MetricCard
          title="Avg Defect Rate"
          value={`${(incidents.reduce((sum, inc) => sum + inc.defectRate, 0) / incidents.length).toFixed(1)}%`}
          icon={<TrendingUp size={20} />}
          subtitle="per incident"
        />
        <MetricCard
          title="Avg Resolution"
          value={`${(incidents.filter(i => i.resolutionTime).reduce((sum, i) => sum + (i.resolutionTime || 0), 0) / incidents.filter(i => i.resolutionTime).length).toFixed(0)}h`}
          icon={<Clock size={20} />}
          subtitle="resolved incidents"
        />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Defect Rate Trend */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="text-sm font-semibold text-slate-900 mb-4">Monthly Defect Rate Trend</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={defectRateTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
              <Area type="monotone" dataKey="avgDefectRate" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.15} strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Incident Type Distribution */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="text-sm font-semibold text-slate-900 mb-4">Incidents by Type</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={typeDistribution}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} stroke="#94a3b8" angle={-45} textAnchor="end" height={80} />
              <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {typeDistribution.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Severity by Type */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="text-sm font-semibold text-slate-900 mb-4">Severity Distribution by Type</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={severityByType} stackOffset="expand">
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} stroke="#94a3b8" angle={-45} textAnchor="end" height={80} />
              <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
              <Legend wrapperStyle={{ fontSize: '11px' }} />
              <Bar dataKey="Critical" stackId="a" fill="#ef4444" />
              <Bar dataKey="Major" stackId="a" fill="#f59e0b" />
              <Bar dataKey="Minor" stackId="a" fill="#3b82f6" />
              <Bar dataKey="Low" stackId="a" fill="#22c55e" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Resolution Time */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="text-sm font-semibold text-slate-900 mb-4">Resolution Time (Top 15)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={resolutionTime} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis type="number" tick={{ fontSize: 11 }} stroke="#94a3b8" unit="h" />
              <YAxis dataKey="id" type="category" tick={{ fontSize: 10 }} stroke="#94a3b8" width={70} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
              <Bar dataKey="time" radius={[0, 4, 4, 0]}>
                {resolutionTime.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Defect Radar */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="text-sm font-semibold text-slate-900 mb-4">Incident Pattern Analysis</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={topDefects}>
              <PolarGrid />
              <PolarAngleAxis dataKey="name" tick={{ fontSize: 10 }} />
              <Radar name="Incidents" dataKey="incidents" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} />
            </RadarChart>
          </ResponsiveContainer>

          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-slate-900">Key Insights</h4>
            <div className="space-y-3">
              {topDefects.map((d, idx) => (
                <div key={d.name} className="flex items-center gap-3">
                  <span className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-bold">{idx + 1}</span>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm text-slate-700">{d.name}</span>
                      <span className="text-sm font-semibold text-slate-900">{d.incidents}</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div 
                        className="bg-blue-500 h-2 rounded-full" 
                        style={{ width: `${(d.incidents / topDefects[0].incidents) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon, subtitle }: { title: string; value: string | number; icon: React.ReactNode; subtitle: string }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5">
      <div className="flex items-center justify-between mb-3">
        <p className="text-sm text-slate-500">{title}</p>
        <div className="w-9 h-9 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center">{icon}</div>
      </div>
      <p className="text-2xl font-bold text-slate-900">{value}</p>
      <p className="text-xs text-slate-400 mt-1">{subtitle}</p>
    </div>
  );
}
