import { useState } from 'react';
import { Incident, ProcessParameter, QualityMetric, IncidentType, Severity, PLANTS, LINES, INCIDENT_TYPES, SEVERITY_LEVELS } from '../types';
import { analyzeIncident } from '../engine/rootCauseAnalysis';
import { RootCauseAnalysis } from '../types';
import { AlertTriangle, Send, Loader2, Plus, X } from 'lucide-react';
import { cn } from '../utils/cn';

interface IncidentFormProps {
  onSubmit: (incident: Incident, analysis: RootCauseAnalysis) => void;
}

export function IncidentForm({ onSubmit }: IncidentFormProps) {
  const [analyzing, setAnalyzing] = useState(false);
  const [formData, setFormData] = useState({
    plant: '',
    line: '',
    productType: '',
    incidentType: '' as IncidentType | '',
    severity: '' as Severity | '',
    description: '',
    defectCount: 10,
    defectRate: 2.5,
    batchId: '',
    operator: '',
  });

  const [processParams, setProcessParams] = useState<ProcessParameter[]>([
    { name: 'Temperature', value: 200, unit: '°C', lowerLimit: 180, upperLimit: 220, target: 200 },
    { name: 'Pressure', value: 5.25, unit: 'MPa', lowerLimit: 4.5, upperLimit: 6.0, target: 5.25 },
  ]);

  const [qualityMetrics, setQualityMetrics] = useState<QualityMetric[]>([
    { metric: 'Defect Rate', value: 2.5, unit: '%', threshold: 2.0, breached: true },
    { metric: 'First Pass Yield', value: 94, unit: '%', threshold: 95.0, breached: true },
  ]);

  const [newParam, setNewParam] = useState({ name: '', value: 0, unit: '', lowerLimit: 0, upperLimit: 100, target: 50 });
  const [newMetric, setNewMetric] = useState({ metric: '', value: 0, unit: '', threshold: 0 });
  const [showParamForm, setShowParamForm] = useState(false);
  const [showMetricForm, setShowMetricForm] = useState(false);

  const handleAnalyze = () => {
    if (!formData.plant || !formData.line || !formData.incidentType || !formData.severity) {
      alert('Please fill in all required fields');
      return;
    }

    setAnalyzing(true);
    setTimeout(() => {
      const incident: Incident = {
        id: `INC-NEW-${Date.now().toString().slice(-4)}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
        plant: formData.plant,
        line: formData.line,
        productType: formData.productType,
        incidentType: formData.incidentType as IncidentType,
        severity: formData.severity as Severity,
        status: 'Open',
        description: formData.description || 'No additional details provided.',
        defectCount: formData.defectCount,
        defectRate: formData.defectRate,
        batchId: formData.batchId || `BT-2026-${Math.floor(Math.random() * 9000 + 1000)}`,
        operator: formData.operator || 'Current Shift Operator',
        processParameters: processParams,
        qualityMetrics: qualityMetrics,
      };

      const analysis = analyzeIncident(incident);
      onSubmit(incident, analysis);
      setAnalyzing(false);
    }, 1500);
  };

  const addProcessParam = () => {
    if (newParam.name) {
      setProcessParams([...processParams, { ...newParam }]);
      setNewParam({ name: '', value: 0, unit: '', lowerLimit: 0, upperLimit: 100, target: 50 });
      setShowParamForm(false);
    }
  };

  const addQualityMetric = () => {
    if (newMetric.metric) {
      setQualityMetrics([...qualityMetrics, { ...newMetric, breached: newMetric.value > newMetric.threshold }]);
      setNewMetric({ metric: '', value: 0, unit: '', threshold: 0 });
      setShowMetricForm(false);
    }
  };

  const removeParam = (index: number) => setProcessParams(processParams.filter((_, i) => i !== index));
  const removeMetric = (index: number) => setQualityMetrics(qualityMetrics.filter((_, i) => i !== index));

  const filteredLines = LINES.filter(l => l.plantId === PLANTS.find(p => p.name === formData.plant)?.id);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Report Quality Incident</h2>
        <p className="text-sm text-slate-500 mt-1">Enter incident details to trigger AI-powered root cause analysis</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Basic Information */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
            <AlertTriangle size={16} className="text-amber-500" />
            Basic Information
          </h3>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-slate-600 mb-1 block font-medium">Plant *</label>
              <select
                value={formData.plant}
                onChange={e => { setFormData({ ...formData, plant: e.target.value, line: '' }); }}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              >
                <option value="">Select Plant</option>
                {PLANTS.map(p => <option key={p.id} value={p.name}>{p.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-600 mb-1 block font-medium">Production Line *</label>
              <select
                value={formData.line}
                onChange={e => {
                  setFormData({ ...formData, line: e.target.value });
                  const line = LINES.find(l => l.name === e.target.value);
                  if (line) setFormData(prev => ({ ...prev, productType: line.productType }));
                }}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              >
                <option value="">Select Line</option>
                {filteredLines.map(l => <option key={l.id} value={l.name}>{l.name}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-slate-600 mb-1 block font-medium">Incident Type *</label>
              <select
                value={formData.incidentType}
                onChange={e => setFormData({ ...formData, incidentType: e.target.value as IncidentType })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              >
                <option value="">Select Type</option>
                {INCIDENT_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-600 mb-1 block font-medium">Severity *</label>
              <select
                value={formData.severity}
                onChange={e => setFormData({ ...formData, severity: e.target.value as Severity })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              >
                <option value="">Select Severity</option>
                {SEVERITY_LEVELS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-600 mb-1 block font-medium">Description</label>
            <textarea
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              rows={3}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none"
              placeholder="Describe the incident in detail..."
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="text-xs text-slate-600 mb-1 block font-medium">Defect Count</label>
              <input
                type="number"
                value={formData.defectCount}
                onChange={e => setFormData({ ...formData, defectCount: parseInt(e.target.value) || 0 })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-600 mb-1 block font-medium">Defect Rate (%)</label>
              <input
                type="number"
                step="0.1"
                value={formData.defectRate}
                onChange={e => setFormData({ ...formData, defectRate: parseFloat(e.target.value) || 0 })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-slate-600 mb-1 block font-medium">Batch ID</label>
              <input
                type="text"
                value={formData.batchId}
                onChange={e => setFormData({ ...formData, batchId: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="Auto-generated"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-600 mb-1 block font-medium">Operator</label>
            <input
              type="text"
              value={formData.operator}
              onChange={e => setFormData({ ...formData, operator: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              placeholder="Operator name"
            />
          </div>
        </div>

        {/* Process Parameters & Quality Metrics */}
        <div className="space-y-6">
          {/* Process Parameters */}
          <div className="bg-white rounded-xl border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-slate-900">Process Parameters</h3>
              <button
                onClick={() => setShowParamForm(!showParamForm)}
                className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1"
              >
                <Plus size={14} /> Add
              </button>
            </div>

            {showParamForm && (
              <div className="bg-slate-50 rounded-lg p-3 mb-4 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <input placeholder="Name" value={newParam.name} onChange={e => setNewParam({ ...newParam, name: e.target.value })} className="px-2 py-1.5 border rounded text-sm" />
                  <input placeholder="Unit" value={newParam.unit} onChange={e => setNewParam({ ...newParam, unit: e.target.value })} className="px-2 py-1.5 border rounded text-sm" />
                  <input placeholder="Value" type="number" value={newParam.value} onChange={e => setNewParam({ ...newParam, value: parseFloat(e.target.value) })} className="px-2 py-1.5 border rounded text-sm" />
                  <input placeholder="Lower Limit" type="number" value={newParam.lowerLimit} onChange={e => setNewParam({ ...newParam, lowerLimit: parseFloat(e.target.value) })} className="px-2 py-1.5 border rounded text-sm" />
                  <input placeholder="Upper Limit" type="number" value={newParam.upperLimit} onChange={e => setNewParam({ ...newParam, upperLimit: parseFloat(e.target.value) })} className="px-2 py-1.5 border rounded text-sm" />
                  <input placeholder="Target" type="number" value={newParam.target} onChange={e => setNewParam({ ...newParam, target: parseFloat(e.target.value) })} className="px-2 py-1.5 border rounded text-sm" />
                </div>
                <div className="flex gap-2">
                  <button onClick={addProcessParam} className="px-3 py-1 bg-blue-600 text-white rounded text-xs">Add</button>
                  <button onClick={() => setShowParamForm(false)} className="px-3 py-1 bg-slate-200 text-slate-700 rounded text-xs">Cancel</button>
                </div>
              </div>
            )}

            <div className="space-y-2 max-h-48 overflow-y-auto">
              {processParams.map((param, idx) => {
                const outOfSpec = param.value < param.lowerLimit || param.value > param.upperLimit;
                return (
                  <div key={idx} className={cn(
                    "flex items-center justify-between px-3 py-2 rounded-lg text-sm",
                    outOfSpec ? "bg-red-50 border border-red-200" : "bg-slate-50"
                  )}>
                    <div>
                      <span className="font-medium">{param.name}</span>
                      <span className="text-slate-500 ml-2">{param.value}{param.unit}</span>
                      {outOfSpec && <span className="ml-2 text-red-500 text-xs font-medium">⚠ OUT OF SPEC</span>}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">[{param.lowerLimit}–{param.upperLimit}]</span>
                      <button onClick={() => removeParam(idx)} className="text-slate-400 hover:text-red-500"><X size={14} /></button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quality Metrics */}
          <div className="bg-white rounded-xl border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-slate-900">Quality Metrics</h3>
              <button
                onClick={() => setShowMetricForm(!showMetricForm)}
                className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1"
              >
                <Plus size={14} /> Add
              </button>
            </div>

            {showMetricForm && (
              <div className="bg-slate-50 rounded-lg p-3 mb-4 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <input placeholder="Metric" value={newMetric.metric} onChange={e => setNewMetric({ ...newMetric, metric: e.target.value })} className="px-2 py-1.5 border rounded text-sm" />
                  <input placeholder="Value" type="number" value={newMetric.value} onChange={e => setNewMetric({ ...newMetric, value: parseFloat(e.target.value) })} className="px-2 py-1.5 border rounded text-sm" />
                  <input placeholder="Unit" value={newMetric.unit} onChange={e => setNewMetric({ ...newMetric, unit: e.target.value })} className="px-2 py-1.5 border rounded text-sm" />
                  <input placeholder="Threshold" type="number" value={newMetric.threshold} onChange={e => setNewMetric({ ...newMetric, threshold: parseFloat(e.target.value) })} className="px-2 py-1.5 border rounded text-sm" />
                </div>
                <div className="flex gap-2">
                  <button onClick={addQualityMetric} className="px-3 py-1 bg-blue-600 text-white rounded text-xs">Add</button>
                  <button onClick={() => setShowMetricForm(false)} className="px-3 py-1 bg-slate-200 text-slate-700 rounded text-xs">Cancel</button>
                </div>
              </div>
            )}

            <div className="space-y-2 max-h-48 overflow-y-auto">
              {qualityMetrics.map((metric, idx) => (
                <div key={idx} className={cn(
                  "flex items-center justify-between px-3 py-2 rounded-lg text-sm",
                  metric.breached ? "bg-red-50 border border-red-200" : "bg-green-50 border border-green-200"
                )}>
                  <div>
                    <span className="font-medium">{metric.metric}</span>
                    <span className="text-slate-500 ml-2">{metric.value}{metric.unit}</span>
                    {metric.breached && <span className="ml-2 text-red-500 text-xs font-medium">⚠ BREACHED</span>}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">(threshold: {metric.threshold})</span>
                    <button onClick={() => removeMetric(idx)} className="text-slate-400 hover:text-red-500"><X size={14} /></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Analyze Button */}
      <div className="flex justify-end">
        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          className={cn(
            "px-8 py-3 rounded-xl text-white font-medium flex items-center gap-2 transition-all",
            analyzing ? "bg-blue-400 cursor-wait" : "bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-600/20"
          )}
        >
          {analyzing ? <><Loader2 size={18} className="animate-spin" /> Analyzing...</> : <><Send size={18} /> Run Root Cause Analysis</>}
        </button>
      </div>
    </div>
  );
}
