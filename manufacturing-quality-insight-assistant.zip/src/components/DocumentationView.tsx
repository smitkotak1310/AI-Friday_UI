import { BookOpen, Database, Zap, ShieldCheck, Users, ArrowRight } from 'lucide-react';

export function DocumentationView() {
  return (
    <div className="space-y-8 max-w-4xl">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Documentation</h2>
        <p className="text-sm text-slate-500 mt-1">System overview, data structure, and usage guide</p>
      </div>

      {/* Overview */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-6 text-white">
        <h3 className="text-xl font-bold mb-2">QualityIQ — Manufacturing Quality Incident Insight Assistant</h3>
        <p className="text-blue-100 leading-relaxed">
          An AI-powered assistant that accepts quality incident indicators and produces concise explanations suggesting potential root causes. 
          Designed to reduce analysis time and improve decision-making on the manufacturing shop floor.
        </p>
      </div>

      {/* Architecture */}
      <div className="space-y-6">
        <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Database size={20} className="text-blue-600" />
          Data Structure
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <DocCard
            title="Incident Record"
            items={[
              'id — Unique identifier (INC-XXXX)',
              'timestamp — Date/time of occurrence',
              'plant / line / productType — Location context',
              'incidentType — Classification of incident',
              'severity — Critical, Major, Minor, Low',
              'status — Open, Investigating, Resolved, Closed',
              'description — Free-text incident details',
              'defectCount / defectRate — Quantitative metrics',
              'batchId — Production batch reference',
              'operator — Responsible personnel',
            ]}
          />
          <DocCard
            title="Analysis Record"
            items={[
              'primaryCause — Most likely root cause',
              'confidence — Analysis confidence percentage',
              'contributingFactors — Additional factors',
              'severityAssessment — Severity context',
              'recommendedActions — Step-by-step actions',
              'estimatedImpact — Business impact estimate',
              'preventionMeasures — Long-term prevention',
              'relatedIncidents — Linked historical events',
              'priority — Immediate, High, Medium, Low',
            ]}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <DocCard
            title="Process Parameter"
            items={[
              'name — Parameter name (e.g., Temperature)',
              'value — Current measured value',
              'unit — Measurement unit',
              'lowerLimit / upperLimit — Acceptable range',
              'target — Ideal setpoint value',
            ]}
          />
          <DocCard
            title="Quality Metric"
            items={[
              'metric — Name of the quality metric',
              'value — Current measured value',
              'unit — Measurement unit',
              'threshold — Acceptance threshold',
              'breached — Whether threshold is exceeded',
            ]}
          />
        </div>
      </div>

      {/* How it Works */}
      <div className="space-y-6">
        <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Zap size={20} className="text-amber-500" />
          How Root Cause Analysis Works
        </h3>

        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <div className="space-y-6">
            <Step
              num="1"
              title="Data Ingestion"
              description="Quality incident data is collected through the reporting form or selected from historical incidents. Data includes process parameters, quality metrics, incident type, severity, and contextual information."
            />
            <Step
              num="2"
              title="Pattern Recognition"
              description="The analysis engine cross-references incident type with a comprehensive knowledge base of manufacturing failure modes, known root causes, and corrective action patterns."
            />
            <Step
              num="3"
              title="Parameter Analysis"
              description="Process parameters are evaluated against specification limits. Out-of-spec parameters are flagged with deviation analysis. Quality metrics are assessed against defined thresholds."
            />
            <Step
              num="4"
              title="Root Cause Determination"
              description="Based on incident type, severity, parameter status, and metric breaches, the engine identifies the primary root cause and contributing factors with a confidence score."
            />
            <Step
              num="5"
              title="Action Generation"
              description="Corrective actions, prevention measures, and business impact estimates are generated. Related historical incidents are identified for context and pattern analysis."
            />
          </div>
        </div>
      </div>

      {/* Usage Guide */}
      <div className="space-y-6">
        <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Users size={20} className="text-green-600" />
          Usage Guide
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <UsageCard
            icon={<BookOpen size={24} />}
            title="Report Incident"
            description="Navigate to 'Report Incident' to submit a new quality incident. Fill in the required fields and add process parameters and quality metrics. Click 'Run Root Cause Analysis' to get AI-powered insights."
            color="blue"
          />
          <UsageCard
            icon={<ArrowRight size={24} />}
            title="View Analysis"
            description="Review the generated root cause analysis with expandable sections for detailed investigation. Each section provides specific actionable guidance tailored to the incident type and data."
            color="amber"
          />
          <UsageCard
            icon={<ShieldCheck size={24} />}
            title="Track & Analyze"
            description="Use 'Incident History' to browse past incidents with filtering. The 'Analytics' dashboard provides trend analysis, severity distributions, and resolution time metrics for continuous improvement."
            color="green"
          />
        </div>
      </div>

      {/* Incident Types */}
      <div className="space-y-6">
        <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <ShieldCheck size={20} className="text-purple-600" />
          Supported Incident Types
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {[
            'Defect Spike', 'Process Deviation', 'Equipment Failure',
            'Material Anomaly', 'Dimensional Out-of-Tolerance', 'Surface Defect',
            'Electrical Failure', 'Contamination', 'Assembly Error',
            'Calibration Drift'
          ].map(type => (
            <div key={type} className="bg-white rounded-lg border border-slate-200 p-3 text-sm text-slate-700 flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0" />
              {type}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function DocCard({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5">
      <h4 className="text-sm font-semibold text-slate-900 mb-3">{title}</h4>
      <div className="space-y-1.5">
        {items.map(item => (
          <p key={item} className="text-xs text-slate-600 font-mono bg-slate-50 px-2 py-1 rounded">{item}</p>
        ))}
      </div>
    </div>
  );
}

function Step({ num, title, description }: { num: string; title: string; description: string }) {
  return (
    <div className="flex gap-4">
      <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">{num}</div>
      <div>
        <h4 className="text-sm font-semibold text-slate-900">{title}</h4>
        <p className="text-sm text-slate-600 mt-1">{description}</p>
      </div>
    </div>
  );
}

function UsageCard({ icon, title, description, color }: { icon: React.ReactNode; title: string; description: string; color: string }) {
  const colors: Record<string, string> = {
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    amber: 'bg-amber-50 text-amber-600 border-amber-200',
    green: 'bg-green-50 text-green-600 border-green-200',
  };
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5">
      <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center mb-3", colors[color])}>{icon}</div>
      <h4 className="text-sm font-semibold text-slate-900 mb-2">{title}</h4>
      <p className="text-xs text-slate-600 leading-relaxed">{description}</p>
    </div>
  );
}

function cn(...classes: (string | undefined | null | false)[]) {
  return classes.filter(Boolean).join(' ');
}
