import React from 'react';
import { 
  LayoutDashboard, Search, BarChart3, FileText, 
  PlusCircle, History, ChevronLeft, ChevronRight,
  Factory, AlertCircle, MessageSquare
} from 'lucide-react';
import { cn } from '../utils/cn';

type ViewType = 'dashboard' | 'incident' | 'analysis' | 'history' | 'analytics' | 'documentation' | 'chatbot';

interface SidebarProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  collapsed: boolean;
  onToggle: () => void;
  openIncidents: number;
}

const navItems: { view: ViewType; label: string; icon: React.ReactNode; badge?: string; highlight?: boolean }[] = [
  { view: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
  { view: 'incident', label: 'Report Incident', icon: <PlusCircle size={20} /> },
  { view: 'analysis', label: 'AI Analysis', icon: <Search size={20} /> },
  { view: 'history', label: 'Incident History', icon: <History size={20} /> },
  { view: 'analytics', label: 'Analytics', icon: <BarChart3 size={20} /> },
  { view: 'chatbot', label: 'AI Chatbot', icon: <MessageSquare size={20} />, badge: 'NEW', highlight: true },
  { view: 'documentation', label: 'Documentation', icon: <FileText size={20} /> },
];

export function Sidebar({ currentView, onNavigate, collapsed, onToggle, openIncidents }: SidebarProps) {
  return (
    <div className={cn(
      "bg-slate-900 text-white flex flex-col transition-all duration-300 border-r border-slate-700",
      collapsed ? "w-16" : "w-64"
    )}>
      {/* Logo */}
      <div className="p-4 border-b border-slate-700 flex items-center gap-3">
        <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
          <Factory size={18} className="text-white" />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <h1 className="text-sm font-bold text-white leading-tight">QualityIQ</h1>
            <p className="text-[10px] text-slate-400">Incident Assistant</p>
          </div>
        )}
      </div>

      {/* Alert Badge */}
      {openIncidents > 0 && !collapsed && (
        <div className="mx-3 mt-3 bg-amber-500/20 border border-amber-500/30 rounded-lg p-3 flex items-center gap-2">
          <AlertCircle size={16} className="text-amber-400 flex-shrink-0" />
          <div>
            <p className="text-xs text-amber-300 font-medium">{openIncidents} Open</p>
            <p className="text-[10px] text-amber-400/70">incidents need attention</p>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <button
            key={item.view}
            onClick={() => onNavigate(item.view)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200",
              currentView === item.view
                ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20"
                : item.highlight
                  ? "text-emerald-400 hover:text-emerald-300 hover:bg-emerald-400/10 border border-emerald-400/20"
                  : "text-slate-400 hover:text-white hover:bg-slate-800"
            )}
          >
            <span className="flex-shrink-0">{item.icon}</span>
            {!collapsed && (
              <>
                <span className="flex-1 text-left">{item.label}</span>
                {item.badge && (
                  <span className="bg-gradient-to-r from-blue-500 to-purple-500 text-white text-[9px] px-1.5 py-0.5 rounded-full font-bold">
                    {item.badge}
                  </span>
                )}
              </>
            )}
            {item.view === 'history' && openIncidents > 0 && !collapsed && (
              <span className="ml-auto bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full">
                {openIncidents}
              </span>
            )}
          </button>
        ))}
      </nav>

      {/* Toggle Button */}
      <button
        onClick={onToggle}
        className="p-3 border-t border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors flex items-center gap-3"
      >
        {collapsed ? <ChevronRight size={18} /> : <><ChevronLeft size={18} /><span className="text-sm">Collapse</span></>}
      </button>
    </div>
  );
}
