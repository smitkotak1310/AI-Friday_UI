import { useState, useRef, useEffect, useCallback } from 'react';
import { INCIDENTS } from '../data/syntheticData';
import {
  Send, Sparkles, Bot, User, Clock, Zap, Copy,
  ThumbsUp, ThumbsDown, RotateCcw, Brain,
  FileText, ChevronDown, ChevronUp, MessageSquare,
  Trash2, PanelLeftOpen, PanelLeftClose, Loader2,
  Lightbulb, Star, CheckCircle2,
  Target, AlertTriangle, ArrowDown,
} from 'lucide-react';
import { LLMModel, ChatMessage as ChatMsg } from '../types';
import {
  LLM_MODELS,
  generateLLMResponse,
  SUGGESTED_PROMPTS,
  QUICK_ACTIONS,
} from '../engine/llmEngine';

// ============================================================
// Simple Markdown Renderer
// ============================================================

function renderMarkdown(text: string): string {
  let html = text;

  // Code blocks
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, '<pre class="bg-slate-900 text-slate-100 p-3 rounded-lg my-2 overflow-x-auto text-xs"><code>$2</code></pre>');

  // Tables
  html = html.replace(/^\|(.+)\|$/gm, (match) => {
    return match;
  });

  // Convert markdown table to HTML table
  const tableRegex = /(\|.+\|\n\|[-| :]+\|\n(\|.+\|\n?)+)/g;
  html = html.replace(tableRegex, (table) => {
    const rows = table.trim().split('\n');
    let tableHtml = '<table class="w-full text-xs border-collapse my-3">';
    rows.forEach((row, idx) => {
      const cells = row.split('|').filter(c => c.trim());
      if (idx === 0) {
        tableHtml += '<thead><tr>';
        cells.forEach(cell => {
          tableHtml += `<th class="border border-slate-300 px-3 py-2 bg-slate-100 font-semibold text-left">${cell.trim()}</th>`;
        });
        tableHtml += '</tr></thead><tbody>';
      } else if (idx === 1) {
        // Skip separator row
      } else {
        tableHtml += '<tr>';
        cells.forEach(cell => {
          tableHtml += `<td class="border border-slate-300 px-3 py-2">${cell.trim()}</td>`;
        });
        tableHtml += '</tr>';
      }
    });
    tableHtml += '</tbody></table>';
    return tableHtml;
  });

  // Headers
  html = html.replace(/^### (.+)$/gm, '<h3 class="text-base font-bold text-slate-900 mt-4 mb-2">$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2 class="text-lg font-bold text-slate-900 mt-5 mb-2">$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1 class="text-xl font-bold text-slate-900 mt-5 mb-2">$1</h1>');

  // Bold
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong class="font-bold text-slate-900">$1</strong>');

  // Italic
  html = html.replace(/\*(.+?)\*/g, '<em class="italic text-slate-600">$1</em>');

  // Inline code
  html = html.replace(/`([^`]+)`/g, '<code class="bg-slate-100 text-pink-600 px-1.5 py-0.5 rounded text-xs font-mono">$1</code>');

  // Blockquotes
  html = html.replace(/^> (.+)$/gm, '<blockquote class="border-l-4 border-blue-400 bg-blue-50 px-4 py-2 my-2 rounded-r text-sm text-slate-700 italic">$1</blockquote>');

  // Unordered lists
  html = html.replace(/^[-•] (.+)$/gm, '<li class="ml-4 list-disc text-slate-700">$1</li>');

  // Ordered lists
  html = html.replace(/^(\d+)\. (.+)$/gm, '<li class="ml-4 list-decimal text-slate-700">$2</li>');

  // Horizontal rule
  html = html.replace(/^---$/gm, '<hr class="my-4 border-slate-200" />');

  // Line breaks
  html = html.replace(/\n\n/g, '</p><p class="my-1">');
  html = html.replace(/\n/g, '<br />');

  html = `<p class="my-1">${html}</p>`;

  // Clean up empty paragraphs
  html = html.replace(/<p class="my-1">\s*<\/p>/g, '');
  html = html.replace(/<p class="my-1">\s*(<h[1-3])/g, '$1');
  html = html.replace(/(<\/h[1-3]>)\s*<\/p>/g, '$1');
  html = html.replace(/<p class="my-1">\s*(<table)/g, '$1');
  html = html.replace(/(<\/table>)\s*<\/p>/g, '$1');
  html = html.replace(/<p class="my-1">\s*(<pre)/g, '$1');
  html = html.replace(/(<\/pre>)\s*<\/p>/g, '$1');
  html = html.replace(/<p class="my-1">\s*(<blockquote)/g, '$1');
  html = html.replace(/(<\/blockquote>)\s*<\/p>/g, '$1');
  html = html.replace(/<p class="my-1">\s*(<hr)/g, '$1');
  html = html.replace(/<p class="my-1">\s*(<ul)/g, '$1');
  html = html.replace(/<p class="my-1">\s*(<ol)/g, '$1');

  return html;
}

// ============================================================
// Chat Session Interface
// ============================================================

interface ChatSession {
  id: string;
  title: string;
  messages: ChatMsg[];
  createdAt: Date;
  model: LLMModel;
}

// ============================================================
// Chat Message Bubble
// ============================================================

interface MessageBubbleProps {
  message: ChatMsg;
  onCopy: (text: string) => void;
  onRegenerate: () => void;
  showScores: boolean;
  onToggleScores: () => void;
}

function MessageBubble({ message, onCopy, onRegenerate, showScores, onToggleScores }: MessageBubbleProps) {
  const isUser = message.role === 'user';
  const model = LLM_MODELS.find(m => m.id === message.model);

  if (isUser) {
    return (
      <div className="flex gap-3 justify-end mb-6">
        <div className="max-w-[75%]">
          <div className="bg-blue-600 text-white rounded-2xl rounded-br-md px-5 py-3 shadow-md">
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
          </div>
          <div className="flex items-center justify-end gap-2 mt-1.5 px-2">
            <span className="text-[10px] text-slate-400">
              {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        </div>
        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
          <User size={14} className="text-white" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-3 mb-6">
      <div
        className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1"
        style={{ backgroundColor: model?.color || '#6366f1' }}
      >
        <Bot size={14} className="text-white" />
      </div>
      <div className="max-w-[85%] flex-1">
        {/* Model Badge */}
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs font-semibold" style={{ color: model?.color }}>
            {model?.name}
          </span>
          {message.accuracyScore && (
            <div className="flex items-center gap-1">
              <Target size={10} className="text-emerald-500" />
              <span className="text-[10px] font-medium text-emerald-600">{message.accuracyScore}%</span>
            </div>
          )}
          {message.confidenceScore && (
            <div className="flex items-center gap-1">
              <Star size={10} className="text-amber-500" />
              <span className="text-[10px] font-medium text-amber-600">{message.confidenceScore}%</span>
            </div>
          )}
          <button
            onClick={onToggleScores}
            className="text-[10px] text-slate-400 hover:text-slate-600 flex items-center gap-0.5 transition-colors"
          >
            {showScores ? <ChevronUp size={10} /> : <ChevronDown size={10} />}
            {showScores ? 'Hide' : 'Show'} Details
          </button>
        </div>

        {/* Message Content */}
        <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-md px-5 py-4 shadow-sm">
          {message.isStreaming ? (
            <div className="flex items-center gap-2">
              <Loader2 size={16} className="animate-spin text-blue-500" />
              <span className="text-sm text-slate-500">Analyzing and generating response...</span>
            </div>
          ) : (
            <div
              className="text-sm leading-relaxed prose-sm"
              dangerouslySetInnerHTML={{ __html: renderMarkdown(message.content) }}
            />
          )}
        </div>

        {/* Action Bar */}
        {!message.isStreaming && (
          <div className="flex items-center gap-2 mt-2 px-1">
            <button
              onClick={() => onCopy(message.content)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              title="Copy response"
            >
              <Copy size={13} />
            </button>
            <button
              onClick={onRegenerate}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              title="Regenerate response"
            >
              <RotateCcw size={13} />
            </button>
            <button
              className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
              title="Helpful"
            >
              <ThumbsUp size={13} />
            </button>
            <button
              className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
              title="Not helpful"
            >
              <ThumbsDown size={13} />
            </button>

            {/* Metrics */}
            <div className="ml-auto flex items-center gap-3">
              {message.tokensUsed && (
                <span className="flex items-center gap-1 text-[10px] text-slate-400">
                  <FileText size={10} />
                  {message.tokensUsed} tokens
                </span>
              )}
              {message.responseTime && (
                <span className="flex items-center gap-1 text-[10px] text-slate-400">
                  <Clock size={10} />
                  {message.responseTime}s
                </span>
              )}
            </div>
          </div>
        )}

        {/* Score Details Panel */}
        {showScores && message.accuracyScore && message.sources && !message.isStreaming && (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 mt-2 space-y-3">
            {/* Scores */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <div className="flex items-center gap-2 mb-2">
                  <Target size={14} className="text-emerald-500" />
                  <span className="text-xs font-semibold text-slate-700">Accuracy Score</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-slate-100 rounded-full h-2">
                    <div
                      className="bg-emerald-500 h-2 rounded-full transition-all duration-1000"
                      style={{ width: `${message.accuracyScore}%` }}
                    />
                  </div>
                  <span className="text-sm font-bold text-emerald-600">{message.accuracyScore}%</span>
                </div>
              </div>
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <div className="flex items-center gap-2 mb-2">
                  <Star size={14} className="text-amber-500" />
                  <span className="text-xs font-semibold text-slate-700">Confidence Score</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-slate-100 rounded-full h-2">
                    <div
                      className="bg-amber-500 h-2 rounded-full transition-all duration-1000"
                      style={{ width: `${message.confidenceScore}%` }}
                    />
                  </div>
                  <span className="text-sm font-bold text-amber-600">{message.confidenceScore}%</span>
                </div>
              </div>
            </div>

            {/* Reasoning Steps */}
            {message.reasoningSteps && (
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <div className="flex items-center gap-2 mb-2">
                  <Brain size={14} className="text-blue-500" />
                  <span className="text-xs font-semibold text-slate-700">Reasoning Steps</span>
                </div>
                <div className="space-y-1">
                  {message.reasoningSteps.map((step, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-slate-600">
                      <CheckCircle2 size={12} className="text-emerald-400 mt-0.5 flex-shrink-0" />
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Sources */}
            <div className="bg-white rounded-lg p-3 border border-slate-100">
              <div className="flex items-center gap-2 mb-2">
                <FileText size={14} className="text-violet-500" />
                <span className="text-xs font-semibold text-slate-700">Sources Referenced ({message.sources.length})</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {message.sources.map((source, i) => (
                  <span
                    key={i}
                    className="px-2 py-0.5 bg-violet-50 text-violet-700 rounded-full text-[10px] font-medium"
                  >
                    {source}
                  </span>
                ))}
              </div>
            </div>

            {/* Overall Quality Badge */}
            <div className="flex items-center justify-center gap-2">
              {(() => {
                const avgScore = ((message.accuracyScore || 0) + (message.confidenceScore || 0)) / 2;
                if (avgScore >= 90) {
                  return (
                    <span className="flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-semibold">
                      <CheckCircle2 size={12} />
                      High Quality Response
                    </span>
                  );
                } else if (avgScore >= 80) {
                  return (
                    <span className="flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                      <Target size={12} />
                      Good Quality Response
                    </span>
                  );
                } else {
                  return (
                    <span className="flex items-center gap-1.5 px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-semibold">
                      <AlertTriangle size={12} />
                      Moderate Quality — Review Recommended
                    </span>
                  );
                }
              })()}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// LLM Comparison View
// ============================================================

interface LLMComparisonProps {
  query: string;
  onClose: () => void;
}

function LLMComparison({ query, onClose }: LLMComparisonProps) {
  const [results, setResults] = useState<Record<LLMModel, any> | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      const r: Record<LLMModel, any> = {} as any;
      LLM_MODELS.forEach(model => {
        r[model.id] = generateLLMResponse(query, model.id);
      });
      setResults(r);
      setLoading(false);
    }, 800);
    return () => clearTimeout(timer);
  }, [query]);

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <Zap size={20} className="text-amber-500" />
            <h2 className="text-lg font-bold text-slate-900">LLM Response Comparison</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
            ✕
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-5">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-20">
              <Loader2 size={32} className="animate-spin text-blue-500 mb-3" />
              <p className="text-sm text-slate-500">Generating responses from all 5 models...</p>
            </div>
          ) : results ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {LLM_MODELS.map(model => {
                const r = results[model.id];
                if (!r) return null;
                return (
                  <div key={model.id} className="border border-slate-200 rounded-xl p-4 bg-white">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center" style={{ backgroundColor: model.color }}>
                        <Bot size={12} className="text-white" />
                      </div>
                      <span className="text-sm font-bold text-slate-900">{model.name}</span>
                    </div>

                    <div className="flex gap-3 mb-3">
                      <div className="flex-1 text-center bg-emerald-50 rounded-lg p-2">
                        <div className="text-xs text-emerald-600 font-medium">Accuracy</div>
                        <div className="text-lg font-bold text-emerald-700">{r.accuracyScore}%</div>
                      </div>
                      <div className="flex-1 text-center bg-amber-50 rounded-lg p-2">
                        <div className="text-xs text-amber-600 font-medium">Confidence</div>
                        <div className="text-lg font-bold text-amber-700">{r.confidenceScore}%</div>
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-400 space-y-0.5 mb-3">
                      <div>⏱ {r.responseTime}s | 📄 {r.tokensUsed} tokens</div>
                    </div>

                    <div className="max-h-64 overflow-y-auto">
                      <div
                        className="text-xs leading-relaxed text-slate-600 prose-xs"
                        dangerouslySetInnerHTML={{ __html: renderMarkdown(r.content.split('\n\n---\n')[0]) }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Main Chatbot View
// ============================================================

export function ChatbotView() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedModel, setSelectedModel] = useState<LLMModel>('gpt4');
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const [showQuickActions] = useState(true);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [textareaRows, setTextareaRows] = useState(1);
  const [showSidebar, setShowSidebar] = useState(true);
  const [expandedMessages, setExpandedMessages] = useState<Set<string>>(new Set());
  const [comparisonQuery, setComparisonQuery] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('All');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const activeSession = sessions.find(s => s.id === activeSessionId);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [activeSession?.messages, scrollToBottom]);

  // Create initial session
  useEffect(() => {
    if (sessions.length === 0) {
      const newSession: ChatSession = {
        id: `session-${Date.now()}`,
        title: 'New Conversation',
        messages: [{
          id: `msg-${Date.now()}`,
          role: 'assistant',
          content: `Welcome to **QualityIQ AI Assistant**! 🤖

I'm here to help you analyze manufacturing quality incidents, identify root causes, and recommend corrective actions. 

Select an LLM model from the dropdown above, then type your question or choose from the suggested prompts below. I have access to **${INCIDENTS.length}** quality incident records and a comprehensive manufacturing knowledge base.`,
          timestamp: new Date(),
          model: 'gpt4',
          accuracyScore: 100,
          confidenceScore: 100,
          tokensUsed: 0,
          responseTime: 0,
          sources: ['QualityIQ System'],
          reasoningSteps: ['System initialization', 'Welcome message'],
        }],
        createdAt: new Date(),
        model: 'gpt4',
      };
      setSessions([newSession]);
      setActiveSessionId(newSession.id);
    }
  }, [sessions.length]);

  const createNewSession = () => {
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'New Conversation',
      messages: [{
        id: `msg-${Date.now()}`,
        role: 'assistant',
        content: `Hello! How can I help you with manufacturing quality analysis today?`,
        timestamp: new Date(),
        model: selectedModel,
        accuracyScore: 100,
        confidenceScore: 100,
        tokensUsed: 0,
        responseTime: 0,
        sources: ['QualityIQ System'],
        reasoningSteps: ['System initialization'],
      }],
      createdAt: new Date(),
      model: selectedModel,
    };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    setShowSuggestions(true);
  };

  const deleteSession = (id: string) => {
    setSessions(prev => prev.filter(s => s.id !== id));
    if (activeSessionId === id) {
      setActiveSessionId(null);
    }
  };

  const sendMessage = async (content: string) => {
    if (!content.trim() || isGenerating || !activeSessionId) return;

    // Update session title from first user message
    setSessions(prev => prev.map(s => {
      if (s.id === activeSessionId) {
        const firstUserMsg = s.messages.find(m => m.role === 'user');
        if (!firstUserMsg) {
          return { ...s, title: content.substring(0, 50) + (content.length > 50 ? '...' : '') };
        }
      }
      return s;
    }));

    // Add user message
    const userMessage: ChatMsg = {
      id: `msg-user-${Date.now()}`,
      role: 'user',
      content: content.trim(),
      timestamp: new Date(),
    };

    setSessions(prev => prev.map(s =>
      s.id === activeSessionId
        ? { ...s, messages: [...s.messages, userMessage] }
        : s
    ));
    setShowSuggestions(false);
    setInput('');
    setIsGenerating(true);

    // Simulate streaming delay
    const delay = 800 + Math.random() * 1500;

    setTimeout(() => {
      // Add streaming placeholder
      const streamingMsg: ChatMsg = {
        id: `msg-ai-${Date.now()}`,
        role: 'assistant',
        content: '',
        timestamp: new Date(),
        model: selectedModel,
        isStreaming: true,
      };

      setSessions(prev => prev.map(s =>
        s.id === activeSessionId
          ? { ...s, messages: [...s.messages, streamingMsg] }
          : s
      ));

      // Generate response
      const response = generateLLMResponse(content.trim(), selectedModel);

      const aiMessage: ChatMsg = {
        ...streamingMsg,
        content: response.content,
        isStreaming: false,
        accuracyScore: response.accuracyScore,
        confidenceScore: response.confidenceScore,
        tokensUsed: response.tokensUsed,
        responseTime: response.responseTime,
        sources: response.sources,
        reasoningSteps: response.reasoningSteps,
      };

      setSessions(prev => prev.map(s =>
        s.id === activeSessionId
          ? { ...s, messages: s.messages.map(m => m.id === streamingMsg.id ? aiMessage : m) }
          : s
      ));
      setIsGenerating(false);
    }, delay);
  };

  const regenerateLastResponse = () => {
    if (!activeSession || activeSession.messages.length < 2) return;
    const lastUserMsg = [...activeSession.messages].reverse().find(m => m.role === 'user');
    if (lastUserMsg) {
      sendMessage(lastUserMsg.content);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const toggleMessageDetails = (id: string) => {
    setExpandedMessages(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const categories = ['All', ...Array.from(new Set(SUGGESTED_PROMPTS.map(p => p.category)))];
  const filteredPrompts = filterCategory === 'All'
    ? SUGGESTED_PROMPTS
    : SUGGESTED_PROMPTS.filter(p => p.category === filterCategory);

  const currentModel = LLM_MODELS.find(m => m.id === selectedModel)!;

  return (
    <div className="flex h-[calc(100vh-120px)] bg-slate-50 rounded-xl overflow-hidden border border-slate-200">
      {/* Chat Sidebar */}
      {showSidebar && (
        <div className="w-64 bg-slate-900 text-white flex flex-col flex-shrink-0">
          <div className="p-3 border-b border-slate-700">
            <button
              onClick={createNewSession}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-sm font-medium transition-colors"
            >
              <MessageSquare size={14} />
              New Chat
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {sessions.map(session => (
              <div
                key={session.id}
                className={`group flex items-center gap-2 px-3 py-2.5 rounded-lg cursor-pointer transition-colors ${
                  session.id === activeSessionId
                    ? 'bg-blue-600/20 border border-blue-500/30'
                    : 'hover:bg-slate-800'
                }`}
                onClick={() => setActiveSessionId(session.id)}
              >
                <MessageSquare size={14} className="text-slate-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{session.title}</p>
                  <p className="text-[10px] text-slate-500">
                    {LLM_MODELS.find(m => m.id === session.model)?.name} • {session.messages.length - 1} msgs
                  </p>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); deleteSession(session.id); }}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:bg-slate-700 rounded transition-all"
                >
                  <Trash2 size={11} className="text-slate-400" />
                </button>
              </div>
            ))}
          </div>
          <div className="p-3 border-t border-slate-700">
            <div className="text-[10px] text-slate-500">
              {sessions.length} conversations • {LLM_MODELS.length} models available
            </div>
          </div>
        </div>
      )}

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Chat Header */}
        <div className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowSidebar(!showSidebar)}
              className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors text-slate-500"
            >
              {showSidebar ? <PanelLeftClose size={16} /> : <PanelLeftOpen size={16} />}
            </button>

            {/* Model Selector */}
            <div className="relative">
              <button
                onClick={() => setShowModelDropdown(!showModelDropdown)}
                className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
              >
                <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ backgroundColor: currentModel.color }}>
                  <Bot size={10} className="text-white" />
                </div>
                <span className="text-xs font-semibold text-slate-700">{currentModel.name}</span>
                <ChevronDown size={12} className="text-slate-400" />
              </button>

              {showModelDropdown && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowModelDropdown(false)} />
                  <div className="absolute top-full left-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl z-50 w-72 overflow-hidden">
                    <div className="p-2 border-b border-slate-100">
                      <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-wide px-2 py-1">Select LLM Model</p>
                    </div>
                    {LLM_MODELS.map(model => (
                      <button
                        key={model.id}
                        onClick={() => { setSelectedModel(model.id); setShowModelDropdown(false); }}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 hover:bg-slate-50 transition-colors ${
                          model.id === selectedModel ? 'bg-blue-50' : ''
                        }`}
                      >
                        <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: model.color }}>
                          <Bot size={14} className="text-white" />
                        </div>
                        <div className="text-left flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-slate-900">{model.name}</span>
                            {model.id === selectedModel && <CheckCircle2 size={12} className="text-blue-500" />}
                          </div>
                          <p className="text-[10px] text-slate-500 truncate">{model.provider} — {model.description}</p>
                          <div className="flex items-center gap-3 mt-0.5">
                            <span className="text-[10px] text-emerald-600">🎯 {model.baseAccuracy}% accuracy</span>
                            <span className="text-[10px] text-amber-600">⭐ {model.baseConfidence}% confidence</span>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setComparisonQuery(activeSession?.messages.find(m => m.role === 'user')?.content || 'What are common root causes of quality incidents?');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg text-xs font-medium transition-colors border border-amber-200"
            >
              <Zap size={12} />
              Compare All Models
            </button>
          </div>
        </div>

        {/* Messages Area */}
        <div
          className="flex-1 overflow-y-auto px-4 py-6 relative"
          onScroll={(e) => {
            const el = e.currentTarget;
            const isNearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 200;
            setShowScrollButton(!isNearBottom);
          }}
        >
          {/* Scroll to bottom button */}
          {showScrollButton && (
            <button
              onClick={() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })}
              className="absolute bottom-4 right-6 z-10 p-2 bg-white border border-slate-200 rounded-full shadow-lg hover:bg-slate-50 transition-all"
            >
              <ArrowDown size={16} className="text-slate-600" />
            </button>
          )}
          {activeSession ? (
            <>
              {activeSession.messages.map(msg => (
                <MessageBubble
                  key={msg.id}
                  message={msg}
                  onCopy={copyToClipboard}
                  onRegenerate={regenerateLastResponse}
                  showScores={expandedMessages.has(msg.id)}
                  onToggleScores={() => toggleMessageDetails(msg.id)}
                />
              ))}

              {/* Suggested Prompts */}
              {showSuggestions && activeSession.messages.length <= 1 && (
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Lightbulb size={14} className="text-amber-500" />
                      <span className="text-xs font-semibold text-slate-700">Suggested Prompts</span>
                    </div>
                    <div className="flex items-center gap-1">
                      {categories.map(cat => (
                        <button
                          key={cat}
                          onClick={() => setFilterCategory(cat)}
                          className={`px-2 py-0.5 rounded-full text-[10px] font-medium transition-colors ${
                            filterCategory === cat
                              ? 'bg-blue-100 text-blue-700'
                              : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {filteredPrompts.map((prompt, i) => (
                      <button
                        key={i}
                        onClick={() => sendMessage(prompt.prompt)}
                        className="flex items-start gap-2.5 p-3 bg-white border border-slate-200 hover:border-blue-300 hover:shadow-md rounded-xl text-left transition-all group"
                      >
                        <span className="text-lg flex-shrink-0">{prompt.icon}</span>
                        <div>
                          <p className="text-xs font-semibold text-slate-700 group-hover:text-blue-600 transition-colors">
                            {prompt.label}
                          </p>
                          <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">
                            {prompt.prompt}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick Actions */}
              {showQuickActions && activeSession.messages.length <= 1 && (
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Zap size={14} className="text-blue-500" />
                    <span className="text-xs font-semibold text-slate-700">Quick Actions</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {QUICK_ACTIONS.map((action, i) => (
                      <button
                        key={i}
                        onClick={() => sendMessage(action.prompt)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 hover:border-blue-300 hover:bg-blue-50 rounded-lg text-xs font-medium text-slate-700 transition-all"
                      >
                        <span>{action.icon}</span>
                        {action.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-4">
                <Sparkles size={28} className="text-blue-500" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Start a New Conversation</h3>
              <p className="text-sm text-slate-500 mb-4">Create a new chat to begin your quality analysis</p>
              <button
                onClick={createNewSession}
                className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 transition-colors"
              >
                New Chat
              </button>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="bg-white border-t border-slate-200 px-4 py-3 flex-shrink-0">
          <div className="flex items-end gap-2">
            <div className="flex-1 relative">
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => {
                  setInput(e.target.value);
                  const lines = e.target.value.split('\n').length;
                  setTextareaRows(Math.min(Math.max(1, lines), 4));
                }}
                onKeyDown={handleKeyDown}
                placeholder={`Ask about quality incidents, root causes, corrective actions... (Enter to send, Shift+Enter for new line)`}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all pr-12"
                rows={textareaRows}
                style={{ minHeight: '42px', maxHeight: '120px' }}
                disabled={isGenerating}
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-400">
                {input.length > 0 && `${input.length} chars`}
              </div>
            </div>
            <button
              onClick={() => sendMessage(input)}
              disabled={isGenerating || !input.trim()}
              className={`p-2.5 rounded-xl transition-all flex-shrink-0 ${
                isGenerating || !input.trim()
                  ? 'bg-slate-100 text-slate-300 cursor-not-allowed'
                  : 'bg-blue-600 text-white hover:bg-blue-700 shadow-md hover:shadow-lg'
              }`}
            >
              {isGenerating ? (
                <Loader2 size={18} className="animate-spin" />
              ) : (
                <Send size={18} />
              )}
            </button>
          </div>
          <div className="flex items-center justify-between mt-2 px-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-slate-400">
                Using <span style={{ color: currentModel.color }} className="font-semibold">{currentModel.name}</span>
                {' '}• Accuracy ~{currentModel.baseAccuracy}% • Confidence ~{currentModel.baseConfidence}%
              </span>
            </div>
            <div className="text-[10px] text-slate-400">
              {activeSession ? `${activeSession.messages.length - 1} messages` : '0 messages'}
            </div>
          </div>
        </div>
      </div>

      {/* LLM Comparison Modal */}
      {comparisonQuery && (
        <LLMComparison
          query={comparisonQuery}
          onClose={() => setComparisonQuery(null)}
        />
      )}
    </div>
  );
}
