import { useState, useMemo } from 'react';
import { Incident } from '../types';
import { Search, Filter, ChevronDown, Eye, X } from 'lucide-react';
import { cn } from '../utils/cn';

interface IncidentHistoryProps {
  incidents: Incident[];
  onViewAnalysis: (incident: Incident) => void;
}

const severityColors: Record<string, string> = {
  Critical: 'bg-red-100 text-red-700 border-red-200',
  Major: 'bg-amber-100 text-amber-700 border-amber-200',
  Minor: 'bg-blue-100 text-blue-700 border-blue-200',
  Low: 'bg-green-100 text-green-700 border-green-200',
};

const statusColors: Record<string, string> = {
  Open: 'bg-red-50 text-red-600 border-red-200',
  Investigating: 'bg-amber-50 text-amber-600 border-amber-200',
  Resolved: 'bg-green-50 text-green-600 border-green-200',
  Closed: 'bg-slate-100 text-slate-600 border-slate-200',
};

export function IncidentHistory({ incidents, onViewAnalysis }: IncidentHistoryProps) {
  const [search, setSearch] = useState('');
  const [filterSeverity, setFilterSeverity] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [filterType, setFilterType] = useState('All');
  const [showFilters, setShowFilters] = useState(false);

  const filteredIncidents = useMemo(() => {
    return incidents.filter(inc => {
      const matchSearch = !search || 
        inc.id.toLowerCase().includes(search.toLowerCase()) ||
        inc.incidentType.toLowerCase().includes(search.toLowerCase()) ||
        inc.plant.toLowerCase().includes(search.toLowerCase()) ||
        inc.description.toLowerCase().includes(search.toLowerCase());
      const matchSeverity = filterSeverity === 'All' || inc.severity === filterSeverity;
      const matchStatus = filterStatus === 'All' || inc.status === filterStatus;
      const matchType = filterType === 'All' || inc.incidentType === filterType;
      return matchSearch && matchSeverity && matchStatus && matchType;
    });
  }, [incidents, search, filterSeverity, filterStatus, filterType]);

  const incidentTypes = [...new Set(incidents.map(i => i.incidentType))].sort();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Incident History</h2>
        <p className="text-sm text-slate-500 mt-1">Browse and search all quality incidents</p>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search incidents by ID, type, plant, or description..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
              <X size={16} />
            </button>
          )}
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="px-4 py-2.5 border border-slate-300 rounded-xl text-sm text-slate-600 hover:bg-slate-50 flex items-center gap-2"
        >
          <Filter size={16} /> Filters
          <ChevronDown size={14} className={cn("transition-transform", showFilters && "rotate-180")} />
        </button>
      </div>

      {showFilters && (
        <div className="flex flex-wrap gap-3 p-4 bg-slate-50 rounded-xl">
          <div>
            <label className="text-xs text-slate-500 block mb-1">Severity</label>
            <select value={filterSeverity} onChange={e => setFilterSeverity(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm bg-white">
              <option value="All">All</option>
              {['Critical', 'Major', 'Minor', 'Low'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-slate-500 block mb-1">Status</label>
            <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm bg-white">
              <option value="All">All</option>
              {['Open', 'Investigating', 'Resolved', 'Closed'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-slate-500 block mb-1">Type</label>
            <select value={filterType} onChange={e => setFilterType(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm bg-white">
              <option value="All">All Types</option>
              {incidentTypes.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>
      )}

      {/* Results Count */}
      <p className="text-sm text-slate-500">Showing {filteredIncidents.length} of {incidents.length} incidents</p>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">ID</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Date</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Type</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Plant / Line</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Severity</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Status</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-600">Defect Rate</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredIncidents.map((incident) => (
                <tr key={incident.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs text-blue-600">{incident.id}</td>
                  <td className="px-4 py-3 text-slate-600">{incident.timestamp}</td>
                  <td className="px-4 py-3 text-slate-900 max-w-[180px] truncate">{incident.incidentType}</td>
                  <td className="px-4 py-3 text-slate-600">
                    <div>{incident.plant}</div>
                    <div className="text-xs text-slate-400">{incident.line}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={cn("px-2 py-1 rounded-full text-xs font-medium border", severityColors[incident.severity])}>
                      {incident.severity}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={cn("px-2 py-1 rounded-full text-xs font-medium border", statusColors[incident.status])}>
                      {incident.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <span className={cn("font-semibold", incident.defectRate > 5 ? "text-red-600" : incident.defectRate > 3 ? "text-amber-600" : "text-green-600")}>
                      {incident.defectRate}%
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => onViewAnalysis(incident)}
                      className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-medium hover:bg-blue-700 flex items-center gap-1 ml-auto"
                    >
                      <Eye size={12} /> Analyze
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredIncidents.length === 0 && (
          <div className="p-12 text-center text-slate-500">
            <p className="text-lg">No incidents found</p>
            <p className="text-sm mt-1">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
