import { useState } from 'react';
import { Incident, RootCauseAnalysis } from '../types';
import { 
  AlertTriangle, CheckCircle, XCircle, ChevronDown, ChevronUp, 
  ArrowRight, Shield, Target, TrendingUp, BookOpen, Link
} from 'lucide-react';
import { cn } from '../utils/cn';

interface AnalysisResultProps {
  incident: Incident;
  analysis: RootCauseAnalysis;
}

const severityConfig = {
  Critical: { color: 'bg-red-100 text-red-700 border-red-200', icon: <XCircle size={16} />, bg: 'bg-red-50' },
  Major: { color: 'bg-amber-100 text-amber-700 border-amber-200', icon: <AlertTriangle size={16} />, bg: 'bg-amber-50' },
  Minor: { color: 'bg-blue-100 text-blue-700 border-blue-200', icon: <AlertTriangle size={16} />, bg: 'bg-blue-50' },
  Low: { color: 'bg-green-100 text-green-700 border-green-200', icon: <CheckCircle size={16} />, bg: 'bg-green-50' },
};

const priorityConfig = {
  Immediate: 'bg-red-600 text-white',
  High: 'bg-amber-500 text-white',
  Medium: 'bg-blue-500 text-white',
  Low: 'bg-green-500 text-white',
};

export function AnalysisResult({ incident, analysis }: AnalysisResultProps) {
  const [expandedSection, setExpandedSection] = useState<string | null>('overview');

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  return (
    <div className="space-y-6 animate-in">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-2xl p-6 text-white">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h2 className="text-xl font-bold">Analysis Result</h2>
              <span className="text-sm font-mono text-slate-300">{incident.id}</span>
            </div>
            <p className="text-sm text-slate-300">{incident.incidentType} — {incident.plant} — {incident.line}</p>
          </div>
          <div className="flex items-center gap-3">
            <span className={cn("px-3 py-1 rounded-full text-xs font-semibold border", severityConfig[incident.severity].color)}>
              {incident.severity}
            </span>
            <span className={cn("px-3 py-1 rounded-full text-xs font-semibold", priorityConfig[analysis.priority])}>
              {analysis.priority} Priority
            </span>
          </div>
        </div>

        {/* Confidence Meter */}
        <div className="mt-4 bg-white/10 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-slate-300">Analysis Confidence</span>
            <span className="text-lg font-bold">{analysis.confidence}%</span>
          </div>
          <div className="w-full bg-white/20 rounded-full h-2.5">
            <div 
              className={cn(
                "h-2.5 rounded-full transition-all duration-1000",
                analysis.confidence >= 85 ? "bg-green-400" : analysis.confidence >= 70 ? "bg-amber-400" : "bg-red-400"
              )} 
              style={{ width: `${analysis.confidence}%` }}
            />
          </div>
        </div>
      </div>

      {/* Sections */}
      <div className="space-y-3">
        {/* Overview */}
        <AnalysisSection
          title="Incident Overview"
          icon={<BookOpen size={18} />}
          isExpanded={expandedSection === 'overview'}
          onToggle={() => toggleSection('overview')}
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <InfoItem label="Plant" value={incident.plant} />
            <InfoItem label="Line" value={incident.line} />
            <InfoItem label="Product" value={incident.productType} />
            <InfoItem label="Batch" value={incident.batchId} />
            <InfoItem label="Operator" value={incident.operator} />
            <InfoItem label="Timestamp" value={incident.timestamp} />
            <InfoItem label="Defect Count" value={incident.defectCount.toString()} />
            <InfoItem label="Defect Rate" value={`${incident.defectRate}%`} />
          </div>
          <div className="mt-4 p-3 bg-slate-50 rounded-lg">
            <p className="text-sm text-slate-600">{incident.description}</p>
          </div>
        </AnalysisSection>

        {/* Root Cause */}
        <AnalysisSection
          title="Primary Root Cause"
          icon={<Target size={18} />}
          isExpanded={expandedSection === 'rootcause'}
          onToggle={() => toggleSection('rootcause')}
        >
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
              <p className="text-sm text-blue-800 font-medium leading-relaxed">{analysis.primaryCause}</p>
            </div>
            
            <div>
              <h4 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-3">Contributing Factors</h4>
              <div className="space-y-2">
                {analysis.contributingFactors.map((factor, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-amber-50 rounded-lg">
                    <span className="w-6 h-6 bg-amber-200 text-amber-800 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">{idx + 1}</span>
                    <p className="text-sm text-amber-900">{factor}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl">
              <h4 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">Severity Assessment</h4>
              <p className="text-sm text-slate-600">{analysis.severityAssessment}</p>
              <p className="text-sm text-slate-500 mt-1">Impact: {analysis.estimatedImpact}</p>
            </div>
          </div>
        </AnalysisSection>

        {/* Process Analysis */}
        <AnalysisSection
          title="Process & Quality Analysis"
          icon={<TrendingUp size={18} />}
          isExpanded={expandedSection === 'process'}
          onToggle={() => toggleSection('process')}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-3">Process Parameters</h4>
              <div className="space-y-2">
                {incident.processParameters.map((param, idx) => {
                  const outOfSpec = param.value < param.lowerLimit || param.value > param.upperLimit;
                  return (
                    <div key={idx} className={cn(
                      "flex items-center justify-between px-3 py-2 rounded-lg text-sm",
                      outOfSpec ? "bg-red-50 border border-red-100" : "bg-slate-50"
                    )}>
                      <span className="font-medium">{param.name}: {param.value}{param.unit}</span>
                      {outOfSpec ? (
                        <span className="text-red-500 text-xs font-semibold">OUT OF SPEC</span>
                      ) : (
                        <span className="text-green-500 text-xs">Within range</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-3">Quality Metrics</h4>
              <div className="space-y-2">
                {incident.qualityMetrics.map((metric, idx) => (
                  <div key={idx} className={cn(
                    "flex items-center justify-between px-3 py-2 rounded-lg text-sm",
                    metric.breached ? "bg-red-50 border border-red-100" : "bg-green-50 border border-green-100"
                  )}>
                    <span className="font-medium">{metric.metric}: {metric.value}{metric.unit}</span>
                    {metric.breached ? (
                      <span className="text-red-500 text-xs font-semibold">BREACHED</span>
                    ) : (
                      <span className="text-green-500 text-xs">Within threshold</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </AnalysisSection>

        {/* Recommended Actions */}
        <AnalysisSection
          title="Recommended Actions"
          icon={<ArrowRight size={18} />}
          isExpanded={expandedSection === 'actions'}
          onToggle={() => toggleSection('actions')}
        >
          <div className="space-y-3">
            {analysis.recommendedActions.map((action, idx) => (
              <div key={idx} className="flex items-start gap-3 p-4 bg-white border border-slate-200 rounded-xl shadow-sm">
                <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center text-sm font-bold flex-shrink-0">
                  {idx + 1}
                </div>
                <p className="text-sm text-slate-700 pt-1">{action}</p>
              </div>
            ))}
          </div>
        </AnalysisSection>

        {/* Prevention */}
        <AnalysisSection
          title="Prevention Measures"
          icon={<Shield size={18} />}
          isExpanded={expandedSection === 'prevention'}
          onToggle={() => toggleSection('prevention')}
        >
          <div className="space-y-3">
            {analysis.preventionMeasures.map((measure, idx) => (
              <div key={idx} className="flex items-start gap-3 p-4 bg-green-50 border border-green-100 rounded-xl">
                <CheckCircle size={18} className="text-green-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-green-800">{measure}</p>
              </div>
            ))}
          </div>
        </AnalysisSection>

        {/* Related Incidents */}
        <AnalysisSection
          title="Related Incidents"
          icon={<Link size={18} />}
          isExpanded={expandedSection === 'related'}
          onToggle={() => toggleSection('related')}
        >
          <div className="flex gap-3">
            {analysis.relatedIncidents.map((id, idx) => (
              <div key={idx} className="px-4 py-2 bg-slate-100 rounded-lg text-sm font-mono text-slate-700">
                {id}
              </div>
            ))}
          </div>
        </AnalysisSection>
      </div>
    </div>
  );
}

function AnalysisSection({ title, icon, isExpanded, onToggle, children }: {
  title: string; icon: React.ReactNode; isExpanded: boolean; onToggle: () => void; children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">{icon}</div>
          <h3 className="text-sm font-semibold text-slate-900">{title}</h3>
        </div>
        {isExpanded ? <ChevronUp size={18} className="text-slate-400" /> : <ChevronDown size={18} className="text-slate-400" />}
      </button>
      {isExpanded && <div className="p-5 border-t border-slate-100">{children}</div>}
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-slate-500">{label}</p>
      <p className="text-sm font-semibold text-slate-900 mt-0.5">{value}</p>
    </div>
  );
}
