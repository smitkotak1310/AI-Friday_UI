import React from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Clock, AlertOctagon } from 'lucide-react';
import { DashboardStats } from '../types';
import { cn } from '../utils/cn';

interface DashboardHeaderProps {
  stats: DashboardStats;
}

const severityColors: Record<string, string> = {
  Critical: 'text-red-400',
  Major: 'text-amber-400',
  Minor: 'text-blue-400',
  Low: 'text-green-400',
};

export function DashboardHeader({ stats }: DashboardHeaderProps) {
  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Quality Operations Dashboard</h2>
        <p className="text-sm text-slate-500 mt-1">Real-time monitoring of manufacturing quality incidents and root cause analysis</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPICard
          title="Total Incidents"
          value={stats.totalIncidents}
          icon={<AlertTriangle size={24} />}
          color="blue"
          trend={stats.defectTrend.length > 1 ? stats.defectTrend[stats.defectTrend.length - 1] > stats.defectTrend[stats.defectTrend.length - 2] : false}
          trendLabel="vs last month"
        />
        <KPICard
          title="Open Incidents"
          value={stats.openIncidents}
          icon={<Clock size={24} />}
          color="amber"
          trend={stats.openIncidents > 5}
          trendLabel="needs attention"
        />
        <KPICard
          title="Critical Issues"
          value={stats.criticalIncidents}
          icon={<AlertOctagon size={24} />}
          color="red"
          trend={stats.criticalIncidents > 0}
          trendLabel="requires action"
        />
        <KPICard
          title="Avg Resolution"
          value={`${stats.avgResolutionTime}h`}
          icon={<CheckCircle size={24} />}
          color="green"
          trend={stats.avgResolutionTime > 24}
          trendLabel="target: 24h"
        />
      </div>

      {/* Summary Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500 mb-1">Top Defect Type</p>
          <p className="text-lg font-semibold text-slate-900">{stats.topDefectType}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500 mb-1">Most Affected Line</p>
          <p className="text-lg font-semibold text-slate-900">{stats.mostAffectedLine}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500 mb-1">Severity Distribution</p>
          <div className="flex gap-3 mt-1">
            {stats.severityDistribution.map(s => (
              <span key={s.name} className={cn("text-xs font-medium", severityColors[s.name])}>
                {s.name}: {s.value}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function KPICard({ title, value, icon, color, trend, trendLabel }: {
  title: string; value: string | number; icon: React.ReactNode; color: string; trend: boolean; trendLabel: string;
}) {
  const colorClasses: Record<string, string> = {
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    amber: 'bg-amber-50 text-amber-600 border-amber-200',
    red: 'bg-red-50 text-red-600 border-red-200',
    green: 'bg-green-50 text-green-600 border-green-200',
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-3">
        <p className="text-sm text-slate-500">{title}</p>
        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", colorClasses[color])}>
          {icon}
        </div>
      </div>
      <p className="text-3xl font-bold text-slate-900">{value}</p>
      <div className="flex items-center gap-1 mt-2">
        {trend ? <TrendingUp size={14} className="text-red-500" /> : <TrendingDown size={14} className="text-green-500" />}
        <span className={cn("text-xs", trend ? "text-red-500" : "text-green-500")}>{trendLabel}</span>
      </div>
    </div>
  );
}
