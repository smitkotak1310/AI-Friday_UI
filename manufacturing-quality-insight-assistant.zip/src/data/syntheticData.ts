import { Incident, ProcessParameter, QualityMetric, Status } from '../types';

function randomBetween(min: number, max: number): number {
  return Math.random() * (max - min) + min;
}

function randomInt(min: number, max: number): number {
  return Math.floor(randomBetween(min, max));
}

function randomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

function formatDate(date: Date): string {
  return date.toISOString().split('T')[0] + ' ' + 
    date.toTimeString().split(' ')[0].substring(0, 5);
}

function generateProcessParameters(_incidentType: string, isDeviation: boolean): ProcessParameter[] {
  const params: ProcessParameter[] = [];
  
  const baseParams: Record<string, ProcessParameter> = {
    temperature: {
      name: 'Temperature', value: 0, unit: '°C', lowerLimit: 180, upperLimit: 220, target: 200
    },
    pressure: {
      name: 'Pressure', value: 0, unit: 'MPa', lowerLimit: 4.5, upperLimit: 6.0, target: 5.25
    },
    speed: {
      name: 'Line Speed', value: 0, unit: 'm/min', lowerLimit: 8, upperLimit: 15, target: 12
    },
    humidity: {
      name: 'Humidity', value: 0, unit: '%RH', lowerLimit: 30, upperLimit: 60, target: 45
    },
    vibration: {
      name: 'Vibration', value: 0, unit: 'mm/s', lowerLimit: 0, upperLimit: 4.5, target: 2.0
    },
    current: {
      name: 'Current Draw', value: 0, unit: 'A', lowerLimit: 8, upperLimit: 15, target: 11.5
    },
    voltage: {
      name: 'Voltage', value: 0, unit: 'V', lowerLimit: 210, upperLimit: 240, target: 225
    },
    flowRate: {
      name: 'Flow Rate', value: 0, unit: 'L/min', lowerLimit: 15, upperLimit: 25, target: 20
    },
  };

  const keys = Object.keys(baseParams);
  const numParams = randomInt(3, 6);
  const selectedKeys: string[] = [];
  
  while (selectedKeys.length < numParams) {
    const key = keys[randomInt(0, keys.length)];
    if (!selectedKeys.includes(key)) selectedKeys.push(key);
  }

  for (const key of selectedKeys) {
    const param = { ...baseParams[key] };
    if (isDeviation && Math.random() > 0.4) {
      const deviation = randomBetween(1.1, 1.6);
      const direction = Math.random() > 0.5 ? 1 : -1;
      param.value = +(param.target + direction * (param.upperLimit - param.target) * deviation * randomBetween(0.3, 1)).toFixed(2);
    } else {
      const range = param.upperLimit - param.lowerLimit;
      param.value = +(param.lowerLimit + range * randomBetween(0.2, 0.8)).toFixed(2);
    }
    params.push(param);
  }

  return params;
}

function generateQualityMetrics(_incidentType: string, severity: string): QualityMetric[] {
  const metrics: QualityMetric[] = [];
  const severityMultiplier = severity === 'Critical' ? 3 : severity === 'Major' ? 2 : severity === 'Minor' ? 1.5 : 1;

  const numMetrics = randomInt(3, 6);
  const metricTemplates = [
    { metric: 'Defect Rate', base: [0.5, 5], unit: '%', threshold: 2.0 },
    { metric: 'First Pass Yield', base: [85, 99.5], unit: '%', threshold: 95.0 },
    { metric: 'Scrap Rate', base: [0.5, 4], unit: '%', threshold: 1.5 },
    { metric: 'Rework Rate', base: [1, 8], unit: '%', threshold: 3.0 },
    { metric: 'CPK Index', base: [0.5, 2.0], unit: '', threshold: 1.33 },
    { metric: 'PPM Defects', base: [500, 5000], unit: 'PPM', threshold: 1000 },
  ];

  for (let i = 0; i < numMetrics; i++) {
    const t = metricTemplates[i];
    const rawVal = t.metric === 'PPM Defects' 
      ? Math.round(randomBetween(t.base[0], t.base[1]) * severityMultiplier)
      : +(randomBetween(t.base[0], t.base[1]) * (t.metric === 'First Pass Yield' ? 1/(severity === 'Critical' ? 1.1 : 1) : 1) * (t.metric === 'CPK Index' ? 1/(severity === 'Critical' ? 1.5 : 1) : 1)).toFixed(2);
    const breached = t.metric === 'First Pass Yield' || t.metric === 'CPK Index' 
      ? rawVal < t.threshold 
      : rawVal > t.threshold;
    metrics.push({ metric: t.metric, value: rawVal, unit: t.unit, threshold: t.threshold, breached });
  }

  return metrics;
}

const OPERATORS = [
  'James Wilson', 'Maria Garcia', 'Robert Chen', 'Sarah Johnson',
  'David Patel', 'Emily Thompson', 'Michael Brown', 'Lisa Anderson',
  'Kevin O\'Brien', 'Aisha Khan', 'Thomas Lee', 'Jennifer Martinez'
];

const PRODUCT_TYPES = [
  'Automotive Parts', 'Precision Components', 'Plastic Components',
  'Structural Steel', 'Surface Treatment', 'Electronic Boards', 'Electronic Testing'
];

const BATCH_PREFIXES = ['BT', 'LOT', 'BCH', 'RUN'];

function generateBatchId(): string {
  const prefix = BATCH_PREFIXES[randomInt(0, BATCH_PREFIXES.length)];
  return `${prefix}-${new Date().getFullYear()}-${String(randomInt(1000, 9999))}`;
}

const descriptions: Record<string, string[]> = {
  'Defect Spike': [
    'Sudden increase in surface defects detected on production line during routine inspection. Multiple units showing similar failure patterns within a short time window.',
    'Quality checkpoint flagged unusual defect concentration in batch. Visual inspection revealed clustering of scratches and dents on consecutive units.',
    'Automated vision system triggered alert for elevated defect rate. Pattern analysis shows defects concentrated in specific zones of the product.',
  ],
  'Process Deviation': [
    'Process control system detected parameters drifting beyond acceptable operating window. Temperature and pressure readings showing sustained deviation from setpoints.',
    'Statistical process control chart flagged out-of-control condition. Multiple consecutive readings outside 2-sigma control limits observed.',
    'Real-time monitoring system alerted to abnormal process signature. Correlation analysis shows deviation started after scheduled maintenance event.',
  ],
  'Equipment Failure': [
    'CNC machine spindle showing abnormal vibration signatures followed by premature tool wear. Accelerometer data confirms bearing degradation pattern.',
    'Hydraulic press experiencing intermittent pressure drops causing incomplete forming operations. Pressure sensor logs show gradual decline over 48 hours.',
    'Conveyor system motor overheating causing speed variations. Thermal imaging confirms hot spot on motor bearing housing.',
  ],
  'Material Anomaly': [
    'Incoming material inspection detected hardness variation beyond specification. Multiple samples from same supplier lot showing inconsistent properties.',
    'Raw material certificate of analysis shows composition variance. Spectrometer readings indicate trace element contamination in steel alloy batch.',
    'Supplier material substitution detected without proper notification. Physical testing confirms different mechanical properties than specified grade.',
  ],
  'Dimensional Out-of-Tolerance': [
    'Coordinate measuring machine flagged dimensional drift on critical features. Bore diameter trending toward upper tolerance limit over last 50 parts.',
    'Go/No-Go gauge rejection rate spiked during shift change. Statistical analysis shows systematic shift in mean dimension by 0.02mm.',
    'Laser scanning inspection revealed warpage in injection molded components. Dimensional mapping shows asymmetric shrinkage pattern.',
  ],
  'Surface Defect': [
    'Visual inspection identified pitting and discoloration on coated surfaces. Microscopic analysis reveals substrate contamination beneath coating layer.',
    'Surface roughness measurements exceeding specification. Profilometer data shows Ra values trending above acceptable threshold.',
    'Paint adhesion test failures detected on production batch. Cross-hatch testing shows coating delamination in localized areas.',
  ],
  'Electrical Failure': [
    'Continuity test failures detected on PCB assembly batch. Automated test equipment shows open circuit on specific net traces.',
    'Insulation resistance testing revealed breakdown in motor windings. Megger readings below minimum specification on 15% of tested units.',
    'Short circuit failures during functional testing. Thermal imaging identifies localized heating at component junction points.',
  ],
  'Contamination': [
    'Particle count analysis shows elevated contamination in cleanroom environment. Airborne particle monitoring exceeds ISO class specification.',
    'Chemical residue detected on component surfaces during cleaning validation. FTIR analysis identifies unknown organic compound contamination.',
    'Cross-contamination suspected between production runs. Swab test results show trace amounts of previous batch material on equipment surfaces.',
  ],
  'Assembly Error': [
    'Torque verification station flagged inconsistent bolt tightening. Digital torque wrench data shows 20% of fasteners below specification.',
    'Component misalignment detected during final assembly verification. Vision system shows positional deviation exceeding tolerance stack-up.',
    'Missing component detection triggered on automated assembly line. Weight verification confirms material absence in assembly sequence.',
  ],
  'Calibration Drift': [
    'Calibration verification check found measurement instrument reading outside tolerance. Standard reference comparison shows 0.5% drift from last calibration.',
    'Gauge R&R study revealed excessive measurement system variation. Repeatability and reproducibility exceed acceptable %GRR threshold.',
    'Periodic calibration audit discovered drift in temperature sensors. Comparison with NIST-traceable standard shows systematic offset.',
  ],
};

export function generateIncidents(count: number = 40): Incident[] {
  const incidents: Incident[] = [];
  const types = [
    'Defect Spike', 'Process Deviation', 'Equipment Failure', 'Material Anomaly',
    'Dimensional Out-of-Tolerance', 'Surface Defect', 'Electrical Failure',
    'Contamination', 'Assembly Error', 'Calibration Drift'
  ];
  const severities: Array<'Critical' | 'Major' | 'Minor' | 'Low'> = ['Critical', 'Major', 'Minor', 'Low'];
  const lines = ['Line A', 'Line B', 'Line C', 'Line D', 'Line E', 'Line F', 'Line G', 'Line H'];
  const plants = ['Detroit Assembly', 'Chicago Precision', 'Houston Industrial', 'Portland Electronics'];

  const now = new Date();
  const sixMonthsAgo = new Date(now);
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

  for (let i = 0; i < count; i++) {
    const incidentType = types[randomInt(0, types.length)];
    const severity = severities[randomInt(0, severities.length)];
    const isDeviation = Math.random() > 0.5;
    const date = randomDate(sixMonthsAgo, now);
    const statusRoll = Math.random();
    const status: Status = statusRoll > 0.7 ? 'Open' : statusRoll > 0.5 ? 'Investigating' : statusRoll > 0.2 ? 'Resolved' : 'Closed';
    
    const lineIdx = randomInt(0, lines.length);
    const descs = descriptions[incidentType] || descriptions['Defect Spike'];
    const desc = descs[randomInt(0, descs.length)];

    const defectRate = severity === 'Critical' ? randomBetween(5, 12) : 
                       severity === 'Major' ? randomBetween(3, 7) :
                       severity === 'Minor' ? randomBetween(1.5, 4) : randomBetween(0.5, 2);

    const incident: Incident = {
      id: `INC-${String(2026000 + i).slice(-4)}`,
      timestamp: formatDate(date),
      plant: plants[lineIdx],
      line: lines[lineIdx],
      productType: PRODUCT_TYPES[randomInt(0, PRODUCT_TYPES.length)],
      incidentType: incidentType as any,
      severity,
      status,
      description: desc,
      defectCount: randomInt(5, 150),
      defectRate: +defectRate.toFixed(2),
      batchId: generateBatchId(),
      operator: OPERATORS[randomInt(0, OPERATORS.length)],
      processParameters: generateProcessParameters(incidentType, isDeviation),
      qualityMetrics: generateQualityMetrics(incidentType, severity),
      resolutionTime: status === 'Resolved' || status === 'Closed' ? randomInt(2, 72) : undefined,
    };

    incidents.push(incident);
  }

  incidents.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  return incidents;
}

export const INCIDENTS = generateIncidents(40);
