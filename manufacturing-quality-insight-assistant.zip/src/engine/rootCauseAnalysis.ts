import { Incident, RootCauseAnalysis, ProcessParameter, QualityMetric } from '../types';

const ROOT_CAUSE_KNOWLEDGE_BASE: Record<string, {
  causes: string[];
  factors: string[];
  actions: string[];
  prevention: string[];
  severityNote: string;
  impact: string;
}> = {
  'Defect Spike': {
    causes: [
      'Tool wear or degradation causing dimensional variation in machined parts',
      'Raw material batch inconsistency affecting surface quality',
      'Environmental condition changes (temperature/humidity) affecting process stability',
      'Operator procedure deviation during setup or changeover',
    ],
    factors: [
      'Time since last tool change exceeds recommended interval',
      'Material certificate of analysis not verified for current batch',
      'HVAC system maintenance overdue in production area',
      'Recent operator reassignment or training gap identified',
    ],
    actions: [
      'Immediately inspect and replace worn cutting tools or forming dies',
      'Quarantine affected batch and perform 100% inspection on remaining units',
      'Verify material CoA against incoming inspection records',
      'Review environmental monitoring data for temperature/humidity excursions',
      'Conduct operator re-certification on affected process steps',
    ],
    prevention: [
      'Implement predictive tool wear monitoring with automated replacement triggers',
      'Establish mandatory material CoA verification workflow before production release',
      'Install real-time environmental monitoring with automated alerts',
      'Implement standardized changeover checklist with verification steps',
    ],
    severityNote: 'Defect spikes typically indicate a sudden process change that requires immediate containment.',
    impact: 'High — Direct impact on product quality, potential customer returns, and production yield loss.',
  },
  'Process Deviation': {
    causes: [
      'Control loop tuning drift causing process variable oscillation',
      'Sensor calibration error providing incorrect feedback to control system',
      'Utility supply variation (steam, compressed air, cooling water) affecting process stability',
      'Recipe parameter corruption or unauthorized modification',
    ],
    factors: [
      'PID controller tuning parameters have not been reviewed in 6+ months',
      'Calibration due date approaching or overdue for critical sensors',
      'Utility system maintenance or modification activity in past 24 hours',
      'Recipe management system access log shows recent changes',
    ],
    actions: [
      'Review control system logs for controller output patterns and saturation events',
      'Verify sensor calibration against reference standard immediately',
      'Check utility supply parameters and verify stability during deviation period',
      'Audit recipe management system for unauthorized or accidental changes',
    ],
    prevention: [
      'Implement automated control loop performance monitoring with auto-tuning capability',
      'Establish predictive calibration scheduling based on sensor drift analysis',
      'Install utility supply monitoring with upstream alarm before process impact',
      'Implement recipe change control with dual authorization requirement',
    ],
    severityNote: 'Process deviations can cascade into multiple quality issues if not contained quickly.',
    impact: 'Medium to High — May affect entire production batch depending on detection time.',
  },
  'Equipment Failure': {
    causes: [
      'Preventive maintenance interval exceeded causing progressive component degradation',
      'Component fatigue failure due to cyclic loading beyond design life',
      'Lubrication system failure causing accelerated bearing or gear wear',
      'Electrical component failure (motor, drive, PLC) due to power quality issues',
    ],
    factors: [
      'PM work order history shows overdue or deferred maintenance tasks',
      'Equipment runtime hours approaching or exceeding component design life',
      'Oil analysis or vibration trending data shows accelerating degradation',
      'Power quality monitoring reveals voltage sags, surges, or harmonic distortion',
    ],
    actions: [
      'Execute emergency work order and replace failed component immediately',
      'Inspect adjacent components for collateral damage from failure event',
      'Review maintenance history and update PM schedule based on failure mode',
      'Analyze root cause using FMEA methodology to prevent recurrence',
    ],
    prevention: [
      'Implement condition-based maintenance using vibration and thermal monitoring',
      'Establish component life tracking with automated replacement scheduling',
      'Deploy oil analysis program with trending for early degradation detection',
      'Install power quality monitoring with UPS protection for critical equipment',
    ],
    severityNote: 'Equipment failures cause immediate production stoppage and require rapid response.',
    impact: 'High — Production downtime, potential safety hazard, and repair cost.',
  },
  'Material Anomaly': {
    causes: [
      'Supplier process change affecting material properties without notification',
      'Material handling or storage conditions causing degradation (moisture, temperature)',
      'Material mix-up or incorrect grade delivered to production floor',
      'Incoming inspection sampling plan inadequate to detect lot-to-lot variation',
    ],
    factors: [
      'Supplier engineering change notice (ECN) received but not fully assessed',
      'Material storage area environmental conditions outside specification',
      'Material identification labels damaged or missing on incoming stock',
      'Sampling plan based on AQL may miss localized material defects',
    ],
    actions: [
      'Immediately quarantine all material from suspect lot and supplier',
      'Perform comprehensive material testing (composition, mechanical, physical)',
      'Contact supplier for investigation and request material traceability data',
      'Implement 100% incoming inspection for affected material type',
    ],
    prevention: [
      'Implement supplier change notification protocol with mandatory assessment',
      'Install environmental monitoring in material storage areas with alerts',
      'Deploy barcode/RFID material tracking system for positive identification',
      'Revise incoming inspection sampling plan based on supplier quality performance',
    ],
    severityNote: 'Material anomalies can affect multiple production batches and require supplier involvement.',
    impact: 'High — May require product recall and supplier quality audit.',
  },
  'Dimensional Out-of-Tolerance': {
    causes: [
      'Machine tool thermal growth affecting positional accuracy over production run',
      'Fixture wear or damage causing part positioning errors',
      'Cutting tool deflection under load causing dimensional drift',
      'Thermal expansion of part material during machining not compensated',
    ],
    factors: [
      'Machine warm-up cycle not completed before production start',
      'Fixture inspection overdue — wear plates or locating pins may be degraded',
      'Tool holder runout exceeds specification causing tool deflection',
      'Coolant temperature variation affecting part thermal state during machining',
    ],
    actions: [
      'Stop production and perform machine capability study (Cpk analysis)',
      'Inspect and replace worn fixture components or locating elements',
      'Verify tool holder condition and runout using precision indicator',
      'Review coolant system temperature control and flow rate',
    ],
    prevention: [
      'Implement automated machine warm-up verification before production release',
      'Establish fixture inspection schedule with wear limit tracking',
      'Deploy in-process gauging with automatic tool offset compensation',
      'Install coolant temperature control with closed-loop regulation',
    ],
    severityNote: 'Dimensional issues are systematic and affect all parts produced during the deviation period.',
    impact: 'Medium to High — Scrap and rework cost, potential assembly interference.',
  },
  'Surface Defect': {
    causes: [
      'Contamination in coating or finishing process causing adhesion failure',
      'Surface preparation inadequate (cleaning, blasting, etching)',
      'Coating material expired or improperly mixed before application',
      'Environmental contamination (dust, oil mist) in finishing area',
    ],
    factors: [
      'Surface cleanliness test (contact angle, dyne level) not performed before coating',
      'Coating material batch approaching or past shelf life expiration',
      'Mixing ratio verification not documented for multi-component coatings',
      'Air quality monitoring in finishing area shows elevated particle count',
    ],
    actions: [
      'Stop coating operations and verify surface preparation process compliance',
      'Test coating material properties (viscosity, solids content, cure time)',
      'Perform adhesion testing on suspect batch per ASTM standards',
      'Inspect finishing area for contamination sources and implement corrective cleaning',
    ],
    prevention: [
      'Implement mandatory surface cleanliness verification before coating application',
      'Establish coating material shelf life tracking with automated expiration alerts',
      'Deploy automated mixing ratio verification for multi-component coatings',
      'Install air filtration upgrade in finishing area with particle monitoring',
    ],
    severityNote: 'Surface defects are often cosmetic but can affect functional performance.',
    impact: 'Medium — Rework or scrap cost, potential customer aesthetic complaints.',
  },
  'Electrical Failure': {
    causes: [
      'Component quality defect (capacitor, resistor, IC) causing functional failure',
      'Solder joint defect (cold solder, bridging, void) from reflow process issue',
      'ESD damage during handling or assembly causing latent electrical failure',
      'Design margin inadequate for operating environment (temperature, vibration)',
    ],
    factors: [
      'Component supplier quality alert or recall notice received',
      'Reflow oven temperature profile drift detected in recent verification',
      'ESD control audit findings — wrist strap or mat grounding issues',
      'Design FMEA shows marginal operating conditions for component',
    ],
    actions: [
      'Perform failure analysis on failed units (X-ray, cross-section, electrical testing)',
      'Verify reflow oven temperature profile and recalibrate if necessary',
      'Audit ESD control program and verify all grounding points',
      'Review component supplier quality data and incoming inspection results',
    ],
    prevention: [
      'Implement automated optical inspection (AOI) after soldering operations',
      'Establish continuous reflow oven monitoring with SPC charting',
      'Enhance ESD program with continuous monitoring and regular audits',
      'Perform design margin analysis and derating study for critical components',
    ],
    severityNote: 'Electrical failures can be safety-critical and may require product recall.',
    impact: 'High — Safety concern, potential product recall, warranty claims.',
  },
  'Contamination': {
    causes: [
      'Cross-contamination from previous production batch due to inadequate cleaning',
      'Environmental contamination from HVAC system or building maintenance',
      'Operator-borne contamination (gloves, clothing, personal items)',
      'Supplier material contamination (foreign material, chemical residue)',
    ],
    factors: [
      'Cleaning validation study overdue for equipment changeover procedure',
      'HVAC filter replacement overdue or differential pressure out of spec',
      'Cleanroom gowning procedure audit findings in recent inspection',
      'Supplier audit reveals material handling practices not compliant',
    ],
    actions: [
      'Stop production and execute enhanced cleaning procedure on affected equipment',
      'Perform environmental monitoring swab and air sample analysis',
      'Quarantine potentially contaminated product and perform release testing',
      'Initiate contamination source investigation using particle identification analysis',
    ],
    prevention: [
      'Implement automated cleaning verification (TOC, conductivity, visual)',
      'Establish predictive HVAC filter replacement based on differential pressure trending',
      'Deploy automated gowning compliance monitoring in cleanroom entry',
      'Require supplier contamination control program certification',
    ],
    severityNote: 'Contamination events can affect patient safety in regulated industries.',
    impact: 'High — Product quarantine, potential recall, regulatory impact.',
  },
  'Assembly Error': {
    causes: [
      'Work instruction ambiguity or outdated procedure causing incorrect assembly',
      'Component variation (dimensional, material) creating assembly fit issues',
      'Fatigue or ergonomic factors leading to operator assembly mistakes',
      'Poka-yoke (error-proofing) device failure or bypass in assembly station',
    ],
    factors: [
      'Work instruction revision not communicated to production team',
      'Component supplier engineering change not reflected in assembly procedure',
      'Operator ergonomic assessment overdue for assembly station',
      'Poka-yoke device last functional test date exceeds verification interval',
    ],
    actions: [
      'Verify all assembled units against work instruction and BOM requirements',
      'Conduct assembly process audit with operator observation',
      'Test and verify all poka-yoke devices on affected assembly stations',
      'Review and update work instructions with visual aids and error-proofing',
    ],
    prevention: [
      'Implement digital work instructions with version control and confirmation steps',
      'Establish engineering change impact assessment for assembly procedures',
      'Deploy ergonomic improvement program with regular operator assessments',
      'Implement automated poka-yoke verification with production interlock',
    ],
    severityNote: 'Assembly errors can propagate through downstream processes.',
    impact: 'Medium — Rework cost, production delay, potential field failures.',
  },
  'Calibration Drift': {
    causes: [
      'Measurement instrument aging causing gradual accuracy degradation',
      'Environmental condition changes (temperature, vibration) affecting instrument accuracy',
      'Improper handling or storage causing mechanical damage to measurement device',
      'Reference standard drift affecting calibration traceability chain',
    ],
    factors: [
      'Instrument calibration interval based on time rather than usage or drift data',
      'Calibration environment temperature not controlled or monitored',
      'Instrument handling procedure not followed during transport or storage',
      'Reference standard calibration certificate approaching expiration',
    ],
    actions: [
      'Remove affected instrument from service and send for recalibration',
      'Assess impact on products measured with drifted instrument since last calibration',
      'Verify reference standard calibration status and traceability',
      'Implement immediate recalibration of all instruments of same type',
    ],
    prevention: [
      'Implement risk-based calibration intervals using historical drift data analysis',
      'Deploy environmental monitoring at calibration locations with alarms',
      'Establish instrument handling and storage procedures with training',
      'Implement automated calibration management system with expiration alerts',
    ],
    severityNote: 'Calibration drift undermines confidence in all measurements taken with the instrument.',
    impact: 'Medium — Measurement uncertainty, potential for undetected non-conformances.',
  },
};

function analyzeProcessParameters(params: ProcessParameter[]): { outOfSpec: ProcessParameter[]; analysis: string } {
  const outOfSpec = params.filter(p => p.value < p.lowerLimit || p.value > p.upperLimit);
  const nearLimit = params.filter(p => {
    const range = p.upperLimit - p.lowerLimit;
    const margin = range * 0.1;
    return (p.value >= p.upperLimit - margin || p.value <= p.lowerLimit + margin) && 
           !(p.value < p.lowerLimit || p.value > p.upperLimit);
  });

  let analysis = '';
  if (outOfSpec.length > 0) {
    analysis += `Found ${outOfSpec.length} parameter(s) outside specification: ${outOfSpec.map(p => p.name).join(', ')}. `;
  }
  if (nearLimit.length > 0) {
    analysis += `Found ${nearLimit.length} parameter(s) near specification limits: ${nearLimit.map(p => p.name).join(', ')}. `;
  }
  if (outOfSpec.length === 0 && nearLimit.length === 0) {
    analysis = 'All process parameters within acceptable operating range.';
  }
  return { outOfSpec, analysis };
}

function analyzeQualityMetrics(metrics: QualityMetric[]): { breached: QualityMetric[]; analysis: string } {
  const breached = metrics.filter(m => m.breached);
  let analysis = '';
  if (breached.length > 0) {
    analysis += `${breached.length} quality metric(s) breached threshold: `;
    analysis += breached.map(m => `${m.metric} = ${m.value}${m.unit} (threshold: ${m.threshold}${m.unit})`).join(', ') + '. ';
  } else {
    analysis = 'All quality metrics within acceptable thresholds.';
  }
  return { breached, analysis };
}

function generateAnalysis(incident: Incident): RootCauseAnalysis {
  const kb = ROOT_CAUSE_KNOWLEDGE_BASE[incident.incidentType] || ROOT_CAUSE_KNOWLEDGE_BASE['Defect Spike'];
  
  const paramAnalysis = analyzeProcessParameters(incident.processParameters);
  const metricAnalysis = analyzeQualityMetrics(incident.qualityMetrics);

  const outOfSpecParams = paramAnalysis.outOfSpec.map(p => {
    const deviation = p.value > p.upperLimit 
      ? `${((p.value - p.upperLimit) / (p.upperLimit - p.lowerLimit) * 100).toFixed(1)}% above upper limit`
      : `${((p.lowerLimit - p.value) / (p.upperLimit - p.lowerLimit) * 100).toFixed(1)}% below lower limit`;
    return `${p.name}: ${p.value}${p.unit} (${deviation})`;
  });

  const confidence = Math.min(95, 70 + (paramAnalysis.outOfSpec.length * 5) + (metricAnalysis.breached.length * 3));
  
  const primaryCauseIdx = Math.floor((incident.severity === 'Critical' ? 0 : incident.severity === 'Major' ? 1 : 2));
  const primaryCause = kb.causes[Math.min(primaryCauseIdx, kb.causes.length - 1)];
  
  const contributingFactors = kb.factors.slice(0, 3);
  const recommendedActions = [...kb.actions.slice(0, 3)];
  
  if (outOfSpecParams.length > 0) {
    recommendedActions.unshift(`Correct out-of-spec process parameters: ${outOfSpecParams.join('; ')}`);
  }
  if (metricAnalysis.breached.length > 0) {
    recommendedActions.push(`Address breached quality metrics to restore process capability`);
  }

  const relatedIncidents = [
    `INC-${String(2026000 + Math.floor(Math.random() * 40)).slice(-4)}`,
    `INC-${String(2026000 + Math.floor(Math.random() * 40)).slice(-4)}`,
  ].filter((v, i, a) => a.indexOf(v) === i && v !== incident.id);

  const priority = incident.severity === 'Critical' ? 'Immediate' : 
                   incident.severity === 'Major' ? 'High' : 
                   incident.severity === 'Minor' ? 'Medium' : 'Low';

  const details = `
**Root Cause Analysis Report for ${incident.id}**

**Incident Overview:**
Type: ${incident.incidentType} | Severity: ${incident.severity} | Plant: ${incident.plant} | Line: ${incident.line}
Reported: ${incident.timestamp} | Operator: ${incident.operator} | Batch: ${incident.batchId}

**Description:** ${incident.description}

**Process Parameter Analysis:**
${paramAnalysis.analysis}
${outOfSpecParams.length > 0 ? '\nOut-of-Spec Details:\n' + outOfSpecParams.map(p => `  • ${p}`).join('\n') : ''}

**Quality Metric Analysis:**
${metricAnalysis.analysis}

**Primary Root Cause:**
${primaryCause}

**Contributing Factors:**
${kb.factors.slice(0, 3).map((f, i) => `${i + 1}. ${f}`).join('\n')}

**Severity Assessment:**
${kb.severityNote}
Current severity rating: ${incident.severity} — ${kb.impact}

**Estimated Business Impact:**
${kb.impact}
Defect Rate: ${incident.defectRate}% | Defect Count: ${incident.defectCount} units
${incident.defectRate > 5 ? '⚠️ Defect rate exceeds 5% — consider production hold' : incident.defectRate > 3 ? '⚡ Defect rate is elevated — monitor closely' : '✓ Defect rate within manageable range'}
  `.trim();

  return {
    incidentId: incident.id,
    confidence,
    primaryCause,
    contributingFactors,
    severityAssessment: kb.severityNote,
    recommendedActions: recommendedActions,
    estimatedImpact: kb.impact,
    preventionMeasures: kb.prevention,
    analysisDetails: details,
    relatedIncidents,
    priority,
  };
}

export function analyzeIncident(incident: Incident): RootCauseAnalysis {
  return generateAnalysis(incident);
}

export function analyzeNewIncident(incidentData: {
  incidentType: string;
  severity: string;
  plant: string;
  line: string;
  productType: string;
  description: string;
  defectCount: number;
  defectRate: number;
  processParameters: ProcessParameter[];
  qualityMetrics: QualityMetric[];
}): RootCauseAnalysis {
  const syntheticIncident: Incident = {
    id: `INC-NEW-${Date.now().toString().slice(-4)}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
    plant: incidentData.plant,
    line: incidentData.line,
    productType: incidentData.productType,
    incidentType: incidentData.incidentType as any,
    severity: incidentData.severity as any,
    status: 'Open',
    description: incidentData.description,
    defectCount: incidentData.defectCount,
    defectRate: incidentData.defectRate,
    batchId: `BT-2026-${Math.floor(Math.random() * 9000 + 1000)}`,
    operator: 'Current Operator',
    processParameters: incidentData.processParameters,
    qualityMetrics: incidentData.qualityMetrics,
  };

  return generateAnalysis(syntheticIncident);
}
