import { LLMInfo, LLMModel, LLMResponse, Incident } from '../types';
import { INCIDENTS } from '../data/syntheticData';

export const LLM_MODELS: LLMInfo[] = [
  {
    id: 'gpt4',
    name: 'GPT-4',
    provider: 'OpenAI',
    avatar: '🟢',
    color: '#10a37f',
    description: 'Advanced reasoning & comprehensive domain knowledge',
    baseAccuracy: 94,
    baseConfidence: 92,
    tokenSpeed: 35,
  },
  {
    id: 'claude3',
    name: 'Claude 3 Opus',
    provider: 'Anthropic',
    avatar: '🟣',
    color: '#8b5cf6',
    description: 'Nuanced analysis with strong safety alignment',
    baseAccuracy: 93,
    baseConfidence: 90,
    tokenSpeed: 30,
  },
  {
    id: 'gemini',
    name: 'Gemini 1.5 Pro',
    provider: 'Google DeepMind',
    avatar: '🔵',
    color: '#4285f4',
    description: 'Multi-modal reasoning with large context window',
    baseAccuracy: 91,
    baseConfidence: 88,
    tokenSpeed: 40,
  },
  {
    id: 'llama3',
    name: 'Llama 3 70B',
    provider: 'Meta AI',
    avatar: '🔴',
    color: '#f97316',
    description: 'Open-source model with strong technical capabilities',
    baseAccuracy: 87,
    baseConfidence: 85,
    tokenSpeed: 45,
  },
  {
    id: 'mistral',
    name: 'Mistral Large',
    provider: 'Mistral AI',
    avatar: '🟡',
    color: '#eab308',
    description: 'Efficient European model with strong logical reasoning',
    baseAccuracy: 88,
    baseConfidence: 86,
    tokenSpeed: 38,
  },
];

// ============================================================
// Manufacturing Quality Knowledge Base
// ============================================================

interface TopicKnowledge {
  causes: string[];
  actions: string[];
}

const KB: Record<string, TopicKnowledge> = {
  defectspike: {
    causes: [
      'Raw material batch variation from supplier — check incoming material certification',
      'Tool wear exceeding replacement schedule — verify last tool change date',
      'Environmental condition changes (humidity, temperature) in production area',
      'Operator training gap or new operator on the line',
      'Machine calibration drift beyond acceptable tolerance',
      'Inadequate preventive maintenance — check PM schedule adherence',
      'Process parameter deviation from standard operating procedure (SOP)',
      'Fixture or jig degradation causing misalignment',
    ],
    actions: [
      'Immediately quarantine affected batch and perform 100% inspection',
      'Conduct stratified sampling across shifts, operators, and material batches',
      'Run capability analysis (Cpk/Ppk) on the defect characteristic',
      'Implement containment: sort, tag, and segregate non-conforming product',
      'Initiate 8D report and assign cross-functional team',
      'Verify supplier CoC and perform incoming inspection review',
      'Review SPC charts for early warning signals in the last 50 samples',
    ],
  },
  processdeviation: {
    causes: [
      'Control loop malfunction in automated process system',
      'Incorrect recipe or program loaded into machine',
      'Sensor drift or faulty measurement feedback',
      'Material property variation outside specified range',
      'Human error in process parameter setup',
      'Software/firmware update introduced unexpected behavior',
      'Cross-contamination between product changeovers',
    ],
    actions: [
      'Hold process and verify all parameters against the approved SOP',
      'Validate sensor readings against calibrated reference instruments',
      'Review change management log for recent program/recipe changes',
      'Execute first article inspection before resuming production',
      'Implement SPC monitoring with tighter control limits temporarily',
      'Verify operator certification for the specific process',
    ],
  },
  equipmentfailure: {
    causes: [
      'Bearing degradation detected too late — vibration monitoring insufficient',
      'Electrical component end-of-life (contactor, relay, PLC module)',
      'Hydraulic/pneumatic system leak causing pressure loss',
      'Coolant system failure leading to thermal overload',
      'Lubrication system malfunction causing accelerated wear',
      'Structural fatigue in load-bearing components',
      'Software/hardware communication failure in automated systems',
    ],
    actions: [
      'Execute emergency shutdown and lockout/tagout (LOTO) procedures',
      'Assess impact on WIP and initiate production rerouting',
      'Perform failure mode analysis on the failed component',
      'Check MTBF and MTTR data — update PM schedule if needed',
      'Implement condition-based monitoring (vibration, thermal, acoustic)',
      'Evaluate redundancy options for critical equipment',
    ],
  },
  contamination: {
    causes: [
      'Cleanroom classification exceeded (particle count too high)',
      'Improper cleaning procedure between product changeovers',
      'Foreign material from packaging or handling materials',
      'Coolant/lubricant contamination with water or debris',
      'HVAC filter failure allowing airborne contaminants',
      'Operator PPE not compliant or improperly used',
    ],
    actions: [
      'Stop production and isolate contaminated material immediately',
      'Perform environmental monitoring (particle count, swab tests)',
      'Review and validate cleaning procedures for the affected area',
      'Trace contamination source using material flow mapping',
      'Increase cleaning frequency and validate effectiveness',
      'Review gowning procedures and conduct refresher training',
    ],
  },
  general: {
    causes: [
      'Inadequate root cause analysis methodology being applied',
      'Lack of standardized work instructions',
      'Insufficient operator training and competency verification',
      'Poor communication during shift handovers',
      'Material traceability gaps in the supply chain',
      'Statistical process control not properly implemented or monitored',
    ],
    actions: [
      'Initiate structured problem-solving (8D, A3, or DMAIC)',
      'Form cross-functional team with quality, engineering, and operations',
      'Conduct Gemba walk to observe the process firsthand',
      'Review historical data for recurring patterns',
      'Implement interim containment action while investigating',
      'Document lessons learned and update control plan',
      'Verify effectiveness of corrective actions with follow-up audits',
    ],
  },
};

const FMEA_GUIDE = [
  'Perform Failure Mode and Effects Analysis (FMEA) to systematically evaluate all potential failure modes',
  'Calculate Risk Priority Number (RPN) = Severity × Occurrence × Detection for each failure mode',
  'Focus corrective actions on failure modes with RPN above the threshold (typically > 100)',
  'Review and update the PFMEA after every quality incident',
];

const SPC_GUIDE = [
  'Review X-bar and R charts for out-of-control signals (Western Electric Rules)',
  'Calculate Process Capability Index (Cpk) — target ≥ 1.33 for stable processes',
  'Identify special cause vs. common cause variation using control chart rules',
  'Implement real-time SPC monitoring with automated alerts',
];

const EIGHT_D_GUIDE = [
  'D0: Prepare — Assess if 8D methodology is appropriate for this incident',
  'D1: Team — Form a cross-functional team with relevant expertise',
  'D2: Problem — Define the problem in measurable terms (5W2H)',
  'D3: Containment — Implement immediate interim containment actions',
  'D4: Root Cause — Use Fishbone diagram, 5-Why, and data analysis',
  'D5: Corrective Action — Select and verify permanent corrective actions',
  'D6: Validate — Confirm effectiveness through data and follow-up',
  'D7: Prevention — Update FMEA, control plans, and standardized work',
  'D8: Recognition — Congratulate the team and share learnings',
];

// ============================================================
// Query Classification Engine
// ============================================================

type QueryIntent =
  | 'root_cause'
  | 'corrective_action'
  | 'incident_inquiry'
  | 'fmea'
  | 'spc'
  | 'eight_d'
  | 'prevention'
  | 'defect_analysis'
  | 'process_improvement'
  | 'general_quality'
  | 'greeting';

interface QueryAnalysis {
  intent: QueryIntent;
  topics: string[];
  incidentRef?: Incident;
  complexity: 'simple' | 'moderate' | 'complex';
}

function classifyQuery(query: string): QueryAnalysis {
  const q = query.toLowerCase();
  const topics: string[] = [];
  let intent: QueryIntent = 'general_quality';
  let complexity: 'simple' | 'moderate' | 'complex' = 'moderate';

  const incidentRef = INCIDENTS.find(inc =>
    q.includes(inc.id.toLowerCase()) ||
    (q.includes('batch') && q.includes(inc.batchId.toLowerCase())) ||
    q.includes(inc.incidentType.toLowerCase())
  );

  if (q.includes('root cause') || q.includes('why did') || q.includes('what caused') || q.includes('reason for')) {
    intent = 'root_cause';
    topics.push('root_cause');
    complexity = 'complex';
  }
  if (q.includes('corrective action') || q.includes('fix') || q.includes('resolve') || q.includes('solution') || q.includes('how to fix')) {
    intent = 'corrective_action';
    topics.push('corrective_action');
    complexity = 'complex';
  }
  if (q.includes('fmea') || q.includes('failure mode') || q.includes('rpn')) {
    intent = 'fmea';
    topics.push('fmea', 'risk_assessment');
    complexity = 'complex';
  }
  if (q.includes('spc') || q.includes('control chart') || q.includes('cpk') || q.includes('process capability')) {
    intent = 'spc';
    topics.push('spc', 'statistical_analysis');
    complexity = 'complex';
  }
  if (q.includes('8d') || q.includes('eight d') || q.includes('problem solving')) {
    intent = 'eight_d';
    topics.push('8d', 'problem_solving');
    complexity = 'complex';
  }
  if (q.includes('prevent') || q.includes('avoid') || q.includes('future')) {
    intent = 'prevention';
    topics.push('prevention', 'continuous_improvement');
    complexity = 'moderate';
  }
  if (q.includes('defect') || q.includes('defective') || q.includes('quality issue')) {
    intent = 'defect_analysis';
    topics.push('defect_analysis');
    complexity = 'moderate';
  }
  if (q.includes('improve') || q.includes('optimize') || q.includes('better')) {
    intent = 'process_improvement';
    topics.push('process_improvement');
    complexity = 'complex';
  }
  if (q.includes('hello') || q.includes('hi') || q.includes('hey')) {
    intent = 'greeting';
    topics.push('greeting');
    complexity = 'simple';
  }
  if (incidentRef) {
    intent = 'incident_inquiry';
    topics.push('incident', incidentRef.incidentType.toLowerCase());
    complexity = 'complex';
  }

  if (q.includes('equipment') || q.includes('machine') || q.includes('tool')) topics.push('equipment');
  if (q.includes('material') || q.includes('supplier') || q.includes('raw material')) topics.push('material');
  if (q.includes('contamination') || q.includes('clean') || q.includes('particle')) topics.push('contamination');
  if (q.includes('dimensional') || q.includes('tolerance') || q.includes('measurement')) topics.push('dimensional');
  if (q.includes('process') || q.includes('parameter') || q.includes('deviation')) topics.push('process');
  if (q.includes('severity') || q.includes('critical') || q.includes('major')) topics.push('severity_assessment');
  if (q.includes('trend') || q.includes('pattern') || q.includes('historical')) topics.push('trend_analysis');
  if (q.includes('six sigma') || q.includes('lean') || q.includes('kaizen')) topics.push('methodology');
  if (q.includes('training') || q.includes('operator') || q.includes('competency')) topics.push('human_factor');
  if (q.includes('cost') || q.includes('impact') || q.includes('financial')) topics.push('cost_impact');
  if (q.includes('report') || q.includes('dashboard') || q.includes('metrics')) topics.push('reporting');

  return { intent, topics, incidentRef, complexity };
}

// ============================================================
// Response Generation Functions
// ============================================================

function generateGreeting(): string {
  return `Hello! 👋 I'm your **Manufacturing Quality Intelligence Assistant**. I can help you with:

• 🔍 **Root Cause Analysis** — Identify causes of quality incidents
• 🛠️ **Corrective Actions** — Recommend step-by-step resolution plans
• 📊 **SPC & Process Capability** — Analyze process stability
• 📋 **8D Problem Solving** — Guide through structured problem-solving
• 🔬 **FMEA Analysis** — Assess failure modes and risk priority
• 📈 **Trend Analysis** — Review historical patterns and metrics
• 🎯 **Defect Classification** — Categorize and prioritize quality issues

Try asking me about specific incidents, defect types, or quality methodologies. You can also reference incidents by their ID (e.g., "INC-001") or batch number for contextual analysis.`;
}

function getKB(incidentType: string): TopicKnowledge {
  const key = incidentType.toLowerCase().replace(/\s+/g, '');
  return KB[key] || KB.general;
}

function generateRootCauseResponse(analysis: QueryAnalysis): string {
  const specificType = analysis.topics.find(t =>
    ['defect', 'contamination', 'equipment', 'process', 'dimensional', 'material'].includes(t)
  );

  let content = `## Root Cause Analysis\n\n`;

  if (analysis.incidentRef) {
    const inc = analysis.incidentRef;
    const kb = getKB(inc.incidentType);
    content += `### Incident: ${inc.incidentType} (${inc.id})\n`;
    content += `**Plant:** ${inc.plant} | **Line:** ${inc.line}\n`;
    content += `**Severity:** ${inc.severity} | **Status:** ${inc.status}\n\n`;
    content += `### Probable Root Causes (Ranked by Likelihood)\n\n`;
    const causes = kb.causes.slice(0, 5);
    causes.forEach((cause, i) => {
      const likelihood = Math.max(30, 85 - i * 12 + Math.floor(Math.random() * 10));
      content += `${i + 1}. **${cause.split('—')[0].trim()}** — Probability: ~${likelihood}%\n`;
      content += `   → ${cause.includes('—') ? cause.split('—')[1].trim() : 'Requires verification through data analysis'}\n\n`;
    });
    content += `### Recommended Investigation Path\n`;
    content += `1. Start with the highest probability cause and validate against process logs\n`;
    content += `2. Use **5-Why analysis** to drill down to the fundamental cause\n`;
    content += `3. Cross-reference with similar historical incidents (found ${INCIDENTS.filter(i => i.incidentType === inc.incidentType).length} similar cases)\n`;
  } else if (specificType) {
    const typeMap: Record<string, string> = {
      defect: 'defectspike',
      contamination: 'contamination',
      equipment: 'equipmentfailure',
      process: 'processdeviation',
    };
    const kbKey = typeMap[specificType] || 'defectspike';
    const kb = KB[kbKey] || KB.defectspike;
    content += `### Common Root Causes for ${specificType.charAt(0).toUpperCase() + specificType.slice(1)} Issues\n\n`;
    kb.causes.slice(0, 6).forEach((cause, i) => {
      const likelihood = Math.max(25, 82 - i * 11 + Math.floor(Math.random() * 8));
      content += `${i + 1}. **${cause.split('—')[0].trim()}** — Est. probability: ~${likelihood}%\n`;
      if (cause.includes('—')) content += `   → ${cause.split('—')[1].trim()}\n`;
      content += `\n`;
    });
  } else {
    content += `### General Root Cause Investigation Framework\n\n`;
    content += `To identify the root cause of a quality issue, follow this systematic approach:\n\n`;
    KB.defectspike.causes.slice(0, 5).forEach((cause, i) => {
      content += `${i + 1}. **${cause.split('—')[0].trim()}**\n`;
      if (cause.includes('—')) content += `   → ${cause.split('—')[1].trim()}\n`;
      content += `\n`;
    });
    content += `> 💡 **Tip:** Reference a specific incident by its ID (e.g., "What caused INC-001?") for a more targeted analysis.\n`;
  }

  return content;
}

function generateCorrectiveActionResponse(analysis: QueryAnalysis): string {
  let content = `## Corrective Action Plan\n\n`;

  if (analysis.incidentRef) {
    const inc = analysis.incidentRef;
    const kb = getKB(inc.incidentType);

    content += `### Incident: ${inc.incidentType} (${inc.id})\n`;
    content += `**Severity:** ${inc.severity} — Priority: ${inc.severity === 'Critical' ? '🔴 Immediate' : inc.severity === 'Major' ? '🟠 High' : inc.severity === 'Minor' ? '🟡 Medium' : '🟢 Low'}\n\n`;

    content += `### Immediate Containment Actions\n\n`;
    kb.actions.slice(0, 3).forEach((action, i) => {
      content += `${i + 1}. 🔒 ${action}\n`;
    });
    content += `\n### Long-term Corrective Actions\n\n`;
    kb.actions.slice(3).forEach((action, i) => {
      content += `${i + 4}. ✅ ${action}\n`;
    });

    content += `\n### Verification of Effectiveness\n\n`;
    content += `- Monitor defect rate for minimum **30 days** post-implementation\n`;
    content += `- Verify Cpk/Ppk values have returned to ≥ 1.33\n`;
    content += `- Conduct layer process audit at **7, 14, and 30 day** intervals\n`;
    content += `- Update control plan and FMEA with new controls\n`;
  } else {
    content += `### General Corrective Action Framework\n\n`;
    content += `Follow the structured approach for developing effective corrective actions:\n\n`;
    content += `#### Step 1: Containment (Immediate — Within 24 hours)\n`;
    KB.defectspike.actions.slice(0, 3).forEach((action, i) => {
      content += `${i + 1}. ${action}\n`;
    });

    content += `\n#### Step 2: Root Cause Investigation (1–5 days)\n`;
    content += `- Use Fishbone (Ishikawa) diagram across Man, Machine, Material, Method, Measurement, Environment\n`;
    content += `- Apply 5-Why analysis to drill to fundamental cause\n`;
    content += `- Validate hypotheses with data analysis\n`;

    content += `\n#### Step 3: Permanent Corrective Action (1–4 weeks)\n`;
    KB.defectspike.actions.slice(3).forEach((action, i) => {
      content += `${i + 1}. ${action}\n`;
    });

    content += `\n> 💡 Reference a specific incident for a tailored corrective action plan.\n`;
  }

  return content;
}

function generateFMEAResponse(): string {
  let content = `## FMEA — Failure Mode and Effects Analysis\n\n`;
  content += `FMEA is a systematic, proactive method for evaluating a process to identify where and how it might fail.\n\n`;

  content += `### FMEA Process Steps\n\n`;
  content += `1. **Identify Process Steps** — Map each step in the manufacturing process\n`;
  content += `2. **Identify Failure Modes** — For each step, list all ways it could fail\n`;
  content += `3. **Identify Effects** — Determine the consequence of each failure\n`;
  content += `4. **Rate Severity (1-10)** — How serious is the effect?\n`;
  content += `5. **Rate Occurrence (1-10)** — How likely is the failure?\n`;
  content += `6. **Rate Detection (1-10)** — How likely is detection before reaching customer?\n`;
  content += `7. **Calculate RPN** — RPN = Severity × Occurrence × Detection\n`;
  content += `8. **Prioritize & Act** — Focus on highest RPN items first\n\n`;

  content += `### RPN Risk Assessment Matrix\n\n`;
  content += `| RPN Range | Action Required |\n|-----------|----------------|\n| 200–1000 | 🔴 **Critical** — Immediate action required |\n| 100–199 | 🟠 **High** — Corrective action within 30 days |\n| 50–99 | 🟡 **Medium** — Review and improve |\n| 1–49 | 🟢 **Low** — Monitor and maintain |\n\n`;

  content += `### Key Recommendations from Current Data\n\n`;
  FMEA_GUIDE.forEach((item, i) => {
    content += `${i + 1}. ${item}\n`;
  });

  const topRisks = INCIDENTS
    .filter(i => i.severity === 'Critical' || i.severity === 'Major')
    .slice(0, 3);

  content += `\n### Top Risk Items from Current Incidents\n\n`;
  topRisks.forEach((inc, i) => {
    const sevScore = inc.severity === 'Critical' ? 9 : inc.severity === 'Major' ? 7 : 5;
    const occScore = Math.min(10, Math.ceil(inc.defectRate / 2));
    const detScore = Math.min(10, 8 - Math.floor(Math.random() * 3));
    const rpn = sevScore * occScore * detScore;
    content += `${i + 1}. **${inc.incidentType}** (${inc.id}) — Severity: ${sevScore}/10, Occurrence: ${occScore}/10, Detection: ${detScore}/10\n`;
    content += `   → **RPN: ${rpn}** ${rpn > 100 ? '⚠️ Above threshold' : '✅ Within acceptable range'}\n\n`;
  });

  return content;
}

function generateSPCResponse(): string {
  let content = `## Statistical Process Control (SPC)\n\n`;
  content += `SPC is a method of quality control which uses statistical methods to monitor and control a process.\n\n`;

  content += `### Key SPC Concepts\n\n`;
  content += `#### Control Charts\n`;
  content += `- **X-bar and R charts** — Monitor process mean and variability\n`;
  content += `- **Individual and Moving Range (I-MR)** — For individual measurements\n`;
  content += `- **P-chart and NP-chart** — For attribute data (defect counts)\n`;
  content += `- **C-chart and U-chart** — For defect counts per unit\n\n`;

  content += `### Western Electric Rules (Out-of-Control Detection)\n\n`;
  content += `1. One point beyond Zone A (beyond 3σ from centerline)\n`;
  content += `2. Two of three consecutive points in Zone A or beyond\n`;
  content += `3. Four of five consecutive points in Zone B or beyond\n`;
  content += `4. Eight consecutive points on one side of centerline\n\n`;

  content += `### Process Capability Guidelines\n\n`;
  content += `| Metric | Target | Meaning |\n|--------|--------|---------|\n| **Cp** | ≥ 1.33 | Process spread within spec limits |\n| **Cpk** | ≥ 1.33 | Process centered within spec limits |\n| **Pp** | ≥ 1.67 | Long-term process performance |\n| **Ppk** | ≥ 1.67 | Long-term centered performance |\n\n`;

  content += `### SPC Recommendations from Current Data\n\n`;
  SPC_GUIDE.forEach((item, i) => {
    content += `${i + 1}. ${item}\n`;
  });

  const avgDefectRate = INCIDENTS.reduce((sum, i) => sum + i.defectRate, 0) / INCIDENTS.length;
  const maxDefectRate = Math.max(...INCIDENTS.map(i => i.defectRate));
  const highDefectLines = INCIDENTS.filter(i => i.defectRate > avgDefectRate);

  content += `\n### Current Process Performance Summary\n\n`;
  content += `- **Average defect rate across all incidents:** ${avgDefectRate.toFixed(2)}%\n`;
  content += `- **Maximum observed defect rate:** ${maxDefectRate.toFixed(2)}%\n`;
  content += `- **Lines exceeding average defect rate:** ${highDefectLines.length} incidents\n`;
  content += `- **Recommendation:** Lines with defect rates > ${avgDefectRate.toFixed(1)}% should undergo immediate SPC review\n`;

  return content;
}

function generateEightDResponse(): string {
  let content = `## 8D Problem-Solving Methodology\n\n`;
  content += `The 8D (Eight Disciplines) approach is a structured, team-oriented problem-solving methodology.\n\n`;

  content += `### The 8 Disciplines\n\n`;
  EIGHT_D_GUIDE.forEach((step) => {
    content += `- ${step}\n`;
  });

  content += `\n### Supporting Tools for Each Phase\n\n`;
  content += `| Phase | Recommended Tools |\n|-------|---------------------|\n| D1: Team | RACI Matrix, Skills Matrix |\n| D2: Problem | 5W2H, Pareto Analysis, Run Chart |\n| D3: Containment | Quarantine Log, Sort Plan, Segregation Protocol |\n| D4: Root Cause | Fishbone Diagram, 5-Why, FMEA, DOE |\n| D5: Corrective | Pugh Matrix, Risk Assessment, Pilot Testing |\n| D6: Validation | Statistical Testing, Control Charts, Audit Results |\n| D7: Prevention | Updated FMEA, Control Plan, SOP Revision |\n| D8: Recognition | Team Awards, Knowledge Sharing, Best Practices |\n\n`;

  content += `### Current Incidents Suitable for 8D\n\n`;
  const eligible = INCIDENTS.filter(i => i.severity === 'Critical' || i.severity === 'Major');
  content += `Found **${eligible.length}** incidents (Critical/Major severity) that would benefit from formal 8D:\n\n`;
  eligible.slice(0, 5).forEach((inc, i) => {
    content += `${i + 1}. **${inc.incidentType}** (${inc.id}) — ${inc.plant}, ${inc.line}\n`;
    content += `   Severity: ${inc.severity} | Defect Rate: ${inc.defectRate}% | Status: ${inc.status}\n\n`;
  });

  return content;
}

function generatePreventionResponse(analysis: QueryAnalysis): string {
  let content = `## Prevention & Continuous Improvement Strategy\n\n`;

  content += `### Preventive Quality Framework\n\n`;
  content += `#### 1. Proactive Monitoring\n`;
  content += `- Implement **real-time SPC** with automated alerts for out-of-spec conditions\n`;
  content += `- Use **predictive maintenance** (vibration analysis, thermal imaging) for critical equipment\n`;
  content += `- Deploy **automated optical inspection (AOI)** for defect detection at source\n\n`;

  content += `#### 2. Standardization\n`;
  content += `- Maintain up-to-date **Standard Operating Procedures (SOPs)** for all processes\n`;
  content += `- Implement **Standard Work** with visual management and job instructions\n`;
  content += `- Use **Poka-Yoke (error-proofing)** devices to prevent operator errors\n\n`;

  content += `#### 3. Competency & Training\n`;
  content += `- Establish **skill matrices** for all operators with regular competency assessments\n`;
  content += `- Conduct **monthly quality awareness** sessions with real examples\n`;
  content += `- Implement **certification program** for critical process steps\n\n`;

  content += `#### 4. Continuous Improvement\n`;
  content += `- Hold **daily quality stand-ups** to review previous 24h performance\n`;
  content += `- Run **Kaizen events** quarterly for chronic quality issues\n`;
  content += `- Track **Cost of Quality (COQ)** metrics: Prevention, Appraisal, Internal Failure, External Failure\n\n`;

  if (analysis.incidentRef) {
    const inc = analysis.incidentRef;
    const kb = getKB(inc.incidentType);
    content += `\n### Specific Prevention for ${inc.incidentType}\n\n`;
    content += `Based on the analysis of ${inc.id}, recommended prevention measures:\n\n`;
    kb.actions.slice(-3).forEach((action, i) => {
      content += `${i + 1}. ${action}\n`;
    });
  }

  content += `\n### Industry Best Practices\n`;
  content += `- **Zero Defect mentality** — Aim for Cpk ≥ 2.0 (Six Sigma level)\n`;
  content += `- **Quality at Source** — Detect and correct at the point of creation\n`;
  content += `- **Andon System** — Empower operators to stop the line for quality issues\n`;
  content += `- **Layered Process Audits** — Multi-level verification of process adherence\n`;

  return content;
}

function generateDefectAnalysisResponse(): string {
  let content = `## Defect Analysis & Classification\n\n`;

  const typeCounts: Record<string, number> = {};
  const severityCounts: Record<string, number> = {};
  const lineCounts: Record<string, number> = {};

  INCIDENTS.forEach(inc => {
    typeCounts[inc.incidentType] = (typeCounts[inc.incidentType] || 0) + 1;
    severityCounts[inc.severity] = (severityCounts[inc.severity] || 0) + 1;
    lineCounts[inc.line] = (lineCounts[inc.line] || 0) + 1;
  });

  content += `### Current Defect Landscape\n\n`;
  content += `**Total Incidents:** ${INCIDENTS.length}\n\n`;

  content += `#### By Type (Pareto Analysis)\n\n`;
  const sortedTypes = Object.entries(typeCounts).sort((a, b) => b[1] - a[1]);
  sortedTypes.forEach(([type, count]) => {
    const pct = ((count / INCIDENTS.length) * 100).toFixed(1);
    const bar = '█'.repeat(Math.round(count * 2));
    content += `${type}: ${count} (${pct}%) ${bar}\n`;
  });

  content += `\n#### By Severity\n\n`;
  ['Critical', 'Major', 'Minor', 'Low'].forEach(sev => {
    const count = severityCounts[sev] || 0;
    const icon = sev === 'Critical' ? '🔴' : sev === 'Major' ? '🟠' : sev === 'Minor' ? '🟡' : '🟢';
    content += `${icon} **${sev}:** ${count} incidents (${((count / INCIDENTS.length) * 100).toFixed(1)}%)\n`;
  });

  content += `\n#### By Production Line\n\n`;
  const sortedLines = Object.entries(lineCounts).sort((a, b) => b[1] - a[1]);
  sortedLines.forEach(([line, count]) => {
    content += `- **${line}:** ${count} incidents\n`;
  });

  content += `\n### Pareto Principle Check\n`;
  const cumulative = sortedTypes.reduce((acc: { type: string; count: number; cumulative: number }[], [type, count]) => {
    const prev = acc.length > 0 ? acc[acc.length - 1].cumulative : 0;
    acc.push({ type, count, cumulative: prev + count });
    return acc;
  }, []);

  const paretoTop = cumulative.filter(c => (c.cumulative / INCIDENTS.length) <= 0.8);
  const pctVal = ((paretoTop[paretoTop.length - 1]?.cumulative / INCIDENTS.length) * 100 || 0);
  content += `- Top ${paretoTop.length} defect types account for ${pctVal.toFixed(0)}% of all incidents\n`;
  content += `- This ${pctVal >= 70 ? 'confirms' : 'does not fully confirm'} the 80/20 Pareto principle for your data\n`;

  return content;
}

function generateProcessImprovementResponse(): string {
  let content = `## Process Improvement Recommendations\n\n`;

  const lineDefectRates: Record<string, { total: number; count: number }> = {};
  INCIDENTS.forEach(inc => {
    if (!lineDefectRates[inc.line]) lineDefectRates[inc.line] = { total: 0, count: 0 };
    lineDefectRates[inc.line].total += inc.defectRate;
    lineDefectRates[inc.line].count++;
  });

  const lineAvgs = Object.entries(lineDefectRates).map(([line, data]) => ({
    line,
    avgRate: data.total / data.count,
    incidents: data.count,
  })).sort((a, b) => b.avgRate - a.avgRate);

  content += `### Data-Driven Improvement Opportunities\n\n`;
  content += `#### Lines Requiring Improvement (by avg defect rate)\n\n`;
  lineAvgs.forEach((l, i) => {
    const status = l.avgRate > 3 ? '🔴 Critical' : l.avgRate > 2 ? '🟠 Needs Attention' : '🟢 Acceptable';
    content += `${i + 1}. **${l.line}** — Avg defect rate: ${l.avgRate.toFixed(2)}% | ${l.incidents} incidents | ${status}\n`;
  });

  content += `\n### Six Sigma Improvement Path\n\n`;
  content += `1. **Define** — Identify critical quality characteristics (CTQs)\n`;
  content += `2. **Measure** — Establish baseline sigma level using current defect data\n`;
  content += `3. **Analyze** — Use DOE and regression to identify key input variables\n`;
  content += `4. **Improve** — Optimize process parameters using response surface methodology\n`;
  content += `5. **Control** — Implement SPC with automated control and alerting\n\n`;

  content += `### Quick Wins (Low Effort, High Impact)\n\n`;
  content += `- Implement **visual management boards** at each production line\n`;
  content += `- Deploy **Andon system** for immediate defect escalation\n`;
  content += `- Create **defect photo library** for operator reference\n`;
  content += `- Establish **daily quality review meetings** (15 min)\n`;
  content += `- Standardize **first-piece inspection** procedures\n`;

  return content;
}

function generateIncidentInquiryResponse(analysis: QueryAnalysis): string {
  const inc = analysis.incidentRef;
  if (!inc) return generateGeneralQualityResponse();

  const kb = getKB(inc.incidentType);
  const similar = INCIDENTS.filter(i => i.id !== inc.id && i.incidentType === inc.incidentType);

  let content = `## Incident Details: ${inc.id}\n\n`;
  content += `### Overview\n`;
  content += `| Attribute | Value |\n|-----------|-------|\n`;
  content += `| Type | ${inc.incidentType} |\n`;
  content += `| Severity | ${inc.severity} |\n`;
  content += `| Status | ${inc.status} |\n`;
  content += `| Plant | ${inc.plant} |\n`;
  content += `| Line | ${inc.line} |\n`;
  content += `| Product | ${inc.productType} |\n`;
  content += `| Batch | ${inc.batchId} |\n`;
  content += `| Defect Count | ${inc.defectCount} |\n`;
  content += `| Defect Rate | ${inc.defectRate}% |\n`;
  content += `| Timestamp | ${new Date(inc.timestamp).toLocaleString()} |\n\n`;

  content += `### Description\n${inc.description}\n\n`;

  content += `### Process Parameters Status\n`;
  inc.processParameters.forEach(param => {
    const inSpec = param.value >= param.lowerLimit && param.value <= param.upperLimit;
    content += `${inSpec ? '✅' : '⚠️'} **${param.name}:** ${param.value} ${param.unit} (Spec: ${param.lowerLimit}–${param.upperLimit})\n`;
  });

  content += `\n### Quality Metrics\n`;
  inc.qualityMetrics.forEach(metric => {
    const status = metric.breached ? '⚠️ BREACHED' : '✅ OK';
    content += `${metric.breached ? '🔴' : '🟢'} **${metric.metric}:** ${metric.value} ${metric.unit} (Threshold: ${metric.threshold}) — ${status}\n`;
  });

  content += `\n### Analysis\n`;
  content += `**Similar incidents:** ${similar.length} other ${inc.incidentType} cases found in the system.\n`;
  content += `\n**Top probable causes:**\n`;
  kb.causes.slice(0, 3).forEach((cause, i) => {
    content += `${i + 1}. ${cause}\n`;
  });

  return content;
}

function generateGeneralQualityResponse(): string {
  return `## Manufacturing Quality Insights\n\nI can help you analyze quality data, identify root causes, and recommend corrective actions. Here are some areas I can assist with:\n\n### Available Analysis Types\n\n🔍 **Root Cause Analysis**\n- Identify probable causes for any incident\n- Rank causes by likelihood\n- Suggest investigation paths\n\n🛠️ **Corrective Actions**\n- Immediate containment steps\n- Long-term corrective action plans\n- Effectiveness verification methods\n\n📊 **Statistical Analysis**\n- SPC chart interpretation\n- Process capability analysis (Cpk/Ppk)\n- Trend and pattern identification\n\n📋 **Methodology Guidance**\n- 8D problem-solving walkthrough\n- FMEA development and RPN calculation\n- Six Sigma DMAIC framework\n\n💡 **Try asking:**\n- "What are the common causes of defect spikes?"\n- "Analyze incident INC-001"\n- "How do I conduct an FMEA?"\n- "What corrective actions are recommended for contamination?"`;
}

// ============================================================
// Main LLM Response Engine
// ============================================================

export function generateLLMResponse(
  query: string,
  model: LLMModel
): LLMResponse {
  const modelInfo = LLM_MODELS.find(m => m.id === model) || LLM_MODELS[0];
  const analysis = classifyQuery(query);

  const accuracyVariation = (Math.random() * 6 - 3);
  const confidenceVariation = (Math.random() * 8 - 4);
  const complexityPenalty = analysis.complexity === 'complex' ? 2 : analysis.complexity === 'simple' ? 1 : 0;

  const accuracyScore = Math.min(99, Math.max(70,
    modelInfo.baseAccuracy + accuracyVariation - complexityPenalty
  ));

  const confidenceScore = Math.min(99, Math.max(65,
    modelInfo.baseConfidence + confidenceVariation - complexityPenalty
  ));

  let content: string;
  switch (analysis.intent) {
    case 'greeting':
      content = generateGreeting();
      break;
    case 'root_cause':
      content = generateRootCauseResponse(analysis);
      break;
    case 'corrective_action':
      content = generateCorrectiveActionResponse(analysis);
      break;
    case 'fmea':
      content = generateFMEAResponse();
      break;
    case 'spc':
      content = generateSPCResponse();
      break;
    case 'eight_d':
      content = generateEightDResponse();
      break;
    case 'prevention':
      content = generatePreventionResponse(analysis);
      break;
    case 'defect_analysis':
      content = generateDefectAnalysisResponse();
      break;
    case 'process_improvement':
      content = generateProcessImprovementResponse();
      break;
    case 'incident_inquiry':
      content = generateIncidentInquiryResponse(analysis);
      break;
    default:
      content = generateGeneralQualityResponse();
  }

  const modelSignatures: Record<LLMModel, string> = {
    gpt4: `\n\n---\n*Analysis generated by GPT-4 using QualityIQ Manufacturing Knowledge Base*`,
    claude3: `\n\n---\n*Analysis generated by Claude 3 Opus using QualityIQ Manufacturing Knowledge Base*`,
    gemini: `\n\n---\n*Analysis generated by Gemini 1.5 Pro using QualityIQ Manufacturing Knowledge Base*`,
    llama3: `\n\n---\n*Analysis generated by Llama 3 70B using QualityIQ Manufacturing Knowledge Base*`,
    mistral: `\n\n---\n*Analysis generated by Mistral Large using QualityIQ Manufacturing Knowledge Base*`,
  };
  content += modelSignatures[model];

  const sources: string[] = [];
  if (analysis.incidentRef) {
    sources.push(`Incident Record: ${analysis.incidentRef.id}`);
    sources.push(`Process Parameters Log: ${analysis.incidentRef.batchId}`);
  }
  sources.push('QualityIQ Manufacturing Knowledge Base v2.4');
  sources.push('ISO 9001:2015 Quality Management Standards');
  if (analysis.topics.includes('spc')) sources.push('AIAG SPC Reference Manual (2nd Edition)');
  if (analysis.topics.includes('fmea')) sources.push('AIAG FMEA-4 Reference Manual');
  if (analysis.topics.includes('8d')) sources.push('Ford 8D Problem Solving Reference Guide');
  if (analysis.topics.includes('contamination')) sources.push('ISO 14644 Cleanroom Standards');

  const reasoningSteps: string[] = [];
  reasoningSteps.push(`Query classified as: ${analysis.intent.replace(/_/g, ' ')}`);
  reasoningSteps.push(`Complexity level: ${analysis.complexity}`);
  if (analysis.incidentRef) {
    reasoningSteps.push(`Referenced incident: ${analysis.incidentRef.id} (${analysis.incidentRef.incidentType})`);
  }
  reasoningSteps.push(`Knowledge base topics matched: ${analysis.topics.join(', ') || 'general'}`);
  reasoningSteps.push(`Sources consulted: ${sources.length} references`);
  reasoningSteps.push(`Response generated with model-specific calibration`);

  const tokensUsed = Math.ceil(content.length / 4) + 20;
  const responseTime = Math.round((tokensUsed / modelInfo.tokenSpeed) * 10 + Math.random() * 500) / 10;

  return {
    content,
    accuracyScore: Math.round(accuracyScore * 10) / 10,
    confidenceScore: Math.round(confidenceScore * 10) / 10,
    tokensUsed,
    responseTime,
    sources,
    reasoningSteps,
  };
}

// ============================================================
// Suggested Prompts
// ============================================================

export const SUGGESTED_PROMPTS = [
  { icon: '🔍', label: 'Root Cause Analysis', prompt: 'What are the common root causes of defect spikes in manufacturing?', category: 'Analysis' },
  { icon: '📊', label: 'Incident Inquiry', prompt: 'Analyze incident INC-001 and provide a detailed assessment', category: 'Analysis' },
  { icon: '🛠️', label: 'Corrective Actions', prompt: 'What corrective actions are recommended for contamination issues?', category: 'Resolution' },
  { icon: '📋', label: '8D Methodology', prompt: 'Walk me through the 8D problem-solving methodology step by step', category: 'Methodology' },
  { icon: '🔬', label: 'FMEA Analysis', prompt: 'How do I conduct an FMEA for my manufacturing process? Include RPN calculation', category: 'Methodology' },
  { icon: '📈', label: 'SPC Analysis', prompt: 'Explain SPC control charts and process capability analysis', category: 'Analysis' },
  { icon: '🎯', label: 'Process Improvement', prompt: 'What process improvement recommendations can you make based on current quality data?', category: 'Improvement' },
  { icon: '🛡️', label: 'Prevention Strategy', prompt: 'How can we prevent future quality incidents and build a preventive quality culture?', category: 'Improvement' },
  { icon: '⚡', label: 'Critical Incidents', prompt: 'Show me all critical severity incidents and their root causes', category: 'Analysis' },
  { icon: '📉', label: 'Trend Analysis', prompt: 'What are the defect trends across different production lines?', category: 'Analysis' },
];

// ============================================================
// Quick Actions
// ============================================================

export interface QuickAction {
  label: string;
  icon: string;
  action: string;
  prompt: string;
}

export const QUICK_ACTIONS: QuickAction[] = [
  { label: 'Analyze INC', icon: '🔍', action: 'analyze', prompt: 'Analyze the most recent critical incident' },
  { label: 'Get FMEA', icon: '📋', action: 'fmea', prompt: 'Generate FMEA for current incidents' },
  { label: 'SPC Review', icon: '📊', action: 'spc', prompt: 'Review SPC status for all lines' },
  { label: '8D Report', icon: '📝', action: '8d', prompt: 'Create an 8D report for the top defect' },
  { label: 'Compare LLMs', icon: '⚡', action: 'compare', prompt: 'Compare responses across all models' },
];
