import React from 'react';
import { cn } from '../../lib/utils';
import { User, Bot, AlertTriangle, CheckCircle2, FileText } from 'lucide-react';
import { Message } from '../../types';
import { motion } from 'framer-motion';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';
  const isSafe = message.isSafe !== undefined ? message.isSafe : true;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "flex w-full mb-6",
        isUser ? "justify-end" : "justify-start"
      )}
    >
      <div className={cn(
        "flex max-w-[85%] ${isUser ? 'flex-row-reverse' : 'flex-row'}",
        isUser ? "flex-row-reverse" : "flex-row"
      )}>
        <div className={cn(
          "flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center",
          isUser ? "ml-3 bg-blue-600 text-white" : "mr-3 bg-slate-100 text-slate-600"
        )}>
          {isUser ? <User size={20} /> : <Bot size={20} />}
        </div>
        
        <div className="flex flex-col">
          <div className={cn(
            "px-4 py-3 rounded-2xl shadow-sm relative group",
            isUser 
              ? "bg-blue-600 text-white rounded-tr-none" 
              : !isSafe
                ? "bg-amber-50 text-amber-900 border border-amber-200 rounded-tl-none"
                : "bg-white text-slate-800 border border-slate-100 rounded-tl-none"
          )}>
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
          </div>

          {!isUser && (
            <div className="mt-1.5 flex items-center gap-3 px-1">
              {/* Verification Tag */}
              {!isSafe ? (
                <div className="flex items-center gap-1 text-amber-600">
                  <AlertTriangle size={12} />
                  <span className="text-[10px] font-bold uppercase tracking-wider">Unverified</span>
                </div>
              ) : (
                <div className="flex items-center gap-1 text-emerald-600">
                  <CheckCircle2 size={12} />
                  <span className="text-[10px] font-bold uppercase tracking-wider">Policy Verified</span>
                </div>
              )}

              {/* Source Tag */}
              {message.source && (
                <div className="flex items-center gap-1 text-slate-400">
                  <FileText size={12} />
                  <span className="text-[10px] font-medium italic">Source: {message.source}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default ChatMessage;