import React from 'react';
import { Bell, Search, User } from 'lucide-react';
import { View } from '../../types';

interface HeaderProps {
  view: View;
}

const Header: React.FC<HeaderProps> = ({ view }) => {
  const titles: Record<View, string> = {
    dashboard: 'Overview',
    chat: 'Policy Assistant',
    documents: 'Knowledge Base'
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-10">
      <h1 className="text-lg font-semibold text-slate-800">
        {titles[view]}
      </h1>

      <div className="flex items-center gap-4">
        <div className="relative hidden md:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search..." 
            className="pl-10 pr-4 py-2 bg-slate-100 border-none rounded-full text-sm focus:ring-2 focus:ring-blue-500 w-64 transition-all"
          />
        </div>
        
        <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full transition-colors relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
        </button>

        <div className="h-8 w-[1px] bg-slate-200 mx-2"></div>

        <button className="flex items-center gap-2 p-1 pr-3 hover:bg-slate-100 rounded-full transition-colors">
          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
            <User className="w-5 h-5" />
          </div>
          <span className="text-sm font-medium text-slate-700 hidden sm:block">Agent Admin</span>
        </button>
      </div>
    </header>
  );
};

export default Header;
