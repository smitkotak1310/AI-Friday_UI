import React from 'react';
import { cn } from '../../lib/utils';

interface StatsCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: string;
  trendUp?: boolean;
  className?: string;
}

const StatsCard: React.FC<StatsCardProps> = ({ label, value, icon, trend, trendUp, className }) => {
  return (
    <div className={cn("bg-white p-6 rounded-2xl border border-slate-200 shadow-sm", className)}>
      <div className="flex justify-between items-start mb-4">
        <div className="p-2 bg-blue-50 rounded-xl text-blue-600">
          {icon}
        </div>
        {trend && (
          <span className={cn(
            "text-xs font-medium px-2 py-1 rounded-full",
            trendUp ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"
          )}>
            {trend}
          </span>
        )}
      </div>
      <div>
        <p className="text-sm text-slate-500 font-medium">{label}</p>
        <h3 className="text-2xl font-bold text-slate-900 mt-1">{value}</h3>
      </div>
    </div>
  );
};

export default StatsCard;
