import React from 'react';
import { motion } from 'framer-motion';
import { FileText, MessageSquare, ShieldCheck, UploadCloud } from 'lucide-react';
import StatsCard from './StatsCard';
import UploadZone from './UploadZone';
import { View } from '../../types';
import { cn } from '../../lib/utils';

interface DashboardProps {
  view: View;
  isUploading: boolean;
  onUpload: (file: File) => Promise<void>;
}

const Dashboard: React.FC<DashboardProps> = ({ isUploading, onUpload }) => {
  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Welcome Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Welcome back, Admin</h2>
          <p className="text-slate-500 mt-1">Here's what's happening with your insurance knowledge base today.</p>
        </div>
        <button className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200">
          <UploadCloud className="w-5 h-5" />
          New Upload
        </button>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatsCard 
          label="Total Documents" 
          value="12" 
          trend="+2 this week" 
          trendUp={true}
          icon={<FileText className="w-6 h-6" />} 
        />
        <StatsCard 
          label="AI Queries" 
          value="1,284" 
          trend="+12%" 
          trendUp={true}
          icon={<MessageSquare className="w-6 h-6" />} 
        />
        <StatsCard 
          label="System Health" 
          value="99.9%" 
          icon={<ShieldCheck className="w-6 h-6" />} 
        />
      </div>

      {/* Main Content Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Upload Area */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2 space-y-6"
        >
          <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-blue-50 rounded-lg text-blue-600">
                <UploadCloud className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-slate-800">Index New Policy</h3>
            </div>
            <UploadZone onUpload={onUpload} isUploading={isUploading} />
          </div>

          <div className="bg-blue-600 rounded-3xl p-8 text-white relative overflow-hidden group">
            <div className="relative z-10">
              <h3 className="text-xl font-bold mb-2">Need more intelligence?</h3>
              <p className="text-blue-100 mb-6 max-w-md">Our RAG engine uses Gemini 2.5 Flash to provide lightning-fast and accurate policy answers with built-in hallucination detection.</p>
              <button className="px-6 py-2.5 bg-white text-blue-600 rounded-xl font-bold hover:bg-blue-50 transition-colors">
                Learn about RAG Architecture
              </button>
            </div>
            <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-blue-500 rounded-full opacity-20 group-hover:scale-110 transition-transform duration-700"></div>
          </div>
        </motion.div>

        {/* Right: Recent Activity */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-6"
        >
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-slate-800 mb-6">Recent Activity</h3>
            <div className="space-y-6">
              {[
                { type: 'upload', text: 'Uploaded "Life_Policy_2024.pdf"', time: '2h ago', icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50' },
                { type: 'query', text: 'User queried "coverage limits"', time: '5h ago', icon: MessageSquare, color: 'text-purple-600', bg: 'bg-purple-50' },
                { type: 'system', text: 'ChromaDB Index Updated', time: '1d ago', icon: ShieldCheck, color: 'text-green-600', bg: 'bg-green-50' },
              ].map((item, idx) => (
                <div key={idx} className="flex gap-4">
                  <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", item.bg, item.color)}>
                    <item.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-800">{item.text}</p>
                    <p className="text-xs text-slate-400 mt-1">{item.time}</p>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-8 text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors">
              View All Activity
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;
