export type View = 'dashboard' | 'chat' | 'documents';

export interface UploadResponse {
  message: string;
}

export interface QueryResponse {
  answer: string;
  safe: boolean;
  source?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isSafe?: boolean;
  source?: string;
}

export interface DocumentInfo {
  id: string;
  name: string;
  size: string;
  type: string;
  uploadedAt: string;
}
