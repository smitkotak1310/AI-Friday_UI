import React, { useState } from 'react';
import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';
import Dashboard from './components/dashboard/Dashboard';
import ChatInterface from './components/chat/ChatInterface';
import { View, QueryResponse, DocumentInfo } from './types';
import { AlertCircle, FileText } from 'lucide-react';

// SET THIS TO FALSE TO CONNECT TO YOUR ACTUAL FASTAPI BACKEND
const USE_MOCK = true;
const API_BASE_URL = 'http://localhost:8000';

// --- PROFESSIONAL MOCK DATA ---
const MOCK_RESPONSES: Record<string, QueryResponse> = {
  "hello": {
    "answer": "Hello! I am your dedicated Insurance Policy Assistant. I can help you understand your coverage, find specific clauses, or summarize your policy details. How can I assist you today?",
    "safe": true,
    "source": "System"
  },
  "what is my coverage": {
    "answer": "Based on the uploaded documents, your current policy provides comprehensive coverage for accidental damage, theft, and fire. Specifically, it covers up to $50,000 for personal property damage per occurrence.",
    "safe": true,
    "source": "Home_Insurance_Policy_2025.pdf"
  },
  "is there a deductible": {
    "answer": "Yes, your policy includes a standard deductible of $500 for all property damage claims. This amount must be paid out-of-pocket before the insurance provider covers the remaining costs.",
    "safe": true,
    "source": "Policy_Summary_v2.pdf"
  },
  "can i claim for water damage": {
    "answer": "Water damage is covered under Section 4.2 of your policy, provided the damage was caused by sudden and accidental pipe bursts. However, damage resulting from gradual seepage or maintenance issues is typically excluded.",
    "safe": true,
    "source": "Home_Insurance_Policy_2025.pdf"
  },
  "do you cover extreme weather": {
    "answer": "I can see some information related to your query, but I want to be 100% sure. Could you please be more specific or check the document manually?",
    "safe": false,
    "source": "N/A"
  },
  "default": {
    "answer": "I'm sorry, I couldn't find a specific answer to that in your current policy documents. Please try rephrasing your question or upload a more detailed document.",
    "safe": false,
    "source": "N/A"
  }
};

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [isUploading, setIsUploading] = useState(false);
  const [documents, setDocuments] = useState<DocumentInfo[]>([
    { id: '1', name: 'Standard_Policy_2024.pdf', size: '2.4 MB', type: 'PDF', uploadedAt: '2025-01-10' },
    { id: '2', name: 'Terms_and_Conditions.txt', size: '45 KB', type: 'TXT', uploadedAt: '2025-01-12' },
  ]);

  // --- MOCK HANDLERS ---
  const handleMockUpload = async (file: File) => {
    console.log('Mock Uploading:', file.name);
    setIsUploading(true);
    await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate network delay
    setIsUploading(false);
    
    const newDoc: DocumentInfo = {
      id: Math.random().toString(),
      name: file.name,
      size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
      type: file.name.endsWith('.pdf') ? 'PDF' : 'TXT',
      uploadedAt: new Date().toISOString().split('T')[0],
    };
    setDocuments(prev => [newDoc, ...prev]);
  };

  const handleMockAsk = async (question: string): Promise<QueryResponse> => {
    console.log('Mock Asking:', question);
    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate AI thinking
    
    const lowerQuestion = question.toLowerCase();
    
    // Check for exact matches or keyword matches
    if (MOCK_RESPONSES[lowerQuestion]) return MOCK_RESPONSES[lowerQuestion];
    if (lowerQuestion.includes("coverage") || lowerQuestion.includes("covered")) return MOCK_RESPONSES["what is my coverage"];
    if (lowerQuestion.includes("deductible")) return MOCK_RESPONSES["is there a deductible"];
    if (lowerQuestion.includes("water")) return MOCK_RESPONSES["can i claim for water damage"];
    if (lowerQuestion.includes("weather") || lowerQuestion.includes("storm")) return MOCK_RESPONSES["do you cover extreme weather"];

    return MOCK_RESPONSES["default"];
  };

  // --- REAL BACKEND HANDLERS ---
  const handleRealUpload = async (file: File) => {
    setIsUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch(`${API_BASE_URL}/upload`, {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) throw new Error('Upload failed');
      
      const newDoc: DocumentInfo = {
        id: Date.now().toString(),
        name: file.name,
        size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
        type: file.name.endsWith('.pdf') ? 'PDF' : 'TXT',
        uploadedAt: new Date().toISOString().split('T')[0],
      };
      setDocuments(prev => [newDoc, ...prev]);
    } catch (error) {
      console.error('Real Upload Error:', error);
      alert('Failed to upload document to the server.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleRealAsk = async (question: string): Promise<QueryResponse> => {
    try {
      const response = await fetch(`${API_BASE_URL}/ask`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question }),
      });
      if (!response.ok) throw new Error('Query failed');
      return await response.json();
    } catch (error) {
      console.error('Real Query Error:', error);
      return {
        answer: "I'm having trouble connecting to the AI service. Please check if your backend is running.",
        safe: false
      };
    }
  };

  // Select appropriate handler
  const uploadHandler = USE_MOCK ? handleMockUpload : handleRealUpload;
  const askHandler = USE_MOCK ? handleMockAsk : handleRealAsk;

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans text-slate-900">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />

      <div className="flex-1 flex flex-col overflow-hidden">
        <Header view={activeView} />
        
        <main className="flex-1 overflow-y-auto p-8">
          {activeView === 'dashboard' && (
            <Dashboard 
              view={activeView} 
              isUploading={isUploading} 
              onUpload={uploadHandler} 
            />
          )}

          {activeView === 'chat' && (
            <ChatInterface 
              onSendMessage={askHandler} 
            />
          )}

          {activeView === 'documents' && (
            <div className="max-w-5xl mx-auto space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-slate-800">Knowledge Base</h2>
                <span className="text-sm text-slate-500">{documents.length} documents indexed</span>
              </div>
              
              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Name</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Type</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Size</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Uploaded</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {documents.map((doc) => (
                      <tr key={doc.id} className="hover:bg-slate-50 transition-colors group">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded flex items-center justify-center">
                              <FileText className="w-4 h-4" />
                            </div>
                            <span className="text-sm font-medium text-slate-700">{doc.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-xs font-semibold px-2 py-1 bg-slate-100 text-slate-600 rounded-full">
                            {doc.type}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-500">{doc.size}</td>
                        <td className="px-6 py-4 text-sm text-slate-500">{doc.uploadedAt}</td>
                        <td className="px-6 py-4">
                          <button className="text-slate-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100">
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                    {documents.length === 0 && (
                      <tr>
                        <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                          <div className="flex flex-col items-center gap-3">
                            <AlertCircle className="w-10 h-10 opacity-20" />
                            <p>No documents found. Start by uploading one.</p>
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default App;
